package jp.elestyle.androidapp.elepay.core

import android.util.Log
import androidx.annotation.Keep
import androidx.annotation.RestrictTo

@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
enum class LogLevel {
    DEBUG, INFO, ERROR
}

@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun log(
    tag: String,
    message: String
) = log(tag, message, LogLevel.DEBUG)

@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun log(
    tag: String,
    message: String,
    logLevel: LogLevel
) = log(tag, message, logLevel, false)

@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun log(
    tag: String,
    message: String,
    logLevel: LogLevel,
    printsStackTrace: Boolean
) {
    // Avoid Kotlin default-argument bridge methods across separately minified modules.
    if (!BuildConfig.DEBUG && logLevel != LogLevel.ERROR) {
        return
    }

    val stackTraceExp = if (printsStackTrace) Exception() else null
    val logger: (String, String, Throwable?) -> Int = when (logLevel) {
        LogLevel.DEBUG -> Log::d
        LogLevel.INFO -> Log::i
        LogLevel.ERROR -> Log::e
    }
    logger(tag, message, stackTraceExp)
}
