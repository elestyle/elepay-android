package jp.elestyle.androidapp.elepay.core.theme

import androidx.annotation.Keep


/**
 * The theme of the user interface elements in elepay SDK
 */
@Keep
enum class ElepayTheme {
    /**
     * Matches current system's theme.
     */
    System,

    Light,

    Dark,
}