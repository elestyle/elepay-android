package jp.elestyle.androidapp.elepay.core.theme

import androidx.annotation.Keep
import androidx.annotation.RestrictTo
import androidx.appcompat.app.AppCompatDelegate

internal fun ElepayTheme.asAppCompatDelegateMode(): Int = when (this) {
    ElepayTheme.System -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    ElepayTheme.Light -> AppCompatDelegate.MODE_NIGHT_NO
    ElepayTheme.Dark -> AppCompatDelegate.MODE_NIGHT_YES
}

/**
 * Supposed to be called in Activity.onCreate and calling before `setContentView`.
 * @suppress
 */
@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
fun checkAndApplyElepayTheme(theme: ElepayTheme) {
    if (checkIfNeedsToApplyElepayTheme(theme)) {
        AppCompatDelegate.setDefaultNightMode(theme.asAppCompatDelegateMode())
    }
}

private fun checkIfNeedsToApplyElepayTheme(theme: ElepayTheme): Boolean {
    val appNightMode = AppCompatDelegate.getDefaultNightMode()
    return when (theme) {
        ElepayTheme.System -> appNightMode != AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM &&
                appNightMode != AppCompatDelegate.MODE_NIGHT_UNSPECIFIED

        ElepayTheme.Light -> appNightMode != AppCompatDelegate.MODE_NIGHT_NO

        ElepayTheme.Dark -> appNightMode != AppCompatDelegate.MODE_NIGHT_YES
    }
}