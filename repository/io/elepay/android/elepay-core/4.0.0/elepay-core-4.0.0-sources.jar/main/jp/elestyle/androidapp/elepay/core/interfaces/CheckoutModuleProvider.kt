package jp.elestyle.androidapp.elepay.core.interfaces

import android.app.Activity
import androidx.annotation.Keep
import androidx.annotation.RestrictTo
import org.json.JSONObject

@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
interface CheckoutModuleProvider {
    fun startCheckout(
        fromActivity: Activity,
        checkoutJson: JSONObject,
        resultHandler: Any,
        resultHandlerId: String,
    )

    fun isCheckoutAvailable(): Boolean

    companion object {
        @Keep
        @JvmStatic
        fun getInstance(): CheckoutModuleProvider? {
            return try {
                val clazz = Class.forName("jp.elestyle.androidapp.elepay.checkout.CheckoutModuleProviderImpl")
                clazz.getDeclaredConstructor().newInstance() as CheckoutModuleProvider
            } catch (e: Exception) {
                null
            } catch (e: LinkageError) {
                null
            }
        }
    }
}
