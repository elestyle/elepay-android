package jp.elestyle.androidapp.elepay.core.encryptor

import androidx.annotation.Keep
import androidx.annotation.RestrictTo

@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
data class EncryptedContent(val raw: String, val key: String)