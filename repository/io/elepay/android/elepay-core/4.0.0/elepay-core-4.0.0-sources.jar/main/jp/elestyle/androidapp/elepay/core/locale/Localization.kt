package jp.elestyle.androidapp.elepay.core.locale

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import androidx.annotation.Keep
import androidx.annotation.RestrictTo
import java.util.Locale

/**
 * @suppress
 */
@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@Suppress("unused")
object Localization {
    private var resources: Resources? = null

    fun setup(context: Context, languageKey: LanguageKey) {
        resources = if (languageKey == LanguageKey.System) {
            context.resources
        } else {
            val newConfig = makeLocalizedConfiguration(languageKey = languageKey, context = context)
            context.createConfigurationContext(newConfig).resources
        }
    }

    fun cleanup() {
        resources = null
    }

    fun changeLanguage(newKey: LanguageKey, context: Context) {
        val newConfig = makeLocalizedConfiguration(languageKey = newKey, context = context)
        resources = context.createConfigurationContext(newConfig).resources
    }

    fun string(id: Int): String {
        if (resources == null) {
            throw IllegalStateException("Not inited yet.")
        }
        return resources!!.getString(id)
    }

    private fun makeLocalizedConfiguration(
        languageKey: LanguageKey,
        context: Context
    ): Configuration =
        Configuration(context.resources.configuration).apply {
            convertToLocale(languageKey)?.also { locale ->
                setLocale(locale)
            }
        }

    private fun convertToLocale(languageKey: LanguageKey): Locale? =
        when (languageKey) {
            LanguageKey.System -> null
            LanguageKey.English -> Locale.ENGLISH
            LanguageKey.SimplifiedChinese -> Locale.CHINESE
            LanguageKey.TraditionalChinese -> Locale.TAIWAN
            LanguageKey.Japanese -> Locale.JAPANESE
        }
}
