package jp.elestyle.androidapp.elepay.core.encryptor

import android.util.Base64
import androidx.annotation.Keep
import androidx.annotation.RestrictTo
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
object ContentConverter {

    fun retrieveEncryptedContent(compound: String): EncryptedContent? {
        val encrypted = try {
            compound.substring(6)
        } catch (e: StringIndexOutOfBoundsException) {
            return null
        }
        val nonce = try {
            compound.substring(0, 6)
        } catch (e: StringIndexOutOfBoundsException) {
            return null
        }
        val key = SecuredDataStore.retrieveKey() + nonce

        return EncryptedContent(raw = encrypted, key = key)
    }

    fun decrypt(content: EncryptedContent): String =
        decrypt(content) { Base64.decode(it, Base64.DEFAULT) }

    fun decrypt(
        content: EncryptedContent,
        base64Decoding: (String) -> ByteArray
    ): String = decrypt(
        content.key.toByteArray(),
        base64Decoding(content.raw)
    )

    private fun decrypt(keyBytes: ByteArray, encryptionBytes: ByteArray): String =
        try {
            Cipher.getInstance("AES/CTR/NoPadding").apply {
                init(
                    Cipher.DECRYPT_MODE,
                    SecretKeySpec(keyBytes, "AES"),
                    IvParameterSpec(SecuredDataStore.generateIvParam())
                )
            }.doFinal(encryptionBytes).toString(Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }

    fun encrypt(content: String, key: String): String =
        encrypt(content, key) { Base64.encodeToString(it, Base64.NO_WRAP) }

    fun encrypt(
        content: String,
        key: String,
        base64Encoding: (ByteArray) -> String
    ): String {
        var nonce = ""
        repeat(6) {
            nonce += (0..15).random().toString(16)
        }
        val encrypted = try {
            Cipher.getInstance("AES/CTR/NoPadding").apply {
                init(
                    Cipher.ENCRYPT_MODE,
                    SecretKeySpec((key + nonce).toByteArray(), "AES"),
                    IvParameterSpec(SecuredDataStore.generateIvParam())
                )
            }.doFinal(content.toByteArray())
        } catch (e: java.lang.Exception) {
            byteArrayOf()
        }
        return nonce + base64Encoding(encrypted)
    }
}
