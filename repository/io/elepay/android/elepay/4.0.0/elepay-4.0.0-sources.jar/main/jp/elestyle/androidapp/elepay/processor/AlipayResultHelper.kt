package jp.elestyle.androidapp.elepay.processor

/**
 * Created by tanyin on 2018/02/05.
 */
internal data class AlipayResult(val status: String, val result: String, val memo: String)

internal object AlipayResultHelper {
    fun parseAlipayResult(rawResult: Map<String, String>): AlipayResult =
        AlipayResult(
            status = rawResult["resultStatus"] ?: "",
            result = rawResult["result"] ?: "", // 同步返回需要验证的信息
            memo = rawResult["memo"] ?: ""
        )
}