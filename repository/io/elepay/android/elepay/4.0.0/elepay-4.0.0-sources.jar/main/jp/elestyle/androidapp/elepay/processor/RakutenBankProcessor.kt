package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.internal.CreditCardProcessingActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.creditcard.WebViewCreditCard3dsProcessor
import jp.elestyle.androidapp.elepay.processor.creditcard.WebViewCreditCardProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.creditcard.CreditCardProcessingCenter
import org.json.JSONObject

private data class JsProcessingUrl(
    val creditCardUrl: String,
    val threeDSecurityUrl: String,
)

internal object RakutenBankProcessor : ElepayProcessor(true) {
    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else when (chargeData.method) {

            PaymentMethod.CREDIT_CARD -> {
                processCreditCard(chargeData, fromActivity, resultHandler)
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = chargeData.id,
                        error = ElepayError.UnsupportedPaymentMethod("Rakuten bank ${chargeData.method.rawValue}")
                    )
                )
                false
            }
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = if (processTestModePayment(sourceData.paymentCommon, fromActivity, resultHandler)) true
    else when (sourceData.method) {

        PaymentMethod.CREDIT_CARD -> {
            processCreditCardSource(sourceData, fromActivity, resultHandler)
        }

        else -> {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    paymentId = sourceData.id,
                    error = ElepayError.UnsupportedPaymentMethod("Rakuten bank ${sourceData.method.rawValue}")
                )
            )
            false
        }
    }

    private fun processCreditCard(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val processingUrl = retrieveProcessingUrl(chargeData)
        if (processingUrl.creditCardUrl.isEmpty()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.paymentCommon.id,
                    error = ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            PaymentMethodProvider.RAKUTEN_BANK,
                            PaymentMethod.CREDIT_CARD,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "No creditcard processing url for Rakuten Bank payment."
                    )
                ),
                handler = resultHandler
            )
            return false
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, chargeData.id)
        }
        CreditCardProcessingCenter[chargeData.id] =
            if (processingUrl.threeDSecurityUrl.isNotEmpty())
                WebViewCreditCard3dsProcessor(
                    paymentData = chargeData.paymentCommon,
                    creditCardProcessingUrl = processingUrl.creditCardUrl,
                    threeDAuthUrl = processingUrl.threeDSecurityUrl,
                    activity = fromActivity
                )
            else
                WebViewCreditCardProcessor(
                    paymentData = chargeData.paymentCommon,
                    processingUrl = processingUrl.creditCardUrl,
                    activity = fromActivity
                )
        val intent = Intent(fromActivity, CreditCardProcessingActivity::class.java).apply {
            putExtra(
                CreditCardProcessingActivity.IntentExtraKey.PAYMENT_ID.rawValue,
                chargeData.id
            )
        }
        fromActivity.startActivity(intent)

        return true
    }

    private fun processCreditCardSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val processingUrl = retrieveSourceProcessingUrl(sourceData)
        if (processingUrl.creditCardUrl.isEmpty()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = sourceData.paymentCommon.id,
                    error = ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            PaymentMethodProvider.RAKUTEN_BANK,
                            PaymentMethod.CREDIT_CARD,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "No creditcard processing url for Rakuten Bank payment."
                    )
                ),
                handler = resultHandler
            )
            return false
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, sourceData.id)
        }
        CreditCardProcessingCenter[sourceData.id] =
            if (processingUrl.threeDSecurityUrl.isNotEmpty())
                WebViewCreditCard3dsProcessor(
                    paymentData = sourceData.paymentCommon,
                    creditCardProcessingUrl = processingUrl.creditCardUrl,
                    threeDAuthUrl = processingUrl.threeDSecurityUrl,
                    activity = fromActivity
                )
            else
                WebViewCreditCardProcessor(
                    paymentData = sourceData.paymentCommon,
                    processingUrl = processingUrl.creditCardUrl,
                    activity = fromActivity
                )
        val intent = Intent(fromActivity, CreditCardProcessingActivity::class.java).apply {
            putExtra(
                CreditCardProcessingActivity.IntentExtraKey.PAYMENT_ID.rawValue,
                sourceData.id
            )
        }
        fromActivity.startActivity(intent)

        return true
    }

    private fun retrieveProcessingUrl(chargeData: ChargeData): JsProcessingUrl =
        if (chargeData.payload == null) JsProcessingUrl("", "")
        else try {
            val jsonPayload = JSONObject(chargeData.payload)
            val creditCardUrl = jsonPayload.optString("creditcard").let {
                if (it.contains("<key>")) {
                    it.replaceFirst("<key>", ConfigManager.appKey)
                } else ""
            }
            val threeDSecurityUrl = jsonPayload.optString("threeDSecure")

            JsProcessingUrl(creditCardUrl, threeDSecurityUrl)
        } catch (e: Exception) {
            JsProcessingUrl("", "")
        }

    private fun retrieveSourceProcessingUrl(sourceData: SourceData): JsProcessingUrl =
        if (sourceData.payload == null) JsProcessingUrl("", "")
        else try {
            val jsonPayload = JSONObject(sourceData.payload)
            val creditCardUrl = jsonPayload.optString("creditcard").let {
                if (it.contains("<key>")) {
                    it.replaceFirst("<key>", ConfigManager.appKey)
                } else ""
            }
            val threeDSecurityUrl = jsonPayload.optString("threeDSecure")

            JsProcessingUrl(creditCardUrl, threeDSecurityUrl)
        } catch (e: Exception) {
            JsProcessingUrl("", "")
        }
}