package jp.elestyle.androidapp.elepay.data

enum class RedirectType(val rawValue: String) {
    /**
     * Redirect to a web page.
     */
    BROWSER("browser"),

    /**
     * Redirect to a native app.
     */
    NATIVE("any"),

    /**
     * Redirect to a in-app web view.
     */
    IN_APP_BROWSER("in_app");

    companion object {
        /**
         * Try to parse the given string to a concrete [RedirectType] instance.
         * @return A valid [RedirectType] instance or `null` if parsing failed.
         */
        fun from(string: String): RedirectType? = when (string.lowercase()) {
            "browser" -> BROWSER
            "any" -> NATIVE
            "in_app" -> IN_APP_BROWSER
            else -> null
        }
    }
}
