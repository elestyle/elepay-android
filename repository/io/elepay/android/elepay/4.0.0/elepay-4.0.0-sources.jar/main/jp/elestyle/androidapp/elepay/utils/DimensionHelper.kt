@file:Suppress("unused")

package jp.elestyle.androidapp.elepay.utils

import android.content.Context
import android.util.TypedValue

internal fun dpToPx(dip: Float, context: Context): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dip, context.resources.displayMetrics)

internal fun pxToDp(pixel: Float, context: Context): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_PX, pixel, context.resources.displayMetrics)

internal fun spToPx(sp: Float, context: Context): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, context.resources.displayMetrics)