package jp.elestyle.androidapp.elepay.data

import java.util.Locale

internal enum class PaymentMethodProvider(val rawValue: String) {
    STRIPE("stripe"),
    BRAINTREE("braintree"),
    ALLPAY("allpay"),
    WECHAT_PAY("wechatpay"),
    ALIPAY("alipay"),
    LINE_PAY("linepay"),
    PAIDY("paidy"),
    PAYPAY("paypay"),
    MERPAY("merpay"),
    KSHER("ksher"),
    AMAZON_PAY("amazonpay"),
    DOCOMO_PAY("docomopay"),
    ATONE("atone"),
    PAYGENT("paygent"),
    AUPAY("aupay"),
    RAKUTEN_PAY("rakutenpay"),
    JCOINPAY("jcoinpay"),
    UNION_PAY("unionpay"),
    ALIPAY_PLUS("alipayplus"),
    GMO("gmo"),
    RAKUTEN_BANK("rankutenbank"),
    SONY_PAYMENT("sonypayment"),
    AEON_PAY("aeonpay"),
    PXPAY("pxpay"),
    ELEPAY_WEB_BROWSER_PAY("elepaywebbrowserpay"),
    ;

    companion object {
        fun from(string: String): PaymentMethodProvider? = when (string.lowercase(Locale.ROOT)) {
            "stripe" -> STRIPE
            "braintree", "brain tree" -> BRAINTREE
            "allpay" -> ALLPAY
            "wechat pay", "wechatpay", "wx" -> WECHAT_PAY
            "alipay" -> ALIPAY
            "linepay", "line", "line pay" -> LINE_PAY
            "paidy" -> PAIDY
            "paypay" -> PAYPAY
            "merpay" -> MERPAY
            "ksher" -> KSHER
            "amazonpay", "amazon" -> AMAZON_PAY
            "docomopay" -> DOCOMO_PAY
            "atone" -> ATONE
            "paygent" -> PAYGENT
            "aupay" -> AUPAY
            "rakutenpay" -> RAKUTEN_PAY
            "jcoinpay" -> JCOINPAY
            "unionpay" -> UNION_PAY
            "alipayplus" -> ALIPAY_PLUS
            "gmo" -> GMO
            "rakutenbank" -> RAKUTEN_BANK
            "sonypayment" -> SONY_PAYMENT
            "aeonpay" -> AEON_PAY
            "pxpay" -> PXPAY
            "elepaywebbrowserpay" -> ELEPAY_WEB_BROWSER_PAY
            else -> null
        }
    }

    val asErrorCodeBlock: String
        get() = when (this) {
            STRIPE -> "003"
            BRAINTREE -> "005"
            ALLPAY -> "004"
            WECHAT_PAY -> "001"
            ALIPAY -> "002"
            LINE_PAY -> "006"
            PAIDY -> "008"
            PAYPAY -> "010"
            MERPAY -> "011"
            KSHER -> "012"
            AMAZON_PAY -> "013"
            DOCOMO_PAY -> "014"
            ATONE -> "015"
            PAYGENT -> "016"
            AUPAY -> "017"
            RAKUTEN_PAY -> "018"
            JCOINPAY -> "019"
            UNION_PAY -> "020"
            ALIPAY_PLUS -> "021"
            GMO -> "022"
            RAKUTEN_BANK -> "023"
            SONY_PAYMENT -> "024"
            AEON_PAY -> "025"
            PXPAY -> "026"
            ELEPAY_WEB_BROWSER_PAY -> "999"
        }
}