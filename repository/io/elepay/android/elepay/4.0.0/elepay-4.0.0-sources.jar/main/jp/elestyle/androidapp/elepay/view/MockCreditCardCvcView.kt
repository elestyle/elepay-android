package jp.elestyle.androidapp.elepay.view

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Context
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.AttributeSet
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.view.doOnLayout
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.utils.creditcard.CardIssuer
import kotlin.math.absoluteValue

@Suppress("unused")
internal class MockCreditCardCvcView : LinearLayout {
    private val animationDuration = 250L

    // this value is different from `dots.count()`. `dots` is used to cache all the generated view,
    // and we just hide the ones that currently not seen.
    private var maxLength = CardIssuer.Unknown.cvcLength
    private val dots = mutableListOf<ImageView>()

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : this(
        context,
        attrs,
        defStyleAttr,
        0
    )

    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(
        context, attrs, defStyleAttr, defStyleRes
    )

    override fun onFinishInflate() {
        super.onFinishInflate()

        setup()
    }

    val isShowing: Boolean get() = visibility == View.VISIBLE

    fun show(animated: Boolean = true) {
        if (animated) {
            scheduleTransition()
        }

        visibility = View.VISIBLE
    }

    fun hide(animated: Boolean = true) {
        if (animated) {
            scheduleTransition()
        }

        visibility = View.INVISIBLE
    }

    fun updateMaxLength(length: Int, animated: Boolean = true) {
        if (maxLength == length) {
            return
        }

        if (animated) {
            scheduleTransition()
        }

        val diff = length - maxLength
        if (diff > 0) {
            if (dots.count() < length) {
                // uses the second dot as the sample, so that we can retrieve the margin value.
                val sampleDot = dots[1]
                repeat(diff) {
                    val dot = generateDot()
                    addView(dot, 0)
                    // Adjust the new dot's lp after adding to the view hierarchy.
                    val newLp = dot.layoutParams as LayoutParams
                    newLp.width = sampleDot.layoutParams.width
                    newLp.height = sampleDot.layoutParams.height

                    // Also add left margin to the current first dot.
                    val secondLp = dots.first().layoutParams as LayoutParams
                    secondLp.width = sampleDot.layoutParams.width
                    secondLp.height = sampleDot.layoutParams.height
                    secondLp.leftMargin = (sampleDot.layoutParams as LayoutParams).leftMargin

                    // Finally update the cache.
                    dots.add(0, dot)
                }
            }
            dots.forEach { it.visibility = View.VISIBLE }
        } else if (diff < 0) {
            for (i in 0..diff.absoluteValue) {
                dots[i].visibility = View.INVISIBLE
            }
        }

        maxLength = length
    }

    fun animateCvcDigit(digit: Int) {
        if (digit !in 1..dots.count()) {
            return
        }

        val idx = digit - 1
        val offset = dots[idx].height
        dots[idx]
            .animate()
            .setDuration(100L)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    dots[idx]
                        .animate()
                        .setDuration(100L)
                        .translationY(0f)
                        .start()
                }
            })
            .translationY(-offset.toFloat())
            .start()
    }

    private fun setup() {
        repeat(CardIssuer.Unknown.cvcLength) {
            val dot = generateDot()
            addView(dot)
            dots.add(dot)
        }

        doOnLayout {
            val dotDimen = (width * 0.03).toInt()
            val dotInterval = dotDimen / 2

            // Make space for the animation.
            val selfLp = layoutParams.apply { height = dotDimen * 3 }
            layoutParams = selfLp

            for (i in 0 until maxLength) {
                val newLp = dots[i].layoutParams as LayoutParams
                newLp.width = dotDimen
                newLp.height = dotDimen
                if (i > 0) {
                    newLp.leftMargin = dotInterval
                }
                dots[i].layoutParams = newLp
            }
        }
    }

    private fun generateDot(): ImageView {
        return ImageView(context).apply {
            setImageResource(R.drawable.credit_card_number_mock)
        }
    }

    private fun scheduleTransition() {
        TransitionManager.beginDelayedTransition(this, AutoTransition().apply {
            duration = animationDuration
        })
    }
}