package jp.elestyle.androidapp.elepay.utils

import androidx.annotation.Keep
import androidx.annotation.RestrictTo
import jp.elestyle.androidapp.elepay.BuildConfig
import jp.elestyle.androidapp.elepay.ElepayConfiguration
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.GooglePayEnvironment
import jp.elestyle.androidapp.elepay.core.LogLevel
import jp.elestyle.androidapp.elepay.core.encryptor.ContentConverter
import jp.elestyle.androidapp.elepay.core.locale.LanguageKey
import jp.elestyle.androidapp.elepay.core.log
import jp.elestyle.androidapp.elepay.core.theme.ElepayTheme
import jp.elestyle.androidapp.elepay.data.ElepayRemoteConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.utils.parsing.DataParser
import kotlinx.coroutines.delay
import org.json.JSONException
import org.json.JSONObject

internal object ConfigManager {
    private val logTag = ConfigManager::class.java.simpleName

    // This flag only differentiate the inited state from the un-inited state.
    // When the sdk is setup more than one time, e.g. call `Elepay.setup()` multiple times, this flag
    // remains `true` and won't change as true -> false -> true.
    var isInited = false
        get() = synchronized(this) {
            return field
        }
        private set(value) {
            synchronized(this) {
                field = value
            }
        }

    var appKey: String = ""
        private set

    var apiBaseUrl: String = ""
        private set

    var googlePayEnvironment: GooglePayEnvironment? = null
        private set

    var googlePayExistingPaymentRequired: Boolean = true
        private set

    // Save the value here and will be used by the Localization.
    var languageKey: LanguageKey = LanguageKey.System
        get() = synchronized(this) {
            return field
        }
        set(value) {
            synchronized(this) {
                field = value
            }
        }

    var theme: ElepayTheme = ElepayTheme.System
        get() = synchronized(this) {
            return field
        }
        set(value) {
            synchronized(this) {
                field = value
            }
        }

    fun update(config: ElepayConfiguration) {
        isInited = true

        this.appKey = config.apiKey
        this.apiBaseUrl =
            config.remoteHostBaseUrl.ifEmpty {
                "${BuildConfig.API_URL_SCHEME}://${BuildConfig.API_URL_HOST}/${BuildConfig.API_URL_VAR}"
                    .removeSuffix("/")
            }
        this.googlePayEnvironment = config.googlePayEnvironment
        this.googlePayExistingPaymentRequired = config.googlePayExistingPaymentRequired
        this.languageKey = config.languageKey
        this.theme = config.theme
    }

    suspend fun fetchConfigs(retry: Boolean = true): ResultType<ElepayRemoteConfig, ElepayError> {
        when (val result = ServerAPIClient.retrieveConfigs()) {
            is ResultType.Succeeded -> {
                val encrypted = DataParser.parseEncryptedConfig(jsonObject = result.data)
                    ?: return ResultType.Succeeded(ElepayRemoteConfig(listOf()))

                val jsonConfigs = ContentConverter.decrypt(content = encrypted).let {
                    try {
                        JSONObject(it)
                    } catch (e: JSONException) {
                        JSONObject()
                    }
                }
                return ResultType.Succeeded(DataParser.parseConfig(jsonObject = jsonConfigs))
            }

            is ResultType.Failed -> {
                // Bad network retry
                if (result.error.errorCode == ErrorCode.BAD_NETWORK && retry) {
                    delay(500)
                    return fetchConfigs(false)
                }
                val fmtErr = """
                    [${result.error.code}, ${result.error.message}, ${result.error.extra}]
                    """.trimIndent()
                log(logTag, "failed retrieve configs. error: $fmtErr", logLevel = LogLevel.ERROR)
                return ResultType.Failed(
                    ElepayError.SystemError(
                        errorCode = result.error.code,
                        message = result.error.message
                    )
                )
            }
        }
    }
}

/**
 * @suppress
 */
@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
object InnerConfigManagerWrap {
    val appKey: String
        get() = ConfigManager.appKey
    val apiBaseUrl: String
        get() = ConfigManager.apiBaseUrl
    val languageKey: LanguageKey
        get() = ConfigManager.languageKey
    val theme: ElepayTheme
        get() = ConfigManager.theme
}
