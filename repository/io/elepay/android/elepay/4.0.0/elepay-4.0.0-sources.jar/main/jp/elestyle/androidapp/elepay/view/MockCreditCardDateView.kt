package jp.elestyle.androidapp.elepay.view

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Context
import android.util.AttributeSet
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.view.doOnLayout
import jp.elestyle.androidapp.elepay.R

internal class MockCreditCardDateView : LinearLayout {
    private val dots = mutableListOf<ImageView>()

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : this(
        context,
        attrs,
        defStyleAttr,
        0
    )

    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(
        context, attrs, defStyleAttr, defStyleRes
    )

    override fun onFinishInflate() {
        super.onFinishInflate()

        setup()
    }

    fun animateDateDigit(digit: Int) {
        if (digit !in 1..dots.count()) {
            return
        }

        val idx = digit - 1
        val offset = dots[idx].height
        dots[idx]
            .animate()
            .setDuration(100L)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    dots[idx]
                        .animate()
                        .setDuration(100L)
                        .translationY(0f)
                        .start()
                }
            })
            .translationY(-offset.toFloat())
            .start()
    }

    private fun setup() {
        val divider = generateDivider()
        repeat(5) {
            if (it == 2) {
                addView(divider)
            } else {
                val dot = generateDot()
                addView(dot)
                dots.add(dot)
            }
        }

        doOnLayout {
            val dotDimen = (width * 0.028).toInt()
            val dotInterval = dotDimen / 2
            val dividerMargin = dotInterval / 2

            // Make space for the animation.
            val selfLp = layoutParams.apply { height = dotDimen * 3 }
            layoutParams = selfLp

            val dividerNewLp = divider.layoutParams as LayoutParams
            dividerNewLp.width = dotDimen
            dividerNewLp.height = dotDimen
            dividerNewLp.leftMargin = dividerMargin
            divider.layoutParams = dividerNewLp

            for (i in 0..3) {
                val newLp = dots[i].layoutParams as LayoutParams
                newLp.width = dotDimen
                newLp.height = dotDimen
                if (i > 0) {
                    if (i != 2) {
                        newLp.leftMargin = dotInterval
                    } else {
                        newLp.leftMargin = dividerMargin
                    }
                }
                dots[i].layoutParams = newLp
            }
        }
    }

    private fun generateDot(): ImageView {
        return ImageView(context).apply {
            setImageResource(R.drawable.credit_card_number_mock)
        }
    }

    private fun generateDivider(): ImageView {
        return ImageView(context).apply {
            setImageResource(R.drawable.slash_symbol)
            scaleType = ImageView.ScaleType.FIT_XY
        }
    }
}