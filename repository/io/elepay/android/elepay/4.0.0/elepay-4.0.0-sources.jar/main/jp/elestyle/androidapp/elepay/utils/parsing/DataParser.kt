package jp.elestyle.androidapp.elepay.utils.parsing

import android.util.Base64
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.core.encryptor.ContentConverter
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ChargeDataStatus
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ElepayRemoteConfig
import jp.elestyle.androidapp.elepay.core.encryptor.EncryptedContent
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.GmoGooglePayConfig
import jp.elestyle.androidapp.elepay.data.PaygentGooglePayConfig
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PaymentTestModeData
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.RedirectType
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import org.json.JSONException
import org.json.JSONObject

internal object DataParser {
    var base64Decoding: (String) -> ByteArray = { encoded ->
        Base64.decode(encoded, Base64.DEFAULT)
    }

    fun parseEncryptedConfig(jsonObject: JSONObject): EncryptedContent? {
        // payload is in the format of:
        //  nonce(6 digit number) + BASE64 encoded encrypted string.
        val payload = jsonObject.optString("payload", "")
        if (payload.count() < 6) {
            return null
        }
        return ContentConverter.retrieveEncryptedContent(compound = payload)
    }

    // Decrypted string should be a JSON object, looking like:
    // {
    //   "allpay": {"scheme": ""},
    //   "paypal": {"scheme": "", "mode": "sandbox"},
    //   "stripe": {"scheme": "", "sdkKey": "<stripe publishable key>", "appleMerchantId": "merchant.jp.elestyle.elepay"}
    // }
    fun parseConfig(jsonObject: JSONObject): ElepayRemoteConfig {
        val providerConfigs = mutableListOf<ElepayProviderConfig>()
        // Loop through the sdk defined providers, so that we won't miss the config parsing when
        // add a new provider.
        for (provider in PaymentMethodProvider.values()) {
            val jsonConfig = jsonObject.optJSONObject(provider.rawValue) ?: continue

            when (provider) {
                PaymentMethodProvider.ALLPAY -> {
                    val mode = jsonConfig.optString("mode", "")
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(
                        ElepayProviderConfig.Allpay(
                            usesDevelopmentEnvironment = mode.lowercase() == "sandbox",
                            appScheme = appScheme
                        )
                    )
                }
                PaymentMethodProvider.STRIPE -> {
                    val sdkKey = jsonConfig.optString("sdkKey", "")
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(
                        ElepayProviderConfig.Stripe(
                            publishableKey = sdkKey,
                            appScheme = appScheme
                        )
                    )
                }
                PaymentMethodProvider.BRAINTREE -> {
                    val mode = jsonConfig.optString("mode", "")
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(
                        ElepayProviderConfig.Braintree(
                            sandbox = mode.lowercase() == "sandbox",
                            appScheme = appScheme
                        )
                    )
                }
                PaymentMethodProvider.WECHAT_PAY -> {
                    val appKey = jsonConfig.optString("subAppIdForApp")
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(
                        ElepayProviderConfig.WechatPay(
                            appKey = appKey,
                            appScheme = appScheme
                        )
                    )
                }
                PaymentMethodProvider.ALIPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.Alipay(appScheme))
                }
                PaymentMethodProvider.LINE_PAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.LinePay(appScheme))
                }
                PaymentMethodProvider.PAIDY -> {
                    // No thing to do for paidy. Native sdk do not require configs for paidy.
                }
                PaymentMethodProvider.PAYPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.PayPay(appScheme))
                }
                PaymentMethodProvider.MERPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.Merpay(appScheme))
                }
                PaymentMethodProvider.KSHER -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val wechatKey = jsonConfig.optString("subAppIdForApp")
                    providerConfigs.add(ElepayProviderConfig.Ksher(wechatKey, appScheme))
                }
                PaymentMethodProvider.AMAZON_PAY -> {
                    // Nothing to do with amazon pay
                }
                PaymentMethodProvider.DOCOMO_PAY -> {
                    // Nothing to do with docomo pay
                }
                PaymentMethodProvider.ATONE -> {
                    // Nothing to do with atone
                }
                PaymentMethodProvider.PAYGENT -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val googlePayConfig =
                        jsonConfig.optJSONObject("defaultGooglePayRequest") ?: JSONObject()
                    val merchantId = jsonConfig.optString("merchantId")
                    providerConfigs.add(
                        ElepayProviderConfig.Paygent(
                            PaygentGooglePayConfig(
                                googlePayConfig,
                                merchantId
                            ),
                            appScheme
                        )
                    )
                }
                PaymentMethodProvider.AUPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.AuPay(appScheme))
                }
                PaymentMethodProvider.RAKUTEN_PAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val gatewayCode = jsonConfig.optString("gatewayCode", "")
                    providerConfigs.add(ElepayProviderConfig.RakutenPay(gatewayCode, appScheme))
                }
                PaymentMethodProvider.JCOINPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.JcoinPay(appScheme))
                }
                PaymentMethodProvider.UNION_PAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val mode = jsonConfig.optString("mode", "")
                    providerConfigs.add(ElepayProviderConfig.UnionPay(appScheme, mode))
                }
                PaymentMethodProvider.ALIPAY_PLUS -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.AlipayPlus(appScheme))
                }
                PaymentMethodProvider.GMO -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val gmoGooglePayConfig =
                        jsonConfig.optJSONObject("defaultGooglePayRequest")?.let {
                            GmoGooglePayConfig(
                                paymentDataRequestBase = it,
                                merchantId = jsonConfig.optString("merchantId"),
                                googlePayTestToken = jsonConfig.optString("googlePayTestToken")
                            )
                        }
                    providerConfigs.add(
                        ElepayProviderConfig.Gmo(gmoGooglePayConfig, appScheme)
                    )
                }
                PaymentMethodProvider.RAKUTEN_BANK -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.RakutenBank(appScheme))
                }
                PaymentMethodProvider.SONY_PAYMENT -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.SonyPayment(appScheme))
                }
                PaymentMethodProvider.AEON_PAY -> {
                    // Nothing to do with AEON pay
                }
                PaymentMethodProvider.PXPAY -> {
                    // Nothing to do with web browser pay
                }
                PaymentMethodProvider.ELEPAY_WEB_BROWSER_PAY -> {
                    // Nothing to do with web browser pay
                }
            }
        }
        return ElepayRemoteConfig(providerConfigs)
    }

    fun parseChargeData(jsonCharge: JSONObject): ResultType<ChargeData, ElepayError> {
        // Validate json data.
        val obj = jsonCharge.optString("object", "")
        if (obj != "charge") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_PAYLOAD,
                    message = "Invalid payload. raw: $jsonCharge"
                )
            )
        }

        val paymentId = jsonCharge.optString("id", "")
        if (paymentId.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_PAYMENT_ID,
                    message = "Invalid payment id. raw: $jsonCharge"
                )
            )
        }

        val resource = jsonCharge.optString("resource", "")
        if (resource != "android") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_RESOURCE,
                    message = "Invalid payload. Could not be handled by Android SDK. raw: $jsonCharge"
                )
            )
        }

        val amount = jsonCharge.optString("amount", "")
        validateAmount(amount)?.let { error ->
            return ResultType.Failed(error)
        }

        val currency = jsonCharge.optString("currency", "JPY")
        val name = jsonCharge.optString("name", "")
        val email = jsonCharge.optString("email", "")

        val method = jsonCharge.optString("paymentMethod")
            .let { PaymentMethod.from(string = it) }
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYMENT_METHOD
                )
            )

        val isTestMode = !jsonCharge.optBoolean("liveMode", true)

        val jsonCredential = parseCredential(jsonCharge, base64Decoding)
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_CREDENTIAL)
            )

        // The following 2 could be null.
        val payload = parsePayload(jsonCredential)
        val redirectType = jsonCredential.optString("redirectType", "any")
        val redirectUrl = parseRedirectUrl(jsonCredential)

        val providerString = jsonCredential.optString("provider")
        val provider = PaymentMethodProvider.from(providerString)
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_PROVIDER)
            )

        // Check status last. Because we only check parts of the status,
        // we need to make sure the other fields are all valid.
        val status = when (jsonCharge.optString("status", "")) {
            "pending" -> ChargeDataStatus.PENDING
            "captured" -> ChargeDataStatus.CAPTURED
            else ->
                return ResultType.Failed(
                    generateUserAwareInvalidPayloadError(
                        errorCode = ErrorCode.INVALID_STATUS,
                        message = "Invalid status. raw: $jsonCharge"
                    )
                )
        }

        return ResultType.Succeeded(
            ChargeData(
                paymentCommon = PaymentCommon(
                    paymentId,
                    provider,
                    method,
                    PaymentDataType.CHARGE,
                    if (isTestMode && redirectUrl != null) PaymentTestModeData(redirectUrl) else null
                ),
                amount = amount,
                currency = currency,
                name = name,
                email = email,
                payload = payload,
                redirectType = RedirectType.from(redirectType) ?: RedirectType.NATIVE,
                redirectUrl = redirectUrl,
                status = status,
                rawJson = jsonCharge
            )
        )
    }

    private fun validateAmount(amount: String): ElepayError? {
        val valid = if (amount.isEmpty()) {
            false
        } else {
            amount.toDoubleOrNull()
                ?.let { it > 0 }
                ?: false
        }
        return if (!valid) generateUserAwareInvalidPayloadError(ErrorCode.INVALID_AMOUNT)
        else null
    }

    fun parseSourceData(jsonSource: JSONObject): ResultType<SourceData, ElepayError> {
        // Validate json data.
        val obj = jsonSource.optString("object", "")
        if (obj != "source") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_PAYLOAD,
                    message = "Invalid payload. raw: $jsonSource"
                )
            )
        }

        val sourceId = jsonSource.optString("id", "")
        if (sourceId.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_PAYMENT_ID,
                    message = "Invalid payment id. raw: $jsonSource"
                )
            )
        }

        val status = jsonSource.optString("status", "")
        if (status != "pending") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_STATUS,
                    message = "Invalid status. raw: $jsonSource"
                )
            )
        }

        val resource = jsonSource.optString("resource", "")
        if (resource != "android") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_RESOURCE,
                    message = "Invalid payload. Could not be handled by Android SDK. raw: $jsonSource"
                )
            )
        }

        val method = jsonSource.optString("paymentMethod")
            .let { PaymentMethod.from(string = it) }
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_PAYMENT_METHOD)
            )

        val isTestMode = !jsonSource.optBoolean("liveMode", true)

        val jsonCredential = parseCredential(jsonSource, base64Decoding)
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_CREDENTIAL)
            )

        val payload = parsePayload(jsonCredential)
        val redirectType = jsonCredential.optString("redirectType", "any")
        val redirectUrl = parseRedirectUrl(jsonCredential)

        val providerString = jsonCredential.optString("provider")
        val provider = PaymentMethodProvider.from(providerString)
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_PROVIDER)
            )

        return ResultType.Succeeded(
            SourceData(
                paymentCommon = PaymentCommon(
                    sourceId,
                    provider,
                    method,
                    PaymentDataType.SOURCE,
                    if (isTestMode && redirectUrl != null) PaymentTestModeData(redirectUrl) else null
                ),
                payload = payload,
                redirectUrl = redirectUrl,
                redirectType = RedirectType.from(redirectType) ?: RedirectType.NATIVE,
                rawJson = jsonSource
            )
        )
    }

    private fun parseCredential(
        jsonCharge: JSONObject,
        base64Decoding: (String) -> ByteArray
    ): JSONObject? {
        val rawCredential = jsonCharge.optString("credential", "")
            .ifEmpty { return null }

        val encryptedCredential =
            ContentConverter.retrieveEncryptedContent(rawCredential) ?: return null
        val credentialString = ContentConverter.decrypt(
            content = encryptedCredential,
            base64Decoding = base64Decoding
        )
        return try {
            JSONObject(credentialString)
        } catch (e: JSONException) {
            return null
        }
    }

    private fun parsePayload(jsonCredential: JSONObject): String? =
        if (jsonCredential.has("payload") && !jsonCredential.isNull("payload")) {
            jsonCredential.optString("payload", "").takeIf { it.isNotEmpty() }
        } else null

    private fun parseRedirectUrl(jsonCredential: JSONObject): String? =
        if (jsonCredential.has("redirectUrl") && !jsonCredential.isNull("redirectUrl")) {
            jsonCredential.optString("redirectUrl", "").let {
                if (it.isEmpty()) null else it.replaceFirst(
                    "<key>",
                    ConfigManager.appKey
                )
            }
        } else null

    fun generateUserAwareInvalidPayloadError(
        errorCode: ErrorCode,
        message: String = "charge error"
    ): ElepayError.InvalidPayload =
        ElepayError.InvalidPayload(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.ENDUSER,
                null,
                null,
                errorCode
            ),
            message = message
        )
}
