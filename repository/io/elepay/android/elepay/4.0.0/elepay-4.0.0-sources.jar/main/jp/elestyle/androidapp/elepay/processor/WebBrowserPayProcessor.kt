package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.internal.ElepayWebProcessorActivity
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.RedirectType
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator

internal object WebBrowserPayProcessor : ElepayProcessor(true), CallbackProcessable {
    private var processingData: CallbackProcessable.ProcessingPaymentInfo? = null

    override var callbackScheme: String = ""
        private set

    override fun retrieveProcessingPaymentInfo(
        disposeImmediately: Boolean
    ): CallbackProcessable.ProcessingPaymentInfo? {
        val ret = processingData
        if (disposeImmediately) {
            processingData = null
        }
        return ret
    }

    override suspend fun continueCallbackProcessing(
        data: CallbackProcessingData
    ): CallbackProcessable.ProcessedResult {
        val paymentId = data.paymentData.id
        val elepayResult = when (data.params["status"]?.lowercase()) {
            "cancelled" -> ElepayResult.Canceled(paymentId)
            "captured", "active" -> ElepayResult.Succeeded(paymentId)
            else -> ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        data.paymentData.provider,
                        data.paymentData.method,
                        ErrorCode.FAILED
                    ),
                    "No valid type found."
                )
            )
        }

        return CallbackProcessable.ProcessedResult(paymentId, elepayResult)
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        when (chargeData.redirectType) {
            RedirectType.IN_APP_BROWSER -> {
                val paymentUrl = chargeData.redirectUrl ?: run {
                    val error = ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.ELEPAY_WEB_BROWSER_PAY,
                            PaymentMethod.WEB_BROWSER_PAY,
                            ErrorCode.INVALID_AUTH_URL
                        ),
                        "No available url for authorization."
                    )
                    resultHandler?.invoke(ElepayResult.Failed(chargeData.id, error))
                    return false
                }
                processInAppWebBrowserPay(
                    paymentUrl,
                    chargeData.paymentCommon,
                    fromActivity,
                    resultHandler
                )
                true
            }

            RedirectType.BROWSER -> {
                // Open RedirectURL in external browser
                openUrlInExternalBrowser(
                    chargeData.redirectUrl ?: "",
                    chargeData.paymentCommon,
                    chargeData.id,
                    fromActivity,
                    resultHandler
                )
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = chargeData.id,
                        error = ElepayError.UnsupportedPaymentMethod(chargeData.method.rawValue)
                    )
                )
                false
            }
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        when (sourceData.redirectType) {
            RedirectType.IN_APP_BROWSER -> {
                val paymentUrl = sourceData.redirectUrl ?: run {
                    val error = ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.ELEPAY_WEB_BROWSER_PAY,
                            PaymentMethod.WEB_BROWSER_PAY,
                            ErrorCode.INVALID_AUTH_URL
                        ),
                        "No available url for authorization."
                    )
                    resultHandler?.invoke(ElepayResult.Failed(sourceData.id, error))
                    return false
                }
                processInAppWebBrowserPay(
                    paymentUrl,
                    sourceData.paymentCommon,
                    fromActivity,
                    resultHandler
                )
            }

            RedirectType.BROWSER -> {
                // Open RedirectURL in external browser
                openUrlInExternalBrowser(
                    sourceData.redirectUrl ?: "",
                    sourceData.paymentCommon,
                    sourceData.id,
                    fromActivity,
                    resultHandler
                )
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = sourceData.id,
                        error = ElepayError.UnsupportedPaymentMethod(sourceData.method.rawValue)
                    )
                )
                false
            }
        }

    private fun processInAppWebBrowserPay(
        paymentUrl: String,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentData.id)
        }
        val intent = Intent(fromActivity, ElepayWebProcessorActivity::class.java).apply {
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.PAYMENT_DATA.rawValue, paymentData)
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.TARGET_URL.rawValue, paymentUrl)
        }
        fromActivity.startActivity(intent)
        return true
    }

    private fun openUrlInExternalBrowser(
        url: String,
        paymentCommon: PaymentCommon,
        processId: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        return try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            processingData = CallbackProcessable.ProcessingPaymentInfo(paymentCommon)
            if (resultHandler != null) {
                ElepayResultHandlerManager.registerResultHandler(resultHandler, processId)
            }
            fromActivity.startActivity(browserIntent)
            true
        } catch (e: ActivityNotFoundException) {
            // Handle the error when no browser is installed
            resultHandler?.invoke(
                ElepayResult.Failed(
                    paymentId = processId,
                    error = ElepayError.UnsupportedPaymentMethod(PaymentMethod.WEB_BROWSER_PAY.rawValue)
                )
            )
            false
        }
    }
}