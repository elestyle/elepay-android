package jp.elestyle.androidapp.elepay.activity.rakutenpay

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import jp.co.rakuten.pay.sdk.RPayHelper
import jp.co.rakuten.pay.sdk.RPayPaymentResult
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.processor.RakutenPayProcessor
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator


internal class RakutenPayResultHandlingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        val paymentId = RakutenPayProcessor.paymentId

        if (!RPayHelper.isPaymentResultIntent(intent)) {
            // Intent does not have required action.
            val failure = ElepayError.PaymentFailure(
                errorCode = ErrorCodeGenerator.generate(
                    platform = PlatformCode.ENDUSER,
                    provider = PaymentMethodProvider.RAKUTEN_PAY,
                    method = PaymentMethod.RAKUTEN_PAY,
                    errorCode = ErrorCode.INVALID_DATA
                ),
                message = "No valid data parsed from the result intent."
            )
            finishPayment(ElepayResult.Failed(paymentId, failure))
            return
        }

        val result = RPayPaymentResult.fromIntent(intent)
        when (result.paymentResult) {
            RPayPaymentResult.RESULT_COMPLETE ->
                finishPayment(ElepayResult.Succeeded(paymentId))

            RPayPaymentResult.RESULT_CANCELED ->
                finishPayment(ElepayResult.Canceled(paymentId))

            RPayPaymentResult.RESULT_UNKNOWN ->
                finishPayment(
                    ElepayResult.Failed(
                        paymentId,
                        ElepayError.PaymentFailure(
                            errorCode = ErrorCodeGenerator.generate(
                                platform = PlatformCode.ENDUSER,
                                provider = PaymentMethodProvider.RAKUTEN_PAY,
                                method = PaymentMethod.RAKUTEN_PAY,
                                errorCode = ErrorCode.FAILED
                            ),
                            message = "Failed processing Rakuten Payment."
                        )
                    )
                )
        }
    }

    private fun finishPayment(result: ElepayResult) {
        val paymentId = RakutenPayProcessor.paymentId
        ElepayResultHandlerManager.notifyResult(result, paymentId)
        runOnUiThread { finish() }
    }
}