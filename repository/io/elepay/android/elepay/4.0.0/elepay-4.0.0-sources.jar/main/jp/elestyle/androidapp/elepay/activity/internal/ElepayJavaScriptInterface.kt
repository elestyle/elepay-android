package jp.elestyle.androidapp.elepay.activity.internal

import android.webkit.JavascriptInterface
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import org.json.JSONObject
import java.lang.ref.WeakReference

internal interface ElepayJsActionPerformer {
    fun onPaymentResult(result: ElepayResult)

    fun onCapturePayment(token: String)

    fun onConfirmPayment(token: String)

    fun onProviderPaymentParams(callbackEvent: String)

    fun onOpen(url: String)
}

@Suppress("UNUSED_PARAMETER", "unused")
internal open class ElepayJavaScriptInterface(
    private val paymentData: PaymentCommon,
    private val weakPerformer: WeakReference<ElepayJsActionPerformer>
) {

    sealed class JsResultType {
        object Success : JsResultType()
        object Failure : JsResultType()
        object Cancelled : JsResultType()
    }

    companion object {
        const val ELEPAY_JS_NAME = "elepayAndroid"
    }

    private fun convertToElepayResult(jsResult: JsResultType, jsMessage: String): ElepayResult =
        when (jsResult) {
            is JsResultType.Success -> ElepayResult.Succeeded(paymentData.id)

            is JsResultType.Failure -> ElepayResult.Failed(
                paymentData.id,
                ElepayError.PaymentFailure(
                    ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        paymentData.provider,
                        paymentData.method,
                        ErrorCode.FAILED
                    ),
                    jsMessage
                )
            )

            is JsResultType.Cancelled -> ElepayResult.Canceled(paymentData.id)
        }

    @JavascriptInterface
    open fun onPaymentSucceeded(message: String) {
        val res = convertToElepayResult(jsResult = JsResultType.Success, jsMessage = message)
        weakPerformer.get()?.onPaymentResult(res)
    }

    @JavascriptInterface
    open fun onPaymentFailed(message: String) {
        val res = convertToElepayResult(jsResult = JsResultType.Failure, jsMessage = message)
        weakPerformer.get()?.onPaymentResult(res)
    }

    @JavascriptInterface
    open fun onPaymentCancelled(message: String) {
        val res = convertToElepayResult(jsResult = JsResultType.Cancelled, jsMessage = message)
        weakPerformer.get()?.onPaymentResult(res)
    }

    @JavascriptInterface
    open fun onCapture(token: String) {
        weakPerformer.get()?.onCapturePayment(token)
    }

    @JavascriptInterface
    open fun onConfirm(token: String) {
        weakPerformer.get()?.onConfirmPayment(token)
    }

    @JavascriptInterface
    open fun onProviderPaymentParams(callbackEvent: String) {
        weakPerformer.get()?.onProviderPaymentParams(callbackEvent)
    }

    @JavascriptInterface
    open fun onOpen(url: String) {
        weakPerformer.get()?.onOpen(url)
    }

    @JavascriptInterface
    open fun onPayment3DSResult(result: String) {
        val jsonRes = JSONObject(result)
        val res = when (jsonRes.optString("result").lowercase()) {
            "success" -> ElepayResult.Succeeded(jsonRes.optString("threeDSecureId"))
            "failure" -> ElepayResult.Failed(
                paymentData.id,
                ElepayError.PaymentFailure(
                    ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        paymentData.provider,
                        paymentData.method,
                        ErrorCode.CREDITCARD_3D_AUTH_FAILURE
                    ),
                    "failed auth"
                )
            )

            else -> ElepayResult.Failed(
                paymentData.id,
                ElepayError.PaymentFailure(
                    ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        paymentData.provider,
                        paymentData.method,
                        ErrorCode.FAILED
                    ),
                    result
                )
            )
        }
        weakPerformer.get()?.onPaymentResult(res)
    }
}