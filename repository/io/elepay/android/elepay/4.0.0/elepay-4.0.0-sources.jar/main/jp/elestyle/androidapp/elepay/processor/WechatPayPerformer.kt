package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import com.tencent.mm.opensdk.modelbase.BaseResp
import com.tencent.mm.opensdk.modelpay.PayReq
import com.tencent.mm.opensdk.openapi.WXAPIFactory
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.IntegrationChecker
import org.json.JSONObject

internal object WechatPayPerformer {
    /**
     * This data structure is supposed to be used only by WechatPayPerformer.
     */
    internal data class PaymentInfo(
        val apiKey: String,
        val paymentId: String,
        val provider: PaymentMethodProvider,
        /**
         * The data conatins information for wechat processing. Basically, it's the data parsed
         * from charge data's payload.
         */
        val paymentData: JSONObject,
    )

    private var paymentInfo: PaymentInfo? = null

    val apiKey: String
        get() = paymentInfo?.apiKey ?: ""

    fun pay(
        info: PaymentInfo,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (this.paymentInfo?.paymentId == info.paymentId) {
            val failure = ElepayResult.Failed(
                info.paymentId,
                ElepayError.AlreadyMakingPayment(info.paymentId)
            )
            resultHandler?.invoke(failure)
            return false
        }

        if (!IntegrationChecker.isWechatPayAvailable()) {
            val error = ElepayError.UninitializedPaymentMethod(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    null,
                    null,
                    ErrorCode.UNINIT
                ),
                paymentMethod = PaymentMethod.WECHAT_PAY.rawValue,
                message = "Have you installed wechat sdk to your project?"
            )
            resultHandler?.invoke(ElepayResult.Failed(info.paymentId, error))
            return false
        }

        val wxApi = WXAPIFactory.createWXAPI(fromActivity, info.apiKey)
        if (!wxApi.isWXAppInstalled) {
            val error = ElepayError.PaymentFailure(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    null,
                    null,
                    ErrorCode.APP_NOT_INSTALLED
                ),
                message = "Wechat app could not be opened for the processing."
            )
            resultHandler?.invoke(ElepayResult.Failed(info.paymentId, error))
            return false
        }

        this.paymentInfo = info
        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, info.paymentId)
        }

        PayReq().apply {
            appId = info.paymentData.optString("appid")
            partnerId = info.paymentData.optString("partnerid")
            prepayId = info.paymentData.optString("prepayid")
            packageValue = info.paymentData.optString("package")
            nonceStr = info.paymentData.optString("noncestr")
            timeStamp = info.paymentData.optString("timestamp")
            sign = info.paymentData.optString("sign")
        }.also { wxApi.sendReq(it) }

        return true
    }

    fun processWechatPayResponse(response: BaseResp) {
        if (paymentInfo == null) {
            return
        }
        val paymentId = paymentInfo!!.paymentId
        when (response.errCode) {
            0 -> {
                finishPayment(ElepayResult.Succeeded(paymentId), paymentId)
            }
            -2 -> {
                // user canceled payment.
                finishPayment(ElepayResult.Canceled(paymentId), paymentId)
            }
            else -> {
                val provider = paymentInfo!!.provider
                val result = ElepayResult.Failed(
                    paymentId = paymentId,
                    error = ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            provider,
                            PaymentMethod.WECHAT_PAY,
                            ErrorCode.FAILED
                        ), message = ""
                    )
                )
                finishPayment(result, paymentId)
            }
        }
    }

    private fun finishPayment(result: ElepayResult, paymentId: String) {
        ElepayResultHandlerManager.notifyResult(result, paymentId)

        paymentInfo = null
    }
}