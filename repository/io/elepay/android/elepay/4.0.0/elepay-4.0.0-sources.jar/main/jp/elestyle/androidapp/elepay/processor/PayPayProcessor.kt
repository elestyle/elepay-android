package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.PayPayHelper
import jp.elestyle.androidapp.elepay.utils.ServerAPIClient
import org.json.JSONObject

internal object PayPayProcessor : ElepayProcessor(), CallbackProcessable {
    private sealed class PaymentType {
        class Charge(val payload: String?) : PaymentType()
        class Source(val redirectUrl: String?) : PaymentType()
    }

    private var processingData: CallbackProcessable.ProcessingPaymentInfo? = null

    override fun setup(providerConfig: ElepayProviderConfig) {
        super.setup(providerConfig)
        if (providerConfig is ElepayProviderConfig.PayPay) {
            callbackScheme = providerConfig.appScheme
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = processPayPay(
        chargeData.paymentCommon,
        PaymentType.Charge(chargeData.payload),
        fromActivity,
        resultHandler
    )

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = processPayPay(
        sourceData.paymentCommon,
        PaymentType.Source(sourceData.redirectUrl),
        fromActivity,
        resultHandler
    )

    override var callbackScheme: String = ""
        private set

    override fun retrieveProcessingPaymentInfo(
        disposeImmediately: Boolean
    ): CallbackProcessable.ProcessingPaymentInfo? {
        val ret = processingData
        if (disposeImmediately) {
            processingData = null
        }
        return ret
    }

    override suspend fun continueCallbackProcessing(
        data: CallbackProcessingData
    ): CallbackProcessable.ProcessedResult {
        val paymentId = data.paymentData.id
        val elepayResult = when (data.params["type"]?.lowercase()) {
            null -> ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        data.paymentData.provider,
                        data.paymentData.method,
                        ErrorCode.FAILED
                    ),
                    "No valid type found."
                )
            )

            "confirm" -> {
                when (data.paymentData.dataType) {
                    PaymentDataType.CHARGE -> capturePayment(paymentId, "")

                    PaymentDataType.SOURCE -> {
                        val token = data.params["responseToken"]
                        if (token.isNullOrEmpty()) {
                            val error = ElepayError.PaymentFailure(
                                errorCode = ErrorCodeGenerator.generate(
                                    PlatformCode.SDK,
                                    PaymentMethodProvider.PAYPAY,
                                    PaymentMethod.PAYPAY,
                                    errorCode = ErrorCode.FAILED,
                                ),
                                message = "Failed to get token."
                            )
                            ElepayResult.Failed(paymentId, error)
                        } else {
                            confirmPayment(paymentId, token)
                        }
                    }

                    // Impossible
                    PaymentDataType.CHECKOUT -> ElepayResult.Failed(
                        paymentId = paymentId,
                        error = ElepayError.InvalidPayload(
                            ErrorCodeGenerator.generate(
                                PlatformCode.ENDUSER,
                                data.paymentData.provider,
                                data.paymentData.method,
                                ErrorCode.FAILED
                            ),
                            "CHECKOUT data could not be processed."
                        )
                    )
                }
            }

            // FIXME: When PayPay returns a result with more information, we can check the final result more precisely.
            else -> ElepayResult.Canceled(paymentId)
        }

        return CallbackProcessable.ProcessedResult(paymentId, elepayResult)
    }

    private fun processPayPay(
        paymentData: PaymentCommon,
        paymentType: PaymentType,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(paymentData, fromActivity, resultHandler)) true
        else when (paymentData.method) {
            PaymentMethod.PAYPAY -> {
                if (callbackScheme.isEmpty()) {
                    val error = ElepayError.UninitializedPaymentMethod(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.PAYPAY,
                            PaymentMethod.PAYPAY,
                            ErrorCode.UNINIT
                        ),
                        PaymentMethod.PAYPAY.rawValue,
                        "Not well configured"
                    )
                    resultHandler?.invoke(ElepayResult.Failed(paymentData.id, error))
                    false
                } else {
                    when (paymentType) {
                        is PaymentType.Charge -> {
                            processPayPayCharge(
                                paymentType.payload,
                                paymentData,
                                fromActivity,
                                resultHandler
                            )
                        }

                        is PaymentType.Source -> {
                            processPayPaySource(
                                paymentType.redirectUrl,
                                paymentData,
                                fromActivity,
                                resultHandler
                            )
                        }
                    }
                }
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = paymentData.id,
                        error = ElepayError.UnsupportedPaymentMethod(paymentData.method.rawValue)
                    )
                )
                false
            }
        }

    private fun processPayPayCharge(
        payload: String?,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val paymentId = paymentData.id
        if (payload.isNullOrEmpty()) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.PAYPAY,
                    PaymentMethod.PAYPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.PAYPAY.rawValue} no payload."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentId, error = error))
            return false
        }

        val jsonPayload = try {
            JSONObject(payload)
        } catch (e: Exception) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.PAYPAY,
                    PaymentMethod.PAYPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.PAYPAY.rawValue} invalid json payload."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentId, error = error))
            return false
        }

        val jsonPaymentUrl = jsonPayload.optJSONObject("paymentUrl") ?: run {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.PAYPAY,
                    PaymentMethod.PAYPAY,
                    ErrorCode.INVALID_AUTH_URL
                ),
                "No available url for authorization."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId, error))
            return false
        }

        val appUrl = jsonPaymentUrl.optString("app", "")
        loadPayPayPaymentUrl(appUrl, paymentData, fromActivity, resultHandler)

        return true
    }

    private fun processPayPaySource(
        redirectUrl: String?,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val paymentId = paymentData.id
        if (redirectUrl.isNullOrEmpty()) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.PAYPAY,
                    PaymentMethod.PAYPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.PAYPAY.rawValue} no redirect url."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentId, error = error))
            return false
        }

        loadPayPayPaymentUrl(redirectUrl, paymentData, fromActivity, resultHandler)

        return true
    }

    private fun loadPayPayPaymentUrl(
        paymentUrl: String,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ) {
        val paymentId = paymentData.id
        var finishedLaunching = false

        if (PayPayHelper.isPayPayInstalled(fromActivity)) {
            finishedLaunching = if (paymentUrl.isNotEmpty()) {
                try {
                    val uri = Uri.parse(paymentUrl)
                    fromActivity.startActivity(Intent(Intent.ACTION_VIEW, uri))
                    processingData = CallbackProcessable.ProcessingPaymentInfo(paymentData)
                    if (resultHandler != null) {
                        ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
                    }
                    true
                } catch (e: Exception) {
                    false
                }
            } else false
        }

        // For whatever reason, the app could not be opened. Return an error to let user handle it.
        //
        // 20191010, PayPay's web url target is not a payment processing page. It just try to
        // open the PayPay app or shows a download page. And specifically, it has a lot redirects
        // then try to open a url like
        //  intent://payment?af_android_url=https%3A%2F%2Fpaypay.ne.jp%2F&af_deeplink=true&af_ios_url=https%3A%2F%2Fpaypay.ne.jp%2F&af_web_i....
        // This url won't be showed correctly in our own WebView, and we have to do a lot of extra
        // handles to make it work, which just shows an introducing page with a download icon.
        // And when the final user clicks the download icon, it just replaced the current page with
        // the Google Play page. And of course, our inner WebView has no user authorization so the
        // download won't process smoothly.
        // For above reason, we choose to return an error to let the user(not the final user)
        // handle the situation. And also provide another interface in Elepay to let the user
        // check if the PayPay app has been installed.
        // In future, if PayPay finally made a working web page, we would change this logic to
        // open that page, like LinePayProcessor did.
        if (!finishedLaunching) {
            val error = ElepayError.PaymentFailure(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    null,
                    null,
                    ErrorCode.APP_NOT_INSTALLED
                ),
                message = "PayPay app could not be opened for the processing."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId, error))
        }
    }

    private suspend fun capturePayment(paymentId: String, token: String): ElepayResult =
        when (ServerAPIClient.capture(paymentId, token)) {
            is ResultType.Failed ->
                ElepayResult.Failed(
                    paymentId,
                    ElepayError.PaymentFailure(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.PAYPAY,
                            PaymentMethod.PAYPAY,
                            ErrorCode.FAILED_CAPTURE
                        ),
                        "Failed to capture."
                    )
                )

            is ResultType.Succeeded -> ElepayResult.Succeeded(paymentId)
        }

    private suspend fun confirmPayment(paymentId: String, token: String): ElepayResult =
        when (val res = ServerAPIClient.confirm(paymentId, token)) {
            is ResultType.Failed -> {
                // This special code is used by PayPay when user canceled source auth.
                if (res.error.code.split("_").lastOrNull() == "40046") {
                    ElepayResult.Canceled(paymentId)
                } else {
                    ElepayResult.Failed(
                        paymentId,
                        ElepayError.PaymentFailure(
                            ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                PaymentMethodProvider.PAYPAY,
                                PaymentMethod.PAYPAY,
                                ErrorCode.FAILED_CAPTURE
                            ),
                            "Failed to confirm."
                        )
                    )
                }
            }

            is ResultType.Succeeded -> ElepayResult.Succeeded(paymentId)
        }
}