package jp.elestyle.androidapp.elepay.processor.creditcard

import androidx.activity.ComponentActivity

internal interface ActivityAwarenessCreditCardProcessor : CreditCardProcessor {
    fun onHostActivityCreate(hostActivity: ComponentActivity)

    fun onHostActivityDestroy(hostActivity: ComponentActivity)
}