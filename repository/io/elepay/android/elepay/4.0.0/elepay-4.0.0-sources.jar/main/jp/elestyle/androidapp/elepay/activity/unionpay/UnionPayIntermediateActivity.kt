package jp.elestyle.androidapp.elepay.activity.unionpay

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.unionpay.UPPayAssistEx
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.core.log

internal class UnionPayIntermediateActivity : Activity() {
    enum class IntentExtraKey(val rawValue: String) {
        USES_DEVELOPMENT_ENVIRONMENT("uses_dev_env"),
        PAYMENT_ID("payment_id"),
        PAYMENT_TN("payment_tn")
    }

    private lateinit var paymentId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        intent.extras?.run {
            paymentId = getString(IntentExtraKey.PAYMENT_ID.rawValue) ?: ""
            // According to Union's sdk doc, "01" for test, "00" for prod
            val mode = getBoolean(IntentExtraKey.USES_DEVELOPMENT_ENVIRONMENT.rawValue).let {
                if (it) "01" else "00"
            }

            getString(IntentExtraKey.PAYMENT_TN.rawValue)?.also { tn ->
                UPPayAssistEx.startPay(this@UnionPayIntermediateActivity, null, null, tn, mode)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (data == null) {
            return
        }

        val resultStr = data.extras?.getString("pay_result")?.lowercase() ?: run {
            log("UnionPayResultActivity", "onActivityResult: no valid pay result. Ignore")
            return
        }
        val elepayRes = when (resultStr) {
            "success" -> ElepayResult.Succeeded(paymentId)

            "fail" -> ElepayResult.Failed(
                paymentId,
                error = ElepayError.PaymentFailure(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.UNION_PAY,
                        PaymentMethod.UNION_PAY,
                        ErrorCode.FAILED
                    ),
                    message = "Union Pay failed."
                )
            )

            "cancel" -> ElepayResult.Canceled(paymentId)

            else -> ElepayResult.Failed(
                paymentId,
                ElepayError.PaymentFailure(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.UNION_PAY,
                        PaymentMethod.UNION_PAY,
                        ErrorCode.FAILED
                    ),
                    message = "union pay failed. $resultStr"
                )
            )
        }

        Handler(Looper.getMainLooper()).postDelayed({
            ElepayResultHandlerManager.notifyResult(elepayRes, paymentId)
            finish()
        }, 100)
    }
}