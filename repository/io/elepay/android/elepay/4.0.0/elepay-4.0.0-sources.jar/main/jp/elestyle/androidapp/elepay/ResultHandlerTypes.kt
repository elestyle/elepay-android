package jp.elestyle.androidapp.elepay

import androidx.annotation.Keep

// --- elepay result handler

/**
 * Result handler type for the payment processing.
 *
 * Just a typealias for a simple lambda expression.
 * For Kotlin project and Java project which can support Java 8 lambda expression,
 * this type is preferred.
 */
typealias ElepayResultHandler = (ElepayResult) -> Unit

/**
 * Functional interface for notifying Elepay result.
 */
@Keep
fun interface ElepayResultListener {
    /**
     * Called when the payment is finished processing.
     *
     * @param result The result contains the detail information. Please refer to [ElepayResult] for the details.
     */
    fun onElepayResult(result: ElepayResult)
}

// --- Google Pay Ready to Use result handler

@Keep
/**
 * Functional interface for notifying result.
 */
fun interface IsGooglePayReadyToUseListener {
    /**
     * Notify the result of checking if Google Pay is ready to use.
     */
    fun onFinishCheckingIsGooglePayReadyToUse(result: Boolean)
}