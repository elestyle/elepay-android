package jp.elestyle.androidapp.elepay.processor.creditcard

import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.CreditCardInfo

internal interface CreditCardProcessor {

    suspend fun processCard(card: CreditCardInfo): ElepayResult

    fun cancelProcessing()
}