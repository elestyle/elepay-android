package jp.elestyle.androidapp.elepay.data

import androidx.annotation.Keep
import androidx.annotation.RestrictTo

/**
 * Supported payment method.
 *
 * @suppress
 */
@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
enum class PaymentMethod(val rawValue: String) {
    WECHAT_PAY("wechatpay"),
    ALIPAY("alipay"),
    CREDIT_CARD("creditcard"),
    UNION_PAY("unionpay"),
    PAYPAL("paypal"),
    GOOGLE_PAY("googlepay"),
    LINE_PAY("linepay"),
    PAYPAY("paypay"),
    PAIDY("paidy"),
    MERPAY("merpay"),
    AMAZON_PAY("amazonpay"),
    DOCOMO_PAY("docomopay"),
    ATONE("atone"),
    AUPAY("aupay"),
    RAKUTEN_PAY("rakutenpay"),
    JCOINPAY("jcoinpay"),
    ALIPAY_HK("alipayhk"),
    KAKAO_PAY("kakaopay"),
    EZLINK("ezlink"),
    TNG("tng"),
    GCASH("gcash"),
    DANA("dana"),
    TRUEMONEY("truemoney"),
    RABBITLINEPAY("rabbitlinepay"),
    BPI("bpi"),
    BOOST("boost"),
    HELLOMONEY("hellomoney"),
    TOSS_PAY("tosspay"),
    NAVAR_PAY("navarpay"),
    AEON_PAY("aeonpay"),
    PXPAY("pxpay"),
    WEB_BROWSER_PAY("webbrowserpay"),
    ;

    @Keep
    companion object {
        /**
         * Try to parse the given string to a concrete [PaymentMethod] instance.
         * @return A valid [PaymentMethod] instance or `null` if parsing failed.
         */
        fun from(string: String): PaymentMethod? = when (string.lowercase()) {
            "wechat pay", "wechatpay", "wx", "wechat" -> WECHAT_PAY
            "alipay" -> ALIPAY
            "credit card", "creditcard" -> CREDIT_CARD
            "union pay", "unionpay" -> UNION_PAY
            "paypal" -> PAYPAL
            "google pay", "googlepay" -> GOOGLE_PAY
            "linepay", "line" -> LINE_PAY
            "paidy" -> PAIDY
            "paypay", "pay-pay" -> PAYPAY
            "merpay" -> MERPAY
            "amazonpay", "amazon" -> AMAZON_PAY
            "docomopay" -> DOCOMO_PAY
            "atone" -> ATONE
            "aupay" -> AUPAY
            "rakutenpay" -> RAKUTEN_PAY
            "jcoinpay" -> JCOINPAY
            "alipayhk" -> ALIPAY_HK
            "kakaopay" -> KAKAO_PAY
            "ezlink" -> EZLINK
            "tng" -> TNG
            "gcash" -> GCASH
            "dana" -> DANA
            "truemoney" -> TRUEMONEY
            "rabbitlinepay" -> RABBITLINEPAY
            "bpi" -> BPI
            "boost" -> BOOST
            "hellomoney" -> HELLOMONEY
            "tosspay" -> TOSS_PAY
            "navarpay" -> NAVAR_PAY
            "aeonpay" -> AEON_PAY
            "pxpay" -> PXPAY
            "webbrowserpay" -> WEB_BROWSER_PAY
            else -> null
        }
    }

    val asErrorCodeBlock: String
        get() = when (this) {
            WECHAT_PAY -> "001"
            ALIPAY -> "002"
            CREDIT_CARD -> "004"
            UNION_PAY -> "009"
            PAYPAL -> "011"
            GOOGLE_PAY -> "012"
            LINE_PAY -> "013"
            PAIDY -> "015"
            PAYPAY -> "016"
            MERPAY -> "017"
            AMAZON_PAY -> "018"
            DOCOMO_PAY -> "019"
            ATONE -> "020"
            AUPAY -> "021"
            RAKUTEN_PAY -> "022"
            JCOINPAY -> "023"
            ALIPAY_HK -> "024"
            KAKAO_PAY -> "025"
            EZLINK -> "026"
            TNG -> "027"
            GCASH -> "028"
            DANA -> "029"
            TRUEMONEY -> "030"
            RABBITLINEPAY -> "031"
            BPI -> "032"
            BOOST -> "033"
            HELLOMONEY -> "034"
            TOSS_PAY -> "035"
            NAVAR_PAY -> "036"
            AEON_PAY -> "037"
            PXPAY -> "038"
            WEB_BROWSER_PAY -> "999"
        }
}
