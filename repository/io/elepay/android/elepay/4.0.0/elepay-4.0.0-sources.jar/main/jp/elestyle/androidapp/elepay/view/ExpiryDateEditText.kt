package jp.elestyle.androidapp.elepay.view

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import com.google.android.material.textfield.TextInputEditText
import kotlin.math.max
import kotlin.math.min

internal class ExpirationDate(val month: Int, val year: Int)

private class ExpiryDateFormattedResult(
    val dateString: String,
    val overflowedInput: String,
    val adjustedCount: Int
)

internal class ExpiryDateEditText : TextInputEditText {
    private val maxDateStringLengthWithoutDivider = 4

    private var isFormattingNumber = false

    /**
     * Special flag for method `acceptInput()`.
     * We still want to trigger the text-formatting-mechanism when that method is called but may
     * need to treat the input specially.
     */
    private var isExternalInput = false

    interface StateListener {
        fun onCreditCardExpiryDateCleanedUp()
        fun onEditCreditCardExpiryDate(digit: Int)
        fun onCreditCardExpiryDateFinishedEditing(month: Int, year: Int, extraInput: String)
        fun onClearCreditCardExpiryDateErrors()
    }

    var stateListener: StateListener? = null

    val date: ExpirationDate? get() = parseExpirationDate(text.toString())

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    override fun onFinishInflate() {
        super.onFinishInflate()

        setup()
    }

    fun acceptInput(input: String) {
        isExternalInput = true
        setText(input)
    }

    private fun setup() {
        attachTextChangeListener()
        setOnEditorActionListener { _, actionId, _ ->
            when (actionId) {
                EditorInfo.IME_ACTION_NEXT, EditorInfo.IME_ACTION_DONE -> {
                    val input = date ?: ExpirationDate(-1, -1)
                    stateListener?.onCreditCardExpiryDateFinishedEditing(
                        input.month,
                        input.year,
                        ""
                    )
                    true
                }
                else -> false
            }
        }
        setOnKeyListener { _, _, event ->
            if (text != null
                && text.toString().isEmpty()
                && event.keyCode == KeyEvent.KEYCODE_DEL
                && event.action == KeyEvent.ACTION_DOWN
            ) {
                stateListener?.onCreditCardExpiryDateCleanedUp()
                true
            } else false
        }
    }

    private fun attachTextChangeListener() {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s == null) return
                if (isFormattingNumber) return

                // Just in case user got some way to input more than 1 char at one time.
                val target = if (s.length > 5) s.substring(0, 6) else s

                val formattedResult = formatExpiryDate(target.toString(), isDeleting = count == 0)
                val newPosition = max(
                    0,
                    min(
                        start + formattedResult.adjustedCount + count,
                        formattedResult.dateString.length
                    )
                )

                // Feedback the current state to listener.
                checkToNotifyStateUpdating(formattedResult, newPosition, editingStartPos = start)

                isFormattingNumber = true
                setText(formattedResult.dateString)
                setSelection(newPosition)
                isFormattingNumber = false

                // Clean up the special flag after all changes are handled.
                isExternalInput = false
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun formatExpiryDate(date: String, isDeleting: Boolean): ExpiryDateFormattedResult {
        if (date.isEmpty()) return ExpiryDateFormattedResult(date, "", 0)

        var inserted = 0
        val (stripped, reduced) = stripDate(date, isDeleting)

        val ret = StringBuilder()

        if (shouldAddZeroPrefix(stripped)) {
            inserted += 1
            ret.append("0")
            ret.append(
                stripped.substring(
                    0,
                    min(stripped.length, maxDateStringLengthWithoutDivider - 1)
                )
            )
        } else if (isDeleting && !date.contains("/") && date.length > 2) {
            // Handle a special case: we deleted the "/" character.
            // We can detect this situation by checking the "isDeleting" flag,
            // along with the raw `date` string.
            // What we do here is jut skip the character before the "/", that's what the user
            // expected, since the "/" is just a placeholder.
            ret.append(stripped.first())
            ret.append(
                stripped.substring(2, min(stripped.length, maxDateStringLengthWithoutDivider))
            )
        } else {
            ret.append(
                stripped.substring(0, min(stripped.length, maxDateStringLengthWithoutDivider))
            )
        }

        if (ret.length > 2) {
            inserted += 1
            ret.insert(2, "/")
        }

        val overflowed =
            if (stripped.length > maxDateStringLengthWithoutDivider)
                stripped.substring(maxDateStringLengthWithoutDivider)
            else ""

        return ExpiryDateFormattedResult(
            dateString = ret.toString(),
            overflowedInput = overflowed,
            adjustedCount = inserted - reduced
        )
    }

    private fun parseExpirationDate(dateStr: String): ExpirationDate? {
        val dateComponents = dateStr.split("/")
        if (dateComponents.count() != 2) return null
        val month = try {
            dateComponents.first().toInt()
        } catch (e: Exception) {
            return null
        }
        val year = try {
            dateComponents.last().toInt()
        } catch (e: Exception) {
            return null
        }

        return ExpirationDate(month, year)
    }

    /**
     * Try to strip the date string. e.g. "12/23" -> "1223"
     * @return The stripped string and number of characters that has been removed, which could be
     * either 1 or 0
     */
    private fun stripDate(date: String, isDeleting: Boolean): Pair<String, Int> =
        if (date.length >= 3) {
            // To make sure the reduced count is calculated correctly,
            // Consider the following situation:
            //  1. "12" -> "123", the raw `date` has already changed to "123" so we go here but
            //  should not count reduced char since we're inserting.
            //  2. "12/23" -> "1223", although we just deleted the "/", it's still a reducing and
            //  will be balanced by the last "/" insertion.
            //  3. other cases, it's ok to not counting the recuded char.
            val reduced = if (date.contains("/")) 1 else if (isDeleting) 1 else 0
            val stripped = date.replace("/", "")

            Pair(stripped, reduced)
        } else Pair(date, 0)

    private fun checkToNotifyStateUpdating(
        formattedResult: ExpiryDateFormattedResult,
        newPosition: Int,
        editingStartPos: Int
    ) {
        when (formattedResult.dateString.length) {
            0 -> {
                // Do not trigger clean up callback when this is a external passed-in data.
                if (!isExternalInput) {
                    stateListener?.onCreditCardExpiryDateCleanedUp()
                }
            }

            5 -> {
                parseExpirationDate(formattedResult.dateString)?.run {
                    stateListener?.onCreditCardExpiryDateFinishedEditing(
                        month,
                        year,
                        formattedResult.overflowedInput
                    )
                }
            }
        }
        // Only trigger the clear error action when this is just a normal editing.
        if (formattedResult.dateString.length != 5) {
            error = null
            stateListener?.onClearCreditCardExpiryDateErrors()
        }

        val digit = if (newPosition > 2) {
            if (editingStartPos >= 5 && formattedResult.dateString.length in 5..editingStartPos) {
                // When user has already finished the last digit input, but manually moved the
                // cursor back to the last digit, trigger the callback with an invalid value.
                -1
            } else {
                newPosition - 1
            }
        } else newPosition
        stateListener?.onEditCreditCardExpiryDate(digit)

    }

    /**
     * Check if it's necessary to add a "0" prefix to the given date string.
     */
    private fun shouldAddZeroPrefix(date: String): Boolean {
        val firstDigit = Character.getNumericValue(date.first())
        val firstTwoDigits = if (date.length >= 2) date.substring(0, 2).toInt() else null
        return (firstDigit > 1 || (firstTwoDigits != null && firstTwoDigits > 12))
    }
}
