package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.IntegrationChecker
import org.json.JSONException
import org.json.JSONObject

internal object KsherProcessor : ElepayProcessor() {
    private var wechatKey: String = ""

    override fun setup(providerConfig: ElepayProviderConfig) {
        super.setup(providerConfig)
        if (providerConfig is ElepayProviderConfig.Ksher) {
            wechatKey = providerConfig.wechatKey
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else when (chargeData.method) {

            PaymentMethod.ALIPAY -> processAlipay(chargeData, fromActivity, resultHandler)

            PaymentMethod.WECHAT_PAY -> processWechatPay(chargeData, fromActivity, resultHandler)

            else -> {
                val failure = ElepayResult.Failed(
                    chargeData.id,
                    ElepayError.UnsupportedPaymentMethod(
                        "${PaymentMethodProvider.KSHER.rawValue} ${chargeData.method.rawValue}"
                    )
                )
                resultHandler?.invoke(failure)
                false
            }
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    private fun processAlipay(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (!IntegrationChecker.isAlipayAvailable()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.id,
                    error = ElepayError.UninitializedPaymentMethod(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            null,
                            null,
                            ErrorCode.UNINIT
                        ),
                        paymentMethod = PaymentMethod.ALIPAY.rawValue,
                        message = "Have you installed Alipay sdk to your project?"
                    )
                ),
                handler = resultHandler
            )
            false
        } else if (chargeData.payload.isNullOrEmpty()) {
            postElepayResult(
                ElepayResult.Failed(
                    chargeData.id, ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.KSHER,
                            PaymentMethod.ALIPAY,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "charge error"
                    )
                ),
                resultHandler
            )
            false
        } else AlipayPerformer.pay(
            paymentId = chargeData.id,
            payload = chargeData.payload,
            fromActivity = fromActivity,
            resultHandler = resultHandler
        )


    private fun processWechatPay(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (wechatKey.isEmpty()) {
            val failure = ElepayResult.Failed(
                paymentId = chargeData.id,
                error = ElepayError.UninitializedPaymentMethod(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        null,
                        null,
                        ErrorCode.UNINIT
                    ),
                    paymentMethod = PaymentMethod.WECHAT_PAY.rawValue,
                    message = "Ksher: Wechat Pay is not configured. Please contact elepay for support."
                )
            )
            postElepayResult(failure, resultHandler)
            return false
        }

        if (!IntegrationChecker.isWechatPayAvailable()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.id,
                    error = ElepayError.UninitializedPaymentMethod(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            null,
                            null,
                            ErrorCode.UNINIT
                        ),
                        paymentMethod = PaymentMethod.ALIPAY.rawValue,
                        message = "Have you installed Wechat Pay sdk to your project?"
                    )
                ),
                handler = resultHandler
            )
            return false
        }

        if (chargeData.payload.isNullOrEmpty()) {
            postElepayResult(
                ElepayResult.Failed(
                    chargeData.id, ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.KSHER,
                            PaymentMethod.WECHAT_PAY,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "charge error"
                    )
                ),
                resultHandler
            )
            return false
        }

        val data = try {
            JSONObject(chargeData.payload)
        } catch (e: JSONException) {
            val failure = ElepayResult.Failed(
                chargeData.id,
                ElepayError.InvalidPayload(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.WECHAT_PAY,
                        PaymentMethod.WECHAT_PAY,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    message = chargeData.payload
                )
            )
            postElepayResult(failure, resultHandler)
            return false
        }

        val info = WechatPayPerformer.PaymentInfo(
            apiKey = wechatKey,
            paymentId = chargeData.id,
            provider = PaymentMethodProvider.KSHER,
            paymentData = data
        )
        return WechatPayPerformer.pay(info, fromActivity, resultHandler)
    }
}