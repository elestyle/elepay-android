package jp.elestyle.androidapp.elepay.utils

import android.content.Context
import android.os.Build
import jp.elestyle.androidapp.elepay.core.encryptor.SecuredDataStore
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.core.encryptor.ContentConverter
import jp.elestyle.androidapp.elepay.core.log
import org.json.JSONArray
import org.json.JSONObject

/**
 * RC for Risk Control
 */
internal object RCManager {

    private enum class TaskIdentity {
        DEVICE_INFO, BATTERY, IP, LOCATION, APP_INFO;

        val asResultKey: String
            get() = when (this) {
                DEVICE_INFO -> "device"
                BATTERY -> "battery"
                IP -> "ip"
                LOCATION -> "locations"
                APP_INFO -> "hostApp"
            }
    }

    suspend fun verifyPayment(paymentCommon: PaymentCommon, context: Context) {
        val result = JSONObject()
        val jsonMeta = JSONObject()

        // Device Info
        val jsonDeviceIds = JSONObject()
        val deviceRelatedIds = DeviceUtil.getDeviceRelatedIds(context)
        for (entry in deviceRelatedIds) {
            jsonDeviceIds.put(entry.key.name, entry.value)
        }
        val hardwareAddrs = NetworkUtil.collectHardwareAddresses()
        jsonDeviceIds.put("net_hw_addrs", JSONObject(hardwareAddrs))
        for (entry in DeviceUtil.deviceInfo) {
            jsonDeviceIds.put(entry.key, entry.value)
        }
        result.put(TaskIdentity.DEVICE_INFO.asResultKey, jsonDeviceIds)

        // Battery
        val jsonBattery = JSONObject()
        for (entry in DeviceUtil.getBatteryInfo(context)) {
            jsonBattery.put(entry.key, entry.value)
        }
        result.put(TaskIdentity.BATTERY.asResultKey, jsonBattery)

        // IP address
        val addressesMap = NetworkUtil.collectIPAddresses()
        jsonMeta.put(TaskIdentity.IP.asResultKey, JSONObject(addressesMap))

        // App Info
        val hostAppInfo = SystemUtil.getHostAppInfo(context)
        jsonMeta.put(TaskIdentity.APP_INFO.asResultKey, JSONObject(hostAppInfo))

        // Location
        when (val locatingResult = Locator.startLocating(context, 20)) {
            is LocatingResult.UpdatedLocation -> {
                log("RCManager", "${locatingResult.location}")
                val jsonLocation = JSONObject(
                    mapOf(
                        "altitude" to locatingResult.location.altitude,
                        "latitude" to locatingResult.location.latitude,
                        "longitude" to locatingResult.location.longitude,
                        "accuracy" to locatingResult.location.accuracy,
                        "speed" to locatingResult.location.speed,
                        "bearing" to locatingResult.location.bearing,
                        "time" to locatingResult.location.time
                    )
                )
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O) {
                    jsonLocation.put(
                        "verticalAccuracyMeters",
                        locatingResult.location.verticalAccuracyMeters
                    )
                }

                val jsonLocations = JSONArray()
                jsonLocations.put(jsonLocation)
                jsonMeta.put(TaskIdentity.LOCATION.asResultKey, jsonLocations)
            }
            // Ignore all errors.
            is LocatingResult.Timeout,
            is LocatingResult.NoValidLocationProvider,
            is LocatingResult.PermissionDenied -> {
                log("RCManager", "$locatingResult")
                jsonMeta.put(TaskIdentity.LOCATION.asResultKey, JSONArray())
            }
        }

        // Final result
        result.put("type", "android")
        result.put("meta", jsonMeta)
        val key = SecuredDataStore.retrieveKey()
        val encrypted = ContentConverter.encrypt(result.toString(), key)
        upload(paymentCommon, encrypted)
    }

    private suspend fun upload(paymentCommon: PaymentCommon, data: String) {
        when (paymentCommon.dataType) {
            PaymentDataType.CHARGE -> ServerAPIClient.verifyCharge(
                paymentId = paymentCommon.id,
                data = data
            )

            PaymentDataType.SOURCE -> ServerAPIClient.verifySource(
                sourceId = paymentCommon.id,
                data = data
            )

            PaymentDataType.CHECKOUT -> {
                // There's no API for checkout verify currently.
            }
        }
    }
}