package jp.elestyle.androidapp.elepay.utils.creditcard

import jp.elestyle.androidapp.elepay.processor.creditcard.CreditCardProcessor

internal object CreditCardProcessingCenter {
    private val processors: MutableMap<String, CreditCardProcessor> = mutableMapOf()

    operator fun get(key: String): CreditCardProcessor? = synchronized(this) {
        processors[key]
    }

    operator fun set(key: String, processor: CreditCardProcessor) = synchronized(this) {
        processors[key] = processor
    }

    fun removeProcessor(key: String) {
        synchronized(this) {
            processors.remove(key)
        }
    }
}