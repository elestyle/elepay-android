package jp.elestyle.androidapp.elepay.data

internal enum class PaymentDataType {
    CHARGE,
    SOURCE,
    CHECKOUT,
    ;

    val stringPresentation: String
        get() = when (this) {
            CHARGE -> "charge"
            SOURCE -> "source"
            CHECKOUT -> "checkout"
        }
}