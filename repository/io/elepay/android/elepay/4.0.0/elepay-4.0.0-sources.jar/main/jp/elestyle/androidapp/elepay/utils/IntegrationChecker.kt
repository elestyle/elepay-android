package jp.elestyle.androidapp.elepay.utils

internal object IntegrationChecker {
    fun isAlipayAvailable(): Boolean =
        try {
            Class.forName("com.alipay.sdk.app.PayTask")
            true
        } catch (e: Exception) {
            false
        }

    fun isWechatPayAvailable(): Boolean =
        try {
            Class.forName("com.tencent.mm.opensdk.modelpay.PayReq")
            Class.forName("com.tencent.mm.opensdk.openapi.WXAPIFactory")
            true
        } catch (e: Exception) {
            false
        }

    fun isAvailable(className: String): Boolean {
        return try {
            Class.forName(className)
            true
        } catch (e: Exception) {
            false
        }
    }
}