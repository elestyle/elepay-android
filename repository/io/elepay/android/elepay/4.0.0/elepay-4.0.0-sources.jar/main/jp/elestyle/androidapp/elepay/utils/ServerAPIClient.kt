package jp.elestyle.androidapp.elepay.utils

import android.util.Base64
import androidx.annotation.Keep
import androidx.annotation.RestrictTo
import jp.elestyle.androidapp.elepay.BuildConfig
import jp.elestyle.androidapp.elepay.data.APIResult
import jp.elestyle.androidapp.elepay.data.ExecuteResult
import jp.elestyle.androidapp.elepay.data.RequestError
import jp.elestyle.androidapp.elepay.data.ResultType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

internal object ServerAPIClient {
    private val applicationJsonContentTypeHeaders: Map<String, String> = mapOf(
        "Content-Type" to "application/json; charset=utf-8",
        "Accept" to "application/json"
    )

    suspend fun retrieveConfigs(): APIResult = withContext(Dispatchers.IO) {
        ApiRequester.get(
            "${ConfigManager.apiBaseUrl}/config/providers",
            headers = fetchCommonHeaders()
        )
    }

    suspend fun capture(paymentId: String, token: String) =
        capture(paymentId, token, "")

    suspend fun capture(paymentId: String, token: String, threeDSecureId: String) =
        withContext(Dispatchers.IO) {
            val credential = JSONObject().apply {
                put("token", token)
                if (threeDSecureId.isNotEmpty()) {
                    put("threeDSecureId", threeDSecureId)
                }
            }
            val params = JSONObject().apply {
                put("extra", credential)
            }

            ApiRequester.post(
                url = "${ConfigManager.apiBaseUrl}/charges/$paymentId/capture",
                headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
                bodyData = ApiPostRequestBody.JsonObject(params)
            )
        }

    /**
     * Execute a charge with the given token. Used for payment flows that may require
     * additional steps like 3DS verification.
     *
     * @param chargeId      The charge ID to execute.
     * @param token         The payment token (e.g. Google Pay token).
     * @param repaymentType Installment type. "1" = single payment (一括払い), no installment.
     * @return [ExecuteResult] containing the charge status and an optional redirect URL
     *         for 3DS verification.
     */
    suspend fun execute(chargeId: String, token: String, repaymentType: String = "1"): ResultType<ExecuteResult, RequestError> =
        withContext(Dispatchers.IO) {
            val params = JSONObject().apply {
                put("extra", JSONObject().apply {
                    put("token", token)
                    put("repaymentType", repaymentType)
                })
            }
            val apiResult = ApiRequester.post(
                url = "${ConfigManager.apiBaseUrl}/charges/$chargeId/execute",
                headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
                bodyData = ApiPostRequestBody.JsonObject(params)
            )
            when (apiResult) {
                is ResultType.Succeeded -> {
                    val json = apiResult.data
                    ResultType.Succeeded(
                        ExecuteResult(
                            status = json.optString("status", ""),
                            redirectUrl = if (json.isNull("redirectUrl")) null
                                else json.optString("redirectUrl", "").ifEmpty { null }
                        )
                    )
                }
                is ResultType.Failed -> ResultType.Failed(apiResult.error)
            }
        }

    suspend fun confirm(sourceId: String, token: String) = withContext(Dispatchers.IO) {
        val credential = JSONObject().apply {
            put("token", token)
        }
        val params = JSONObject().apply {
            put("extra", credential)
        }
        ApiRequester.post(
            url = "${ConfigManager.apiBaseUrl}/sources/$sourceId/confirm",
            headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
            bodyData = ApiPostRequestBody.JsonObject(params)
        )
    }

    suspend fun verifyCharge(paymentId: String, data: String) {
        verify("${ConfigManager.apiBaseUrl}/charges/$paymentId/verify", data)
    }

    suspend fun verifySource(sourceId: String, data: String) {
        verify("${ConfigManager.apiBaseUrl}/sources/$sourceId/verify", data)
    }

    private suspend fun verify(url: String, data: String) = withContext(Dispatchers.IO) {
        val params = JSONObject().apply {
            put("metadata", JSONObject().apply {
                put("credential", data)
            })
        }
        ApiRequester.post(
            url,
            headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
            bodyData = ApiPostRequestBody.JsonObject(params)
        )
    }

    suspend fun report(errors: List<String>) = withContext(Dispatchers.IO) {
        val params = JSONObject().apply {
            put("reports", JSONArray().apply {
                errors.forEach { put(it) }
            })
        }
        ApiRequester.post(
            url = "${ConfigManager.apiBaseUrl}/sdk-reports",
            headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
            bodyData = ApiPostRequestBody.JsonObject(params)
        )
    }

    suspend fun retrieveCheckout(code: String, domain: String) = withContext(Dispatchers.IO) {
        val header = mapOf(
            "origin" to domain
        )
        ApiRequester.get(url = "${ConfigManager.apiBaseUrl}/codes-checkout/$code", headers = header)
    }

    suspend fun retrieveCheckoutSetting(pkey: String) = withContext(Dispatchers.IO) {
        ApiRequester.get(
            url = "${ConfigManager.apiBaseUrl}/config/app-code-setting",
            headers = fetchCommonHeaders(pkey)
        )
    }

    suspend fun retrievePaymentMethodResourceInfo() = withContext(Dispatchers.IO) {
        ApiRequester.get(
            url = "https://resource.elecdn.com/payment-methods/info.json",
            headers = fetchCommonHeaders()
        )
    }

    suspend fun createChargeForCheckout(
        codeId: String,
        pKey: String,
        paymentMethod: String,
        resource: String
    ) = withContext(Dispatchers.IO) {
        val params = JSONObject().apply {
            put("paymentMethod", paymentMethod)
            put("resource", resource)
        }
        ApiRequester.post(
            url = "${ConfigManager.apiBaseUrl}/codes/$codeId/charge",
            headers = fetchCommonHeaders(pKey),
            bodyData = ApiPostRequestBody.JsonObject(params)
        )
    }

    suspend fun chargeStatus(chargeId: String) = withContext(Dispatchers.IO) {
        ApiRequester.get(
            url = "${ConfigManager.apiBaseUrl}/charges/$chargeId/status",
            headers = fetchCommonHeaders()
        )
    }

    suspend fun sourceStatus(sourceId: String) = withContext(Dispatchers.IO) {
        ApiRequester.get(
            url = "${ConfigManager.apiBaseUrl}/sources/$sourceId/status",
            headers = fetchCommonHeaders()
        )
    }

    fun fetchCommonHeaders(): Map<String, String> =
        fetchCommonHeaders(ConfigManager.appKey)

    fun fetchCommonHeaders(pKey: String): Map<String, String> {
        // Uses http basic authorization, which in format of "username:password",
        // "username" is the `apiKey`, and we leave "password" empty.
        val basicAuth = "Basic " +
                Base64.encode("$pKey:".toByteArray(), Base64.NO_WRAP).toString(Charsets.UTF_8)
        return mapOf(
            "Authorization" to basicAuth,
            "elepay-api-version" to ApiVersion.versionCode,
            "elepay-sdk-source" to "android",
            "elepay-sdk-version" to BuildConfig.LIB_VERSION_CODE,
        )
    }
}

/**
 * @suppress
 */
@Keep
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
object InnerServerAPIClientWrap {

    @Keep
    class InnerException(val code: String, message: String) : Exception(message)

    fun get(url: String): Result<JSONObject> =
        get(url, headers = mapOf())

    fun get(
        url: String,
        headers: Map<String, String>,
    ): Result<JSONObject> = get(url, headers, params = mapOf())

    fun get(
        url: String,
        headers: Map<String, String>,
        params: Map<String, Any>,
    ): Result<JSONObject> = get(url, headers, params, appendElepayHeader = true)

    fun get(
        url: String,
        headers: Map<String, String>,
        params: Map<String, Any>,
        appendElepayHeader: Boolean,
    ): Result<JSONObject> {
        // Avoid Kotlin default-argument bridge methods across separately minified modules.
        val transformHeaders = headers + if (appendElepayHeader) ServerAPIClient.fetchCommonHeaders() else mapOf()
        return transform(ApiRequester.get(url, transformHeaders, params))
    }


    fun post(
        url: String,
        json: JSONObject,
    ): Result<JSONObject> = post(url, headers = mapOf(), json = json)

    fun post(
        url: String,
        headers: Map<String, String>,
        json: JSONObject,
    ): Result<JSONObject> = post(url, headers, json, appendElepayHeader = true)

    fun post(
        url: String,
        headers: Map<String, String>,
        json: JSONObject,
        appendElepayHeader: Boolean,
    ): Result<JSONObject> {
        val transformHeaders = headers + if (appendElepayHeader) ServerAPIClient.fetchCommonHeaders() else mapOf()
        return transform(ApiRequester.post(url, transformHeaders, ApiPostRequestBody.JsonObject(json)))
    }

    fun fetchCommonHeaders(): Map<String, String> =
        fetchCommonHeaders(ConfigManager.appKey)

    fun fetchCommonHeaders(pKey: String): Map<String, String> =
        ServerAPIClient.fetchCommonHeaders(pKey)

    private fun transform(apiResult: APIResult): Result<JSONObject> =
        when (apiResult) {
            is ResultType.Succeeded -> Result.success(apiResult.data)
            is ResultType.Failed -> Result.failure(
                InnerException(
                    apiResult.error.code,
                    "${apiResult.error.message}${apiResult.error.extra}"
                )
            )
        }
}
