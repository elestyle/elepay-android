package jp.elestyle.androidapp.elepay.processor.creditcard

import androidx.activity.ComponentActivity
import com.stripe.android.PaymentConfiguration
import com.stripe.android.model.ConfirmPaymentIntentParams
import com.stripe.android.model.ConfirmSetupIntentParams
import com.stripe.android.model.PaymentMethodCreateParams
import com.stripe.android.payments.paymentlauncher.PaymentLauncher
import com.stripe.android.payments.paymentlauncher.PaymentResult
import com.stripe.android.stripecardscan.cardscan.CardScanSheet
import com.stripe.android.stripecardscan.cardscan.CardScanSheetResult
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.CreditCardInfo
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.IntegrationChecker
import jp.elestyle.androidapp.elepay.utils.ServerStatusPoller
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Handles stripe "intent" related processing.
 * Currently handles the "payment intent"(as the old token charge) and the "setup intent"(as the
 * old source) processing.
 */
internal class StripeIntentCreditCardProcessor(
    private val stripePublishableKey: String,
    private val clientSecret: String,
    private val paymentData: PaymentCommon,
) : NumberScannableCreditCardProcessor {

    override val isCardScanAvailable =
        IntegrationChecker.isAvailable("com.stripe.android.stripecardscan.cardscan.CardScanSheet")

    private var paymentLauncher: PaymentLauncher? = null
    private var continuation: CancellableContinuation<ElepayResult>? = null
    private var cardScanSheet: CardScanSheet? = null
    private var cardScanContinuation: CancellableContinuation<CreditCardInfo?>? = null
    private val bgScope = CoroutineScope(Dispatchers.IO)

    override fun onHostActivityCreate(hostActivity: ComponentActivity) {
        PaymentConfiguration.init(hostActivity, stripePublishableKey)

        if (isCardScanAvailable) {
            cardScanSheet = CardScanSheet.create(
                hostActivity,
                cardScanSheetResultCallback = { result ->
                    val continuation = cardScanContinuation ?: return@create
                    when (result) {
                        is CardScanSheetResult.Completed -> {
                            val number = result.scannedCard.pan
                            continuation.resume(CreditCardInfo(number, 0, 0, ""))
                        }

                        is CardScanSheetResult.Failed, is CardScanSheetResult.Canceled -> {
                            continuation.resume(null)
                        }
                    }

                    cardScanContinuation = null
                })
        }

        paymentLauncher = PaymentLauncher.Companion.create(
            hostActivity,
            stripePublishableKey,
            null
        ) { paymentResult ->
            when (paymentResult) {
                is PaymentResult.Completed -> {
                    val retryPolicy = ServerStatusPoller.PollPolicy(
                        // According to the server guy's advice, the valid "status" for capturing
                        // actually varies in many different ways. e.g. an "in-captured" status
                        // may indicate a successful state. So just check if it's not "pending"
                        // is good enough here.
                        statusValidating = { status -> status != "pending" },
                        intervalMillis = 1000L,
                        maxPollingCount = 10,
                        extraFailureMessage = "Stripe Intent Credit Card"
                    )
                    bgScope.launch {
                        notifyResult(ServerStatusPoller.poll(paymentData, retryPolicy))
                    }
                }

                is PaymentResult.Canceled ->
                    notifyResult(ElepayResult.Canceled(paymentData.id))

                is PaymentResult.Failed -> {
                    val failure = ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            paymentData.provider,
                            paymentData.method,
                            ErrorCode.FAILED_CAPTURE
                        ),
                        message = "Failed confirming stripe payment-intent. Response: ${paymentResult.throwable.localizedMessage}"
                    )
                    notifyResult(ElepayResult.Failed(paymentData.id, failure))
                }
            }
        }
    }

    override fun onHostActivityDestroy(hostActivity: ComponentActivity) {
        paymentLauncher = null
        continuation?.cancel()
        continuation = null
        cardScanContinuation?.cancel()
        cardScanContinuation = null
    }

    override suspend fun processCard(card: CreditCardInfo): ElepayResult =
        when (paymentData.dataType) {
            PaymentDataType.CHARGE -> processPaymentIntent(card)

            PaymentDataType.SOURCE -> processSetupIntent(card)

            PaymentDataType.CHECKOUT ->
                ElepayResult.Failed(
                    paymentData.id,
                    ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            paymentData.provider,
                            paymentData.method,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "CHECKOUT data should not pass to stripe processing."
                    )
                )
        }

    override fun cancelProcessing() {}

    override suspend fun scanCreditCard(hostActivity: ComponentActivity): CreditCardInfo? =
        suspendCancellableCoroutine { cont ->
            cardScanContinuation?.cancel()
            cardScanContinuation = cont

            cardScanSheet?.present()
        }

    private suspend fun processPaymentIntent(card: CreditCardInfo): ElepayResult {
        val confirmParams = ConfirmPaymentIntentParams.createWithPaymentMethodCreateParams(
            PaymentMethodCreateParams.createCard(card.asStripeCardParams()),
            clientSecret,
        )

        return suspendCancellableCoroutine { cont ->
            continuation = cont
            paymentLauncher?.confirm(confirmParams)
        }
    }

    private suspend fun processSetupIntent(card: CreditCardInfo): ElepayResult {
        val confirmParams = ConfirmSetupIntentParams.create(
            PaymentMethodCreateParams.createCard(card.asStripeCardParams()),
            clientSecret
        )
        return suspendCancellableCoroutine { cont ->
            continuation = cont
            paymentLauncher?.confirm(confirmParams)
        }
    }

    private fun notifyResult(elepayResult: ElepayResult) {
        continuation?.resume(elepayResult)
        continuation = null
    }
}
