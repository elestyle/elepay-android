package jp.elestyle.androidapp.elepay.utils

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.os.HandlerThread
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.function.Consumer
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

internal sealed class LocatingResult {
    data class UpdatedLocation(val location: Location) : LocatingResult()
    object Timeout : LocatingResult()
    object NoValidLocationProvider : LocatingResult()
    object PermissionDenied : LocatingResult()
}

internal object Locator {
    @Suppress("unused")
    private const val logTag = "Locator"

    private val handlerThread: HandlerThread =
        HandlerThread("jp.elestyle.android.elepay.Locator.handler_thread")
    private val handler: Handler by lazy {
        handlerThread.start()
        Handler(handlerThread.looper)
    }
    private var locationMgr: LocationManager? = null

    @SuppressLint("MissingPermission")
    suspend fun startLocating(context: Context, timeoutInSecs: Long): LocatingResult {
        if (!PermissionChecker.isPermissionGranted(context, android.Manifest.permission.ACCESS_COARSE_LOCATION)
            || !PermissionChecker.isPermissionGranted(context, android.Manifest.permission.ACCESS_FINE_LOCATION)
        ) {
            return LocatingResult.PermissionDenied
        }


        if (locationMgr == null) {
            locationMgr = ContextCompat.getSystemService(context, LocationManager::class.java)
        }

        val locationProvider = when {
            locationMgr!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            locationMgr!!.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> ""
        }
        if (locationProvider.isEmpty()) {
            return LocatingResult.NoValidLocationProvider
        }

        // This timeout is only used to observe the result.
        // It's also necessary to pass the timeout value to the LocationManager because it's not aware of the
        // coroutine mechanism.
        var ret = withTimeoutOrNull(timeoutInSecs * 1000) {
            locationMgr!!.startLocating(locationProvider, handler, timeoutInSecs)
        }
        if (ret == null) {
            ret = LocatingResult.Timeout
        }
        locationMgr = null
        return ret
    }
}

private suspend fun LocationManager.startLocating(
    locationProvider: String,
    handler: Handler,
    timeoutInSecs: Long
): LocatingResult {
    return suspendCoroutine { cont ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startLocatingAboveAPI30(locationProvider, handler, timeoutInSecs, cont)
        } else {
            startLocatingBelowAPI30(locationProvider, handler, timeoutInSecs, cont)
        }
    }
}

@SuppressLint("MissingPermission")
private fun LocationManager.startLocatingBelowAPI30(
    locationProvider: String,
    handler: Handler,
    timeoutInSecs: Long,
    cont: Continuation<LocatingResult>,
) {
    val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            cont.resume(LocatingResult.UpdatedLocation(location))
        }

        override fun onProviderEnabled(provider: String) {}

        override fun onProviderDisabled(provider: String) {}
    }

    try {
        @Suppress("DEPRECATION")
        requestSingleUpdate(locationProvider, listener, handler.looper)

        // Always post this delayed Runnable to make sure the listener is removed.
        handler.postDelayed({
            removeUpdates(listener)
        }, timeoutInSecs * 1000)
    } catch (e: SecurityException) {
        // Guard for system permission exception.
        cont.resume(LocatingResult.PermissionDenied)
    }
}

@RequiresApi(Build.VERSION_CODES.R)
@SuppressLint("MissingPermission")
private fun LocationManager.startLocatingAboveAPI30(
    locationProvider: String,
    handler: Handler,
    timeoutInSecs: Long,
    cont: Continuation<LocatingResult>,
) {
    try {
        val consumer = Consumer<Location> {
            if (it != null) {
                cont.resume(LocatingResult.UpdatedLocation(it))
            }
        }
        val cancellationSignal = CancellationSignal()
        val threadPoolSize = Runtime.getRuntime().availableProcessors()
        val executor = ThreadPoolExecutor(
            threadPoolSize,
            threadPoolSize,
            timeoutInSecs + 10,
            TimeUnit.SECONDS,
            LinkedBlockingDeque()
        )
        getCurrentLocation(locationProvider, cancellationSignal, executor, consumer)

        // Always post this delayed Runnable to make sure the listener is removed.
        handler.postDelayed({
            cancellationSignal.cancel()
        }, timeoutInSecs * 1000)
    } catch (e: SecurityException) {
        // Guard for system permission exception.
        cont.resume(LocatingResult.PermissionDenied)
    }
}
