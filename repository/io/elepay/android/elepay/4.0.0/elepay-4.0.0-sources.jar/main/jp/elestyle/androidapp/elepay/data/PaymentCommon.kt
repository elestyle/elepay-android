package jp.elestyle.androidapp.elepay.data

import android.os.Build
import android.os.Parcel
import android.os.Parcelable

internal data class PaymentCommon(
    val id: String,
    val provider: PaymentMethodProvider,
    val method: PaymentMethod,
    val dataType: PaymentDataType,
    val testModeData: PaymentTestModeData?
) : Parcelable {
    constructor(parcel: Parcel) : this(
        id = parcel.readString() ?: "",
        provider = PaymentMethodProvider.values()[parcel.readInt()],
        method = PaymentMethod.values()[parcel.readInt()],
        dataType = PaymentDataType.values()[parcel.readInt()],
        testModeData = parcel.readInt().run {
            if (this == 0) null
            else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    parcel.readParcelable(
                        PaymentTestModeData::class.java.classLoader,
                        PaymentTestModeData::class.java
                    )!!
                } else {
                    @Suppress("DEPRECATION")
                    parcel.readParcelable(PaymentTestModeData::class.java.classLoader)
                }
            }
        }
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeInt(provider.ordinal)
        parcel.writeInt(method.ordinal)
        parcel.writeInt(dataType.ordinal)
        if (testModeData != null) {
            parcel.writeInt(1)
            parcel.writeParcelable(testModeData, 0)
        } else {
            parcel.writeInt(0)
        }
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object {
        @Suppress("unused")
        @JvmField
        val CREATOR = object : Parcelable.Creator<PaymentCommon> {
            override fun createFromParcel(parcel: Parcel): PaymentCommon {
                return PaymentCommon(parcel)
            }

            override fun newArray(size: Int): Array<PaymentCommon?> {
                return arrayOfNulls(size)
            }
        }
    }
}