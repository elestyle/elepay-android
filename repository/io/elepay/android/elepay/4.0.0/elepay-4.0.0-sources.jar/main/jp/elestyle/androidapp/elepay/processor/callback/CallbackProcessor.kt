package jp.elestyle.androidapp.elepay.processor.callback

import android.net.Uri
import android.util.Log
import jp.elestyle.androidapp.elepay.Elepay
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.ResultType

internal sealed class CallbackProcessingResult {
    data class InvalidUri(val uri: Uri, val message: String) : CallbackProcessingResult()

    data class Result(val result: CallbackProcessable.ProcessedResult) : CallbackProcessingResult()
}

internal object CallbackProcessor {

    @JvmInline
    private value class ParsingError(val message: String)

    /**
     * Process the given uri.
     *
     * @return an ElepayResult instance if process successfully, or `null` if the uri could not
     * be processed.
     */
    suspend fun processCallbackUri(uri: Uri): CallbackProcessingResult {
        val processor = parseProcessor(uri)
            ?: return CallbackProcessingResult.InvalidUri(uri, "No associated processor")

        return when (val parsingRes = parseProcessableData(uri, processor)) {
            is ResultType.Failed -> {
                CallbackProcessingResult.InvalidUri(uri, parsingRes.error.message)
            }

            is ResultType.Succeeded -> {
                CallbackProcessingResult.Result(processor.continueCallbackProcessing(parsingRes.data))
            }
        }
    }

    private fun parseProcessor(uri: Uri): CallbackProcessable? {
        val provider = PaymentMethodProvider.from(uri.host ?: "") ?: run {
            Log.i("Elepay", "Could not parse the given callback uri. Ignore")
            return null
        }
        val processor = Elepay.retrieveProcessor(provider) as? CallbackProcessable ?: run {
            Log.i("Elepay", "No associated processor for $provider. Ignore")
            return null
        }
        return processor
    }

    private fun parseProcessableData(
        uri: Uri,
        processor: CallbackProcessable
    ): ResultType<CallbackProcessingData, ParsingError> {
        val paymentInfo = processor.retrieveProcessingPaymentInfo(true) ?: run {
            return ResultType.Failed(ParsingError("No payment data found in the processor"))
        }

        if (processor.callbackScheme.isNotEmpty() && uri.scheme != processor.callbackScheme) {
            // If the callback scheme is set, the uri scheme must match.
            // Only check if match when callback scheme is set. because the new added WebBrowserPayProcessor does not have a callback scheme.
            // And we also checking the processId below, which is more accurate.
            return ResultType.Failed(ParsingError("Callback uri scheme ${uri.scheme} does not match processor's ${processor.callbackScheme}"))
        }

        val paymentDataInProcessing = paymentInfo.paymentData
        val paymentId = runCatching {
            uri.getQueryParameter("chargeId") ?: uri.getQueryParameter("sourceId")
        }.getOrNull()
        if (paymentId != paymentDataInProcessing.id) {
            return ResultType.Failed(ParsingError("The payment id $paymentId does not match the one in processing ${paymentDataInProcessing.id}"))
        }

        val keys = runCatching { uri.queryParameterNames }.getOrNull()
            ?: return ResultType.Failed(ParsingError("Callback uri does not have parameters."))
        val params = mutableMapOf<String, String>()
        for (key in keys) {
            runCatching { uri.getQueryParameter(key) }.getOrNull()?.also { value ->
                params[key] = value
            }
        }

        return ResultType.Succeeded(CallbackProcessingData(paymentDataInProcessing, params, uri))
    }
}
