package jp.elestyle.androidapp.elepay.data

import android.net.Uri

internal data class CallbackProcessingData(
    val paymentData: PaymentCommon,
    val params: Map<String, String>,
    val rawUri: Uri,
)