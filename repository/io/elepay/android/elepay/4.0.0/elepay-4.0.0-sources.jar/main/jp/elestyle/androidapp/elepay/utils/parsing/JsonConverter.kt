package jp.elestyle.androidapp.elepay.utils.parsing

import org.json.JSONArray
import org.json.JSONObject

@Suppress("MemberVisibilityCanBePrivate")
internal object JsonConverter {
    fun toMap(jsonObject: JSONObject): Map<String, Any> {
        val ret = mutableMapOf<String, Any>()
        for (key in jsonObject.keys()) {
            ret[key] = parseJsonValue(jsonObject.get(key))
        }
        return ret
    }

    fun toList(jsonArray: JSONArray): List<Any> {
        val ret = mutableListOf<Any>()
        (0 until jsonArray.length()).forEach {
            ret.add(jsonArray.get(it))
        }
        return ret
    }

    private fun parseJsonValue(value: Any): Any = when (value) {
        is JSONObject -> toMap(
            jsonObject = value
        )
        is JSONArray -> toList(
            jsonArray = value
        )
        else -> value
    }
}