package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.annotation.CallSuper
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.internal.ElepayWebProcessorActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager

/**
 * Created by tanyin on 2018/01/22.
 */

internal abstract class ElepayProcessor(isConfigured: Boolean = false) {
    var isConfigured: Boolean = isConfigured
        private set

    @CallSuper
    open fun setup(providerConfig: ElepayProviderConfig) {
        isConfigured = true
    }

    abstract fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean

    fun processTestModePayment(
        paymentCommon: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = if (paymentCommon.testModeData != null) {
        val testModeUrl = paymentCommon.testModeData.redirectUrl
        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentCommon.id)
        }
        val intent = Intent(fromActivity, ElepayWebProcessorActivity::class.java).apply {
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.PAYMENT_DATA.rawValue, paymentCommon)
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.TARGET_URL.rawValue, testModeUrl)
        }
        fromActivity.startActivity(intent)
        true
    } else false

    abstract fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean

    fun postElepayResult(result: ElepayResult, handler: ElepayResultHandler?) {
        Handler(Looper.getMainLooper()).postDelayed({
            handler?.invoke(result)
        }, 100) // give wechat and alipay webivew some time to release itself
    }
}
