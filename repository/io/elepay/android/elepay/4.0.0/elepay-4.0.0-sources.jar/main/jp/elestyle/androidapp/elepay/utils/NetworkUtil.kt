package jp.elestyle.androidapp.elepay.utils

import java.net.NetworkInterface

internal object NetworkUtil {
    fun collectIPAddresses(): Map<String, String> {
        val addresses = mutableMapOf<String, String>()
        NetworkInterface.getNetworkInterfaces().toList().forEach { networkIf ->
            val name = networkIf.name
            val addrs = mutableListOf<String>()
            networkIf.inetAddresses.toList().forEach { inetAddress ->
                if (!inetAddress.isLoopbackAddress) {
                    inetAddress.hostAddress?.also {
                        addrs.add(it)
                    }
                }
            }
            addresses[name] = if (addrs.isEmpty()) "empty" else addrs.joinToString("__")
        }

        return addresses
    }

    fun collectHardwareAddresses(): Map<String, String> {
        val addresses = mutableMapOf<String, String>()
        NetworkInterface.getNetworkInterfaces().toList().forEach { networkIf ->
            val name = networkIf.name
            val addressBytes = networkIf.hardwareAddress
            if (addressBytes != null) {
                addresses[name] = addressBytes.joinToString(":") {
                    String.format("%02X", it)
                }
            }
        }
        return addresses
    }
}