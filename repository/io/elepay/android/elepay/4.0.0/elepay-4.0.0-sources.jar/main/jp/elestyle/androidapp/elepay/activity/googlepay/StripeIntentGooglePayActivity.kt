package jp.elestyle.androidapp.elepay.activity.googlepay

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.os.BundleCompat
import androidx.lifecycle.lifecycleScope
import com.stripe.android.PaymentConfiguration
import com.stripe.android.googlepaylauncher.GooglePayLauncher
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.GooglePayEnvironment
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.processor.StripeProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.ServerStatusPoller
import kotlinx.coroutines.launch

/**
 * Use Stripe Intent to process Google Pay, including the old "charge" and "source".
 * Stripe has wrapped the Google Pay UI processing itself, so have to separate this new Activity
 * instead of migrating to the previous GooglePayProcessingActivity.
 */
class StripeIntentGooglePayActivity : ComponentActivity() {
    enum class IntentExtraKey(val rawValue: String) {
        CLIENT_SECRET("stripe_client_secret"),
        PAYMENT_BASE_DATA("google_pay_payment_common"),
        PAYMENT_DATA_CURRENCY("google_pay_payment_currency"),
    }

    private lateinit var clientSecret: String
    private lateinit var paymentData: PaymentCommon
    private lateinit var currency: String
    private var launcher: GooglePayLauncher? = null

    private val paymentId: String
        get() = paymentData.id

    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            // In Oreo, Activities where `android:windowIsTranslucent=true` can't request
            // orientation. See https://stackoverflow.com/a/50832408/11103900
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }

        intent.extras!!.run {
            clientSecret = getString(IntentExtraKey.CLIENT_SECRET.rawValue)!!
            paymentData = BundleCompat.getParcelable(
                this,
                IntentExtraKey.PAYMENT_BASE_DATA.rawValue,
                PaymentCommon::class.java
            )!!
            currency = getString(IntentExtraKey.PAYMENT_DATA_CURRENCY.rawValue) ?: "JPY"
        }

        val env = ConfigManager.googlePayEnvironment
        if (env == null) {
            val error = ElepayError.UninitializedPaymentMethod(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    paymentData.provider,
                    paymentData.method,
                    ErrorCode.UNINIT
                ),
                paymentMethod = paymentData.method.rawValue,
                message = "Google Pay Environment is not set."
            )
            notifyResult(ElepayResult.Failed(paymentId, error))
            finish()
            return
        }

        PaymentConfiguration.init(this, StripeProcessor.publishableKey)

        launcher = GooglePayLauncher(
            activity = this,
            config = GooglePayLauncher.Config(
                environment = env.asStripeGooglePayEnvironment,
                merchantCountryCode = "JP",
                merchantName = "",
                existingPaymentMethodRequired = ConfigManager.googlePayExistingPaymentRequired,
            ),
            readyCallback = ::onGooglePayReady,
            resultCallback = ::onGooglePayResult
        )
    }

    private fun onGooglePayReady(isReady: Boolean) {
        if (!isReady) {
            notifyResult(
                ElepayResult.Failed(
                    paymentId = paymentData.id,
                    error = ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            null,
                            null,
                            ErrorCode.DEVICE_NOT_SUPPORTED
                        ),
                        message = "This device does not support Google Pay."
                    )
                )
            )
        } else {
            when (paymentData.dataType) {
                PaymentDataType.CHARGE -> launcher?.presentForPaymentIntent(clientSecret)
                PaymentDataType.SOURCE -> launcher?.presentForSetupIntent(clientSecret, currency)
                PaymentDataType.CHECKOUT -> {
                    val failure = ElepayResult.Failed(
                        paymentData.id,
                        ElepayError.PaymentFailure(
                            errorCode = ErrorCodeGenerator.generate(
                                PlatformCode.ENDUSER,
                                paymentData.provider,
                                paymentData.method,
                                ErrorCode.INVALID_PAYLOAD
                            ),
                            message = "CHECKOUT data should not pass to Stripe GooglePay processing."
                        )
                    )
                    notifyResult(failure)
                }
            }
        }
    }

    private fun onGooglePayResult(result: GooglePayLauncher.Result) {
        when (result) {
            GooglePayLauncher.Result.Completed -> {
                val retryPolicy = ServerStatusPoller.PollPolicy(
                    // According to the server guy's advice, the valid "status" for capturing
                    // actually varies in many different ways. e.g. an "in-captured" status
                    // may indicate a successful state. So just check if it's not "pending"
                    // is good enough here.
                    statusValidating = { status -> status != "pending" },
                    intervalMillis = 1000L,
                    maxPollingCount = 10,
                    extraFailureMessage = "Stripe Intent GooglePay"
                )
                lifecycleScope.launch {
                    notifyResult(ServerStatusPoller.poll(paymentData, retryPolicy))
                }
            }

            GooglePayLauncher.Result.Canceled ->
                notifyResult(ElepayResult.Canceled(paymentId))

            is GooglePayLauncher.Result.Failed -> {
                val failure = ElepayResult.Failed(
                    paymentId,
                    error = ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            paymentData.provider,
                            paymentData.method,
                            ErrorCode.FAILED
                        ),
                        message = result.error.localizedMessage
                            ?: "Failed processing Google Pay through Stripe."
                    )
                )
                notifyResult(failure)
            }
        }
    }

    private fun notifyResult(result: ElepayResult) {
        ElepayResultHandlerManager.notifyResult(result, paymentId)
        runOnUiThread { finish() }
    }
}

private val GooglePayEnvironment.asStripeGooglePayEnvironment: com.stripe.android.googlepaylauncher.GooglePayEnvironment
    get() = when (this) {
        GooglePayEnvironment.TEST -> com.stripe.android.googlepaylauncher.GooglePayEnvironment.Test
        GooglePayEnvironment.PRODUCTION -> com.stripe.android.googlepaylauncher.GooglePayEnvironment.Production
    }