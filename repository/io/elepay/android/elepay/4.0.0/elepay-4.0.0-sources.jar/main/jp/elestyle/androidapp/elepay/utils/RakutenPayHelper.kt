package jp.elestyle.androidapp.elepay.utils

import android.content.Context
import jp.co.rakuten.pay.sdk.RPayClient

object RakutenPayHelper {
    fun isRPayInstalled(context: Context): Boolean =
        RPayClient.Builder(context).build().isRPayInstalled
}