package jp.elestyle.androidapp.elepay.view

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import jp.elestyle.androidapp.elepay.R

/**
 * Since Android 28, ProgressDialog is deprecated, so we do our own...
 */
internal class LoadingIndicator : LinearLayout {
    private lateinit var progressBar: ProgressBar
    private lateinit var messageView: TextView

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    override fun onFinishInflate() {
        super.onFinishInflate()

        progressBar = findViewById(R.id.loading_indicator_progress_bar)
        messageView = findViewById(R.id.loading_indicator_message_view)
    }

    fun setMessage(message: String?) {
        if (message != null) {
            messageView.visibility = View.VISIBLE
            messageView.text = message
        } else {
            messageView.visibility = View.GONE
        }
    }
}