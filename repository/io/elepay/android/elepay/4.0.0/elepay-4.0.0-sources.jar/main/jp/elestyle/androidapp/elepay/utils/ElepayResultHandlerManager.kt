package jp.elestyle.androidapp.elepay.utils

import android.os.Handler
import android.os.Looper
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler

internal object ElepayResultHandlerManager {
    private var resultHandlers: MutableMap<String, ElepayResultHandler> = mutableMapOf()

    fun registerResultHandler(resultHandler: ElepayResultHandler, paymentId: String) {
        synchronized(this) {
            if (resultHandlers[paymentId] == resultHandler) {
                return
            }
            resultHandlers[paymentId] = resultHandler
        }
    }

    /**
     * Notify the final [result] to the handler associated with the given [paymentId]
     * This is a one-time operation. After sending the result, the handler's reference will be removed internally,
     * it's no longer available for the next invoking.
     */
    fun notifyResult(result: ElepayResult, paymentId: String) {
        val handler = synchronized(this) {
            resultHandlers.remove(paymentId)
        }

        // some providers(e.g. wechat, alipay) need some time to clean up their resources
        Handler(Looper.getMainLooper()).postDelayed({
            handler?.invoke(result)
        }, 100)
    }

    fun checkRegistration(paymentId: String): Boolean = synchronized(this) {
        resultHandlers[paymentId] != null
    }
}