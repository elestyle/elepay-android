package jp.elestyle.androidapp.elepay.activity.internal

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.dialog.LoadingDialog
import jp.elestyle.androidapp.elepay.dialog.MessageDialog
import jp.elestyle.androidapp.elepay.processor.creditcard.CreditCardProcessor
import jp.elestyle.androidapp.elepay.processor.creditcard.ActivityAwarenessCreditCardProcessor
import jp.elestyle.androidapp.elepay.processor.creditcard.NumberScannableCreditCardProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.creditcard.CardIssuer
import jp.elestyle.androidapp.elepay.utils.creditcard.CreditCardProcessingCenter
import jp.elestyle.androidapp.elepay.utils.creditcard.CreditCardValidator
import jp.elestyle.androidapp.elepay.core.theme.checkAndApplyElepayTheme
import jp.elestyle.androidapp.elepay.core.locale.Localization
import jp.elestyle.androidapp.elepay.core.log
import jp.elestyle.androidapp.elepay.view.CreditCardEditorActionListener
import jp.elestyle.androidapp.elepay.view.CreditCardEditorWidget
import jp.elestyle.androidapp.elepay.view.MockCreditCardView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal class CreditCardProcessingActivity : AppCompatActivity(), CoroutineScope by MainScope() {
    @Suppress("unused")
    private val logTag: String = CreditCardProcessingActivity::class.java.simpleName
    private var paymentId: String = ""
    private lateinit var mockCardView: MockCreditCardView
    private lateinit var cardEditor: CreditCardEditorWidget
    private lateinit var doneButton: Button
    private lateinit var loadingDialog: LoadingDialog
    private var processor: CreditCardProcessor? = null
    private var cardIssuer: CardIssuer = CardIssuer.Unknown

    enum class IntentExtraKey(val rawValue: String) {
        PAYMENT_ID("payment_id"),
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        checkAndApplyElepayTheme(ConfigManager.theme)

        super.onCreate(savedInstanceState)

        intent.extras?.run {
            paymentId = getString(IntentExtraKey.PAYMENT_ID.rawValue) ?: ""
        }
        processor = CreditCardProcessingCenter[paymentId]?.also {
            (it as? ActivityAwarenessCreditCardProcessor)?.onHostActivityCreate(this)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                processor?.cancelProcessing()
                notifyElepayResult(ElepayResult.Canceled(paymentId))
                finish()
            }
        })

        setContentView(R.layout.credit_card_activity)

        val toolbar = findViewById<Toolbar>(R.id.elepayDefaultTopbar)
        toolbar.title = Localization.string(R.string.text_credit_card)
        setSupportActionBar(toolbar)
        supportActionBar!!.apply {
            setDisplayHomeAsUpEnabled(true)
        }

        mockCardView = findViewById(R.id.creditCardActivityMockCardView)
        cardEditor = findViewById(R.id.creditCardActivityCardEditorView)
        cardEditor.actionListener = object : CreditCardEditorActionListener {
            override fun onCreditCardIssuerChanged(newIssuer: CardIssuer) {
                cardIssuer = newIssuer
                mockCardView.updateCardIssuer(newIssuer)
            }

            override fun onCreditCardInputFocusChanged(
                focusedWidget: CreditCardEditorWidget.InputEditorIdentity
            ) {
                val target = convertEditorIdentityToMockCardFocusTarget(focusedWidget)
                mockCardView.changeFocusedTarget(target)
            }

            override fun onValidateCreditCardNumber(
                numberString: String,
                cardIssuer: CardIssuer
            ): Boolean {
                return performCardNumberValidating(numberString, cardIssuer)
            }

            override fun onValidateExpirationDate(month: Int, year: Int): Boolean {
                return performExpirationDateValidating(month, year)
            }

            override fun onInputCreditCardInformation(
                target: CreditCardEditorWidget.InputEditorIdentity,
                digit: Int
            ) {
                mockCardView.animateDigit(convertEditorIdentityToMockCardFocusTarget(target), digit)
            }

            override fun onScanCardNumber() {
                cardEditor.clearInputs()
                lifecycleScope.launch {
                    val cardInfo =
                        (processor as? NumberScannableCreditCardProcessor)?.scanCreditCard(this@CreditCardProcessingActivity)
                    if (cardInfo != null) {
                        cardEditor.showCreditCard(cardInfo)
                    }
                }
            }
        }

        cardEditor.numberScanButtonVisibility = View.INVISIBLE
        (processor as? NumberScannableCreditCardProcessor)?.let {
            if (it.isCardScanAvailable) {
                cardEditor.numberScanButtonVisibility = View.VISIBLE
            }
        }

        doneButton = findViewById(R.id.creditCardActivityDoneButton)
        doneButton.text = Localization.string(R.string.button_title_done)
        doneButton.setOnClickListener {
            handleDone()
        }

        loadingDialog =
            LoadingDialog.newInstance(Localization.string(R.string.prompt_text_processing))
        loadingDialog.isCancelable = false

        cardEditor.moveCursor(CreditCardEditorWidget.InputEditorIdentity.CARD_NUMBER)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onDestroy() {
        super.onDestroy()

        (processor as? ActivityAwarenessCreditCardProcessor)?.onHostActivityDestroy(this)
        CreditCardProcessingCenter.removeProcessor(paymentId)
    }

    private fun performCardNumberValidating(numberString: String, cardIssuer: CardIssuer): Boolean {
        val ret = CreditCardValidator.validateCardNumber(numberString, cardIssuer)
        if (!ret) {
            cardEditor.showErrorMessage(
                Localization.string(R.string.prompt_invalid_credit_card_number),
                CreditCardEditorWidget.InputEditorIdentity.CARD_NUMBER
            )
        }
        return ret
    }

    private fun performExpirationDateValidating(month: Int, year: Int): Boolean {
        val ret = CreditCardValidator.validateCardExpirationDate(month, year)
        if (!ret) {
            cardEditor.showErrorMessage(
                Localization.string(R.string.prompt_invalid_credit_card_expiration_date),
                CreditCardEditorWidget.InputEditorIdentity.EXPIRY_DATE
            )
        }
        return ret
    }

    private fun handleDone() {
        if (processor == null) {
            notifyInternalError("Internal error: no credit card processor found.")
            finish()
            return
        }

        val cardInfo = cardEditor.collectedCardInfo
        if (cardInfo == null) {
            showInnerNotification(Localization.string(R.string.prompt_invalid_credit_card))
            return
        }

        // Before perform full checking, do the individual check to show error message more specifically.
        performCardNumberValidating(cardInfo.number, cardIssuer)
        performExpirationDateValidating(cardInfo.month, cardInfo.year)

        if (!CreditCardValidator.validateCard(cardInfo, cardIssuer)) {
            showInnerNotification(Localization.string(R.string.prompt_invalid_credit_card))
            return
        }

        launch {
            showLoadingUI()
            val result = withContext(Dispatchers.Default) {
                processor!!.processCard(cardInfo)
            }
            hideLoadingUI()

            if (result is ElepayResult.Failed &&
                result.error is ElepayError.PaymentFailure &&
                result.error.errorCode.contains(ErrorCode.CREDITCARD_3D_AUTH_FAILURE.raw)
            ) {
                showMessageDialog(getString(R.string.msg3DAuthFailed))
            } else if (result is ElepayResult.Canceled) {
                log(logTag, "Card processor returns \"canceled\" result. Ignore.")
            } else {
                notifyElepayResult(result)
                finish()
            }
        }
    }

    private fun notifyInternalError(@Suppress("SameParameterValue") message: String) {
        val failure = ElepayResult.Failed(
            paymentId = paymentId,
            error = ElepayError.SystemError(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    null,
                    PaymentMethod.CREDIT_CARD,
                    ErrorCode.FAILED
                ),
                message = message
            )
        )
        notifyElepayResult(failure)
    }

    private fun notifyElepayResult(result: ElepayResult) {
        ElepayResultHandlerManager.notifyResult(result, paymentId)
    }

    private fun showInnerNotification(message: String) {
        Snackbar.make(
            findViewById(R.id.creditCardActivityMainContainer),
            message,
            Snackbar.LENGTH_LONG
        ).show()
    }

    private fun showLoadingUI() {
        doneButton.isEnabled = false
        loadingDialog.show(supportFragmentManager, "creditcard_loading_dialog")
    }

    private fun hideLoadingUI() {
        doneButton.isEnabled = true
        loadingDialog.dismiss()
    }

    private fun showMessageDialog(message: String) {
        MessageDialog.newInstance(message).show(supportFragmentManager, "creditcard_message_dialog")
    }

    private fun convertEditorIdentityToMockCardFocusTarget(
        identity: CreditCardEditorWidget.InputEditorIdentity
    ): MockCreditCardView.FocusTarget = when (identity) {
        CreditCardEditorWidget.InputEditorIdentity.CARD_NUMBER -> MockCreditCardView.FocusTarget.NUMBER

        CreditCardEditorWidget.InputEditorIdentity.EXPIRY_DATE -> MockCreditCardView.FocusTarget.DATE

        CreditCardEditorWidget.InputEditorIdentity.CVC -> MockCreditCardView.FocusTarget.CVC
    }
}