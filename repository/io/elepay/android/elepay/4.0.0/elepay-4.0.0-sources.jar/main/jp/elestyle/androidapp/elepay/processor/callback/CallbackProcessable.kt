package jp.elestyle.androidapp.elepay.processor.callback

import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.PaymentCommon

internal interface CallbackProcessable {
    data class ProcessingPaymentInfo(val paymentData: PaymentCommon)

    data class ProcessedResult(
        val paymentId: String,
        val elepayResult: ElepayResult,
    )

    val callbackScheme: String

    fun retrieveProcessingPaymentInfo(disposeImmediately: Boolean): ProcessingPaymentInfo?

    suspend fun continueCallbackProcessing(data: CallbackProcessingData): ProcessedResult
}