package jp.elestyle.androidapp.elepay.utils

import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.APIResult
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import kotlinx.coroutines.delay

internal object ServerStatusPoller {
    data class PollPolicy(
        val statusValidating: (status: String) -> Boolean,
        val intervalMillis: Long,
        val maxPollingCount: Int,
        /**
         * Will be appended to the end of ElepayResult.Failed info.
         */
        val extraFailureMessage: String,
    )

    suspend fun poll(
        paymentData: PaymentCommon,
        pollPolicy: PollPolicy,
    ): ElepayResult {
        val paymentId = paymentData.id
        val api: suspend (String) -> APIResult = when (paymentData.dataType) {
            PaymentDataType.CHARGE -> { chargeId -> ServerAPIClient.chargeStatus(chargeId) }
            PaymentDataType.SOURCE -> { sourceId -> ServerAPIClient.sourceStatus(sourceId) }
            PaymentDataType.CHECKOUT -> return ElepayResult.Failed(
                paymentId,
                ElepayError.PaymentFailure(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        paymentData.provider,
                        paymentData.method,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    message = "CHECKOUT data is not supported by server status checking. ${pollPolicy.extraFailureMessage}"
                )
            )
        }

        return if (poll(api, paymentId, retriedCount = 0, pollPolicy))
            ElepayResult.Succeeded(paymentId)
        else {
            val (target, errorCode) = when (paymentData.dataType) {
                PaymentDataType.CHARGE ->
                    Pair("charge", ErrorCode.FAILED_CAPTURE)
                PaymentDataType.SOURCE ->
                    Pair("source", ErrorCode.FAILED_CONFIRM)
                PaymentDataType.CHECKOUT ->
                    // Impossible
                    Pair("checkout", ErrorCode.FAILED)
            }
            ElepayResult.Failed(
                paymentId,
                ElepayError.PaymentFailure(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        paymentData.provider,
                        paymentData.method,
                        errorCode
                    ),
                    message = "Failed validating server $target status. ${pollPolicy.extraFailureMessage}"
                )
            )
        }
    }

    private suspend fun poll(
        api: suspend (paymentId: String) -> APIResult,
        paymentId: String,
        retriedCount: Int,
        pollingPolicy: PollPolicy,
    ): Boolean {
        val done = when (val apiRes = api(paymentId)) {
            is ResultType.Succeeded -> {
                pollingPolicy.statusValidating(apiRes.data.optString("status"))
            }

            is ResultType.Failed -> false
        }

        return if (!done) {
            if (retriedCount >= pollingPolicy.maxPollingCount) {
                false
            } else {
                delay(pollingPolicy.intervalMillis)
                poll(api, paymentId, retriedCount + 1, pollingPolicy)
            }
        } else {
            true
        }
    }
}