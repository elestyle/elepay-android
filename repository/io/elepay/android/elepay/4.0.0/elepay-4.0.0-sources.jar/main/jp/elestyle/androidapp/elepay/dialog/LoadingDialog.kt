package jp.elestyle.androidapp.elepay.dialog

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.view.LoadingIndicator

internal class LoadingDialog : DialogFragment() {
    companion object {
        fun newInstance(message: String?): LoadingDialog {
            val ret = LoadingDialog()
            if (message != null) {
                ret.arguments = Bundle().apply {
                    putString("message", message)
                }
            }
            return ret
        }
    }

    @SuppressLint("InflateParams")
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val indicator = requireActivity().layoutInflater.inflate(
            R.layout.loading_indicator,
            null
        ) as LoadingIndicator
        // Get the message text explicitly, because we need to tell the indicator view whether it has
        // content.
        val msg = arguments?.getString("message")
        indicator.setMessage(msg)
        return AlertDialog.Builder(activity)
            .setView(indicator)
            .setCancelable(false)
            .create()
    }
}