package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.internal.ElepayWebProcessorActivity
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.ServerAPIClient
import org.json.JSONObject

internal object LinePayProcessor : ElepayProcessor(), CallbackProcessable {
    private var processingData: CallbackProcessable.ProcessingPaymentInfo? = null

    override fun setup(providerConfig: ElepayProviderConfig) {
        super.setup(providerConfig)
        if (providerConfig is ElepayProviderConfig.LinePay) {
            callbackScheme = providerConfig.appScheme
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = processLinePayPayment(
        chargeData.payload,
        chargeData.paymentCommon,
        fromActivity,
        resultHandler
    )

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = processLinePayPayment(
        sourceData.payload,
        sourceData.paymentCommon,
        fromActivity,
        resultHandler
    )

    override var callbackScheme: String = ""
        private set

    override fun retrieveProcessingPaymentInfo(
        disposeImmediately: Boolean
    ): CallbackProcessable.ProcessingPaymentInfo? {
        val ret = processingData
        if (disposeImmediately) {
            processingData = null
        }
        return ret
    }

    override suspend fun continueCallbackProcessing(
        data: CallbackProcessingData
    ): CallbackProcessable.ProcessedResult {
        val paymentId = data.paymentData.id
        val elepayResult = when (data.params["type"]?.lowercase()) {
            null -> ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        data.paymentData.provider,
                        data.paymentData.method,
                        ErrorCode.FAILED
                    ),
                    "No valid type found."
                )
            )
            "confirm" -> {
                when (data.paymentData.dataType) {
                    PaymentDataType.CHARGE -> capturePayment(paymentId, "")

                    PaymentDataType.SOURCE -> confirmPayment(paymentId, "")

                    // Impossible
                    PaymentDataType.CHECKOUT -> ElepayResult.Failed(
                        paymentId = paymentId,
                        error = ElepayError.InvalidPayload(
                            ErrorCodeGenerator.generate(
                                PlatformCode.ENDUSER,
                                data.paymentData.provider,
                                data.paymentData.method,
                                ErrorCode.FAILED
                            ),
                            "CHECKOUT data could not be processed."
                        )
                    )
                }
            }
            else -> ElepayResult.Canceled(paymentId)
        }

        return CallbackProcessable.ProcessedResult(paymentId, elepayResult)
    }

    private fun processLinePayPayment(
        payload: String?,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(paymentData, fromActivity, resultHandler)) true
        else when (paymentData.method) {
            PaymentMethod.LINE_PAY -> {
                if (callbackScheme.isEmpty()) {
                    val error = ElepayError.UninitializedPaymentMethod(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.LINE_PAY,
                            PaymentMethod.LINE_PAY,
                            ErrorCode.UNINIT
                        ),
                        PaymentMethod.LINE_PAY.rawValue,
                        "Not well configured"
                    )
                    resultHandler?.invoke(ElepayResult.Failed(paymentData.id, error))
                    false
                } else {
                    processLinePay(payload, paymentData, fromActivity, resultHandler)
                }
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = paymentData.id,
                        error = ElepayError.UnsupportedPaymentMethod(paymentData.method.rawValue)
                    )
                )
                false
            }
        }

    private fun processLinePay(
        payload: String?,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (payload.isNullOrEmpty()) {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    paymentId = paymentData.id,
                    error = ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.LINE_PAY,
                            PaymentMethod.LINE_PAY,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        "${PaymentMethod.LINE_PAY.rawValue} charge error."
                    )
                )
            )
            return false
        }

        val jsonPayload = try {
            JSONObject(payload)
        } catch (e: Exception) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.LINE_PAY,
                    PaymentMethod.LINE_PAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.LINE_PAY.rawValue} charge error."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentData.id, error = error))
            return false
        }

        val jsonPaymentUrl = jsonPayload.optJSONObject("paymentUrl") ?: run {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    paymentData.id,
                    ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.LINE_PAY,
                            PaymentMethod.LINE_PAY,
                            ErrorCode.INVALID_AUTH_URL
                        ),
                        "No available url for authorization."
                    )
                )
            )
            return false
        }

        val appUrl = jsonPaymentUrl.optString("app", "")
        var started = processAppUrl(appUrl, fromActivity)

        if (!started) {
            val webUrl = jsonPaymentUrl.optString("web", "")
            started = processWebUrl(webUrl, fromActivity, paymentData)
        }

        if (started) {
            processingData = CallbackProcessable.ProcessingPaymentInfo(paymentData)
            if (resultHandler != null) {
                ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentData.id)
            }
        } else {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.LINE_PAY,
                    PaymentMethod.LINE_PAY,
                    ErrorCode.INVALID_AUTH_URL
                ),
                "No available url for authorization."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentData.id, error))
        }

        return true
    }

    /**
     * Try to launch the given app url.
     * @return `true` for launching successfully, `false` otherwise.
     */
    private fun processAppUrl(
        appUrl: String,
        fromActivity: Activity
    ): Boolean =
        if (appUrl.isNotEmpty()) {
            try {
                val uri = Uri.parse(appUrl)
                fromActivity.startActivity(Intent(Intent.ACTION_VIEW, uri))
                true
            } catch (e: Exception) {
                false
            }
        } else false

    private fun processWebUrl(
        webUrl: String,
        fromActivity: Activity,
        paymentData: PaymentCommon
    ): Boolean = if (webUrl.isNotEmpty()) {
        val intent = Intent(fromActivity, ElepayWebProcessorActivity::class.java).apply {
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.PAYMENT_DATA.rawValue, paymentData)
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.TARGET_URL.rawValue, webUrl)
        }
        fromActivity.startActivity(intent)
        true
    } else false

    private suspend fun capturePayment(paymentId: String, token: String): ElepayResult =
        when (ServerAPIClient.capture(paymentId, token)) {
            is ResultType.Failed ->
                ElepayResult.Failed(
                    paymentId,
                    ElepayError.PaymentFailure(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.LINE_PAY,
                            PaymentMethod.LINE_PAY,
                            ErrorCode.FAILED_CAPTURE
                        ),
                        "Failed to capture."
                    )
                )

            is ResultType.Succeeded -> ElepayResult.Succeeded(paymentId)
        }

    private suspend fun confirmPayment(paymentId: String, token: String): ElepayResult =
        when (val res = ServerAPIClient.confirm(paymentId, token)) {
            is ResultType.Failed -> {
                // This special code is used by PayPay when user canceled source auth.
                if (res.error.code.split("_").lastOrNull() == "40046") {
                    ElepayResult.Canceled(paymentId)
                } else {
                    ElepayResult.Failed(
                        paymentId,
                        ElepayError.PaymentFailure(
                            ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                PaymentMethodProvider.LINE_PAY,
                                PaymentMethod.LINE_PAY,
                                ErrorCode.FAILED_CAPTURE
                            ),
                            "Failed to confirm."
                        )
                    )
                }
            }

            is ResultType.Succeeded -> ElepayResult.Succeeded(paymentId)
        }
}