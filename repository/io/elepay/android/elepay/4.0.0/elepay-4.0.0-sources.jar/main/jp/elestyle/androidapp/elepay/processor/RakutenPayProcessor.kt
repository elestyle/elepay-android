package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.ActivityNotFoundException
import jp.co.rakuten.pay.sdk.RPayClient
import jp.co.rakuten.pay.sdk.RPayHelper
import jp.co.rakuten.pay.sdk.RPayPaymentRequest
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.rakutenpay.RakutenPayResultHandlingActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import org.json.JSONObject

internal object RakutenPayProcessor : ElepayProcessor() {
    private var gatewayCode: String = ""

    var paymentId: String = ""
        private set

    override fun setup(providerConfig: ElepayProviderConfig) {
        super.setup(providerConfig)
        if (providerConfig is ElepayProviderConfig.RakutenPay) {
            gatewayCode = providerConfig.gatewayCode
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = processRakutenPay(
        paymentData = chargeData.paymentCommon,
        payload = chargeData.payload,
        fromActivity = fromActivity,
        resultHandler = resultHandler
    )

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    private fun processRakutenPay(
        paymentData: PaymentCommon,
        payload: String?,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(paymentData, fromActivity, resultHandler)) true
        else when (paymentData.method) {
            PaymentMethod.RAKUTEN_PAY -> {
                if (gatewayCode.isEmpty()) {
                    val error = ElepayError.UninitializedPaymentMethod(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.RAKUTEN_PAY,
                            PaymentMethod.RAKUTEN_PAY,
                            ErrorCode.UNINIT
                        ),
                        PaymentMethod.RAKUTEN_PAY.rawValue,
                        "Not well configured"
                    )
                    resultHandler?.invoke(ElepayResult.Failed(paymentData.id, error))
                    false
                } else {
                    processRakutenPayCharge(
                        payload,
                        paymentData.id,
                        fromActivity,
                        resultHandler
                    )
                }
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = paymentData.id,
                        error = ElepayError.UnsupportedPaymentMethod(paymentData.method.rawValue)
                    )
                )
                false
            }
        }

    private fun processRakutenPayCharge(
        payload: String?,
        paymentId: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (payload.isNullOrEmpty()) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.RAKUTEN_PAY,
                    PaymentMethod.RAKUTEN_PAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.RAKUTEN_PAY.rawValue} no payload."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentId, error = error))
            return false
        }

        val jsonPayload = try {
            JSONObject(payload)
        } catch (e: Exception) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.RAKUTEN_PAY,
                    PaymentMethod.RAKUTEN_PAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.RAKUTEN_PAY.rawValue} invalid json payload."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentId, error = error))
            return false
        }

        val transactionId = jsonPayload.optString("transactionId", "")
            .takeIf { it.isNotEmpty() }
            ?: run {
                val error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        PaymentMethodProvider.RAKUTEN_PAY,
                        PaymentMethod.RAKUTEN_PAY,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    "No valid transaction id found."
                )
                resultHandler?.invoke(ElepayResult.Failed(paymentId, error))
                return false
            }

        val pendingIntent = RPayHelper.newResultPendingIntent(
            fromActivity,
            RakutenPayResultHandlingActivity::class.java
        )

        val request = RPayPaymentRequest.Builder()
            .gatewayCode(gatewayCode)
            .transactionId(transactionId)
            .resultIntent(pendingIntent)
            .build()
        return try {
            if (resultHandler != null) {
                ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
            }

            this.paymentId = paymentId
            val intent = RPayClient.Builder(fromActivity).build().newRPayIntent(request)
            fromActivity.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    null,
                    null,
                    ErrorCode.APP_NOT_INSTALLED
                ),
                "Could not found RPay app to perform payment."
            )
            // Use the registered handler for result notifying, this will remove the ref from
            // ElepayResultHandlerManager.
            ElepayResultHandlerManager.notifyResult(
                ElepayResult.Failed(paymentId, error),
                paymentId
            )
            false
        }
    }
}