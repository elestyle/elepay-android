package jp.elestyle.androidapp.elepay.utils.extensions

import java.io.UnsupportedEncodingException
import java.net.URLDecoder
import java.net.URLEncoder

@Suppress("unused")
internal val String.urlDecoded: String
    get() = try {
        URLDecoder.decode(this, Charsets.UTF_8.name())
    } catch (e: UnsupportedEncodingException) {
        this
    }

internal val String.urlEncoded: String
    get() = try {
        URLEncoder.encode(this, Charsets.UTF_8.name())
    } catch (e: UnsupportedEncodingException) {
        this
    }

internal fun String.asPureCreditCardNumber(): String {
    val trimmed = trim()
    if (trimmed.isEmpty()) return trimmed

    return trimmed.replace(Regex("\\s|-"), "")
}