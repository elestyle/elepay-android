package jp.elestyle.androidapp.elepay.utils

import android.content.Context
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailabilityLight

@Suppress("unused")
internal object GooglePlayServiceHelper {
    private const val logTag = "GooglePlayIDFARetriever"

    fun isGooglePlayServiceAvailable(context: Context): Boolean =
        GoogleApiAvailabilityLight.getInstance()
            .isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS
}
