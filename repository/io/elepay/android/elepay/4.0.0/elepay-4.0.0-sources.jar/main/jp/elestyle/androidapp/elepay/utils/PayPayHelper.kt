package jp.elestyle.androidapp.elepay.utils

import android.content.Context

internal object PayPayHelper {
    private const val payPayPackageName = "jp.ne.paypay.android.app"

    fun isPayPayInstalled(context: Context): Boolean =
        SystemUtil.isPackageInstalled(payPayPackageName, context)
}