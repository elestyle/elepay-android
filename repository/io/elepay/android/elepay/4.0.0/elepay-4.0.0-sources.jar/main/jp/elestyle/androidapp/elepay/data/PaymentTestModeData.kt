package jp.elestyle.androidapp.elepay.data

import android.os.Parcel
import android.os.Parcelable

internal data class PaymentTestModeData(
    val redirectUrl: String
) : Parcelable {
    constructor(source: Parcel): this(
        redirectUrl = source.readString() ?: ""
    )

    override fun describeContents(): Int = 0

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(redirectUrl)
    }

    companion object {
        @Suppress("unused")
        @JvmField
        val CREATOR = object : Parcelable.Creator<PaymentTestModeData> {
            override fun createFromParcel(parcel: Parcel): PaymentTestModeData {
                return PaymentTestModeData(parcel)
            }

            override fun newArray(size: Int): Array<PaymentTestModeData?> {
                return arrayOfNulls(size)
            }
        }
    }
}
