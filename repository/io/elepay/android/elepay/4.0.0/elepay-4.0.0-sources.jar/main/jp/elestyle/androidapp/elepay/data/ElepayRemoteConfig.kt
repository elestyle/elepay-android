package jp.elestyle.androidapp.elepay.data

/**
 * Define the config data that retrieved from our server.
 */
internal data class ElepayRemoteConfig(
    val providerConfigs: List<ElepayProviderConfig>
)

@Suppress("unused")
internal sealed class ElepayProviderConfig {
    abstract val appScheme: String
    abstract val asPaymentMethodProvider: PaymentMethodProvider

    data class WechatPay(
        val appKey: String,
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.WECHAT_PAY
    }

    data class Alipay(override val appScheme: String) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider = PaymentMethodProvider.ALIPAY
    }

    data class Stripe(
        val publishableKey: String,
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.STRIPE
    }

    data class Allpay(
        val usesDevelopmentEnvironment: Boolean,
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.ALLPAY
    }

    data class Braintree(
        val sandbox: Boolean,
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.BRAINTREE
    }

    data class LinePay(override val appScheme: String) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.LINE_PAY
    }

    data class PayPay(override val appScheme: String) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider = PaymentMethodProvider.PAYPAY
    }

    data class Merpay(override val appScheme: String) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider = PaymentMethodProvider.MERPAY
    }

    data class Ksher(
        val wechatKey: String,
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider = PaymentMethodProvider.KSHER
    }

    data class Paygent(
        val googlePayConfig: PaygentGooglePayConfig?,
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider = PaymentMethodProvider.PAYGENT
    }

    data class AuPay(
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider = PaymentMethodProvider.AUPAY
    }

    data class RakutenPay(
        val gatewayCode: String,
        override val appScheme: String,
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.RAKUTEN_PAY
    }

    data class JcoinPay(
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider = PaymentMethodProvider.JCOINPAY
    }

    data class UnionPay(
        override val appScheme: String,
        val mode: String,
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.UNION_PAY
    }

    data class AlipayPlus(
        override val appScheme: String,
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.ALIPAY_PLUS
    }

    data class Gmo(
        val googlePayConfig: GmoGooglePayConfig?,
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider = PaymentMethodProvider.GMO
    }

    data class RakutenBank(
        override val appScheme: String
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.RAKUTEN_BANK
    }

    data class SonyPayment(
        override val appScheme: String,
    ) : ElepayProviderConfig() {
        override val asPaymentMethodProvider: PaymentMethodProvider =
            PaymentMethodProvider.SONY_PAYMENT
    }
}
