package jp.elestyle.androidapp.elepay.data

internal sealed class ResultType<DataType, ErrorType> {
    data class Succeeded<DataType, Error>(val data: DataType) : ResultType<DataType, Error>()
    data class Failed<Data, ErrorType>(val error: ErrorType): ResultType<Data, ErrorType>()
}