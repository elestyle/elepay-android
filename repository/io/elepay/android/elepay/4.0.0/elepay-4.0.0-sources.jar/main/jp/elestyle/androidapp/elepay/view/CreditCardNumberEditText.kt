package jp.elestyle.androidapp.elepay.view

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.inputmethod.EditorInfo
import com.google.android.material.textfield.TextInputEditText
import jp.elestyle.androidapp.elepay.utils.creditcard.CardDividerPosition
import jp.elestyle.androidapp.elepay.utils.creditcard.CardIssuer
import jp.elestyle.androidapp.elepay.utils.extensions.asPureCreditCardNumber
import jp.elestyle.androidapp.elepay.utils.extensions.contains
import kotlin.math.max
import kotlin.math.min


private class CardNumberFormattedResult(val numberString: String, val overflowedInput: String)

@Suppress("unused")
internal class CreditCardNumberEditText : TextInputEditText {
    private val logTag = CreditCardNumberEditText::class.java.simpleName
    private val validCardIssuer = arrayOf(
        CardIssuer.Amex,
        CardIssuer.Jcb,
        CardIssuer.Visa,
        CardIssuer.Mastercard,
        CardIssuer.Unionpay,
        CardIssuer.DinersClub
    )
    private val brandCheckingDigitsThreshold = 4

    private var isFormattingNumber: Boolean = false
    private var cardIssuer: CardIssuer = CardIssuer.Unknown

    interface StateListener {
        /**
         * Notify the card issuer is changed according to the card number that user input.
         * @param issuer A concret type of CardIssuer
         */
        fun onCreditCardIssuerChanged(issuer: CardIssuer)

        /**
         * Notify that the card number editing is finished.
         * @param cardNumber The cardnumber without formatting, just a plain card number.
         * @param extraInput The extra digits that user has input. For normal input, when user
         * input the last digit of the card number, the callback is fired with this parameter
         * set to empty string. However, user may manually move the cursor to the number input
         * widget's last position and input a number(may intent to input the date).
         * For this case, we pass the extra number here. This could also handle the copy-paste
         * case more properly.
         */
        fun onCreditCardNumberFinishedEditing(cardNumber: String, extraInput: String)

        /**
         * Notify the card number has been modified.
         * @param digit The digit of the number under the cursor.
         */
        fun onEditCreditCardNumber(digit: Int)

        /**
         * Called when the editor detected some editing. The listener could clear some already
         * shown errors.
         * The internal error indication is handled by this widget and should not be bothered.
         */
        fun onClearCreditCardNumberErrors()
    }

    var stateListener: StateListener? = null

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )


    override fun onFinishInflate() {
        super.onFinishInflate()

        setup()
    }

    private fun setup() {
        attachTextChangeListener()
        setOnEditorActionListener { _, actionId, _ ->
            when (actionId) {
                EditorInfo.IME_ACTION_NEXT, EditorInfo.IME_ACTION_DONE -> {
                    val cardNumber = text.toString().asPureCreditCardNumber()
                    stateListener?.onCreditCardNumberFinishedEditing(cardNumber, "")
                    true
                }
                else -> false
            }
        }
    }

    private fun attachTextChangeListener() {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s == null) return
                if (isFormattingNumber) return

                // From Android's API doc, the system will translate the deletion of deleting
                // a char/sub-range str into "change the count of a char/sub-range str to 0",
                // so "count == 0" means deletion.
                //
                // Note: determine the deleting flag before filtering.
                // When user paste the content to a full input
                // (e.g. paste "123123" to "1234 1234 1234 1234"), the filter algorithm will
                // translate the input count to 0, which is unexpected.
                val isDeleting = count == 0

                // Filter the input.
                // Ignore the input when user keeps pressing the keyboard while there's no space
                // to input. We treat this as user is releasing pressure :)
                val (input, inputCount) = interceptInput(s, startPos = start, changeCount = count)

                checkCardIssuerUpdating(input, inputStartPos = start, inputCount = inputCount)

                val formattedResult = formatCardNumber(input, cardIssuer, start, isDeleting)
                val cursorPos = findCursorPosition(
                    numberStr = input,
                    dividerPositions = cardIssuer.dividerPositions,
                    editingPosition = start,
                    editingTargetCount = inputCount,
                    isDeleting = isDeleting
                )
                // After formatting, make sure the cursor position is still in range.
                val cursorPosition = max(0, min(cursorPos, formattedResult.numberString.length))
                notifyCardNumberInputState(formattedResult, start, inputCount, cursorPosition)

                isFormattingNumber = true
                setText(formattedResult.numberString)
                setSelection(cursorPosition)
                isFormattingNumber = false
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun interceptInput(
        s: CharSequence,
        startPos: Int,
        changeCount: Int
    ): Pair<String, Int> {
        val numberLengthLimit = cardIssuer.formattedCardNumberLength
        return if (s.length > numberLengthLimit && startPos < numberLengthLimit)
        // set "start <= maxLength" causes the inputCount being 0 which may lead to the listener
        // won't get notified about the finish event.
            Pair(
                s.replaceRange(startPos, startPos + changeCount, "").toString(),
                0
            )
        else Pair(s.toString(), changeCount)
    }

    private fun findCursorPosition(
        numberStr: String,
        dividerPositions: Array<CardDividerPosition>,
        editingPosition: Int,
        editingTargetCount: Int,
        isDeleting: Boolean
    ): Int {
        var cursorPosition = editingPosition + editingTargetCount
        // We have restricted the input to just number. System will even filter pasted content.
        // So when calculate the cursor position, need to check against the stripped string.
        // e.g. for card number "1234 5678 9012 3456", when user cut "34 5678 9012 3",
        // the string became "1245 6".
        // Then paste it again, the actual pasted content is "34567890123", and `numberStr` is
        // "123456789012345 6".
        // If we check against the formatted divider position, the last one is missed.
        val dividersBeforeCursor =
            numberStr.filterIndexed { index, c -> index < cursorPosition && c.isWhitespace() }
                .count()
        val strippedBeforeCursor = numberStr.substring(0, cursorPosition).asPureCreditCardNumber()
        val totalDividersBeforeCursor = dividerPositions.count { position ->
            position.preformat < strippedBeforeCursor.length
        }
        val extraMovement = totalDividersBeforeCursor - dividersBeforeCursor
        if (extraMovement > 0) {
            // When user editing the divider, need to perform an extra cursor moving
            // since the divider is just a placeholder to the user.
            if (isDeleting) {
                cursorPosition -= extraMovement
            } else {
                cursorPosition += extraMovement
            }
        } else if (dividerPositions.contains { it.formatted == editingPosition - 1 } &&
            isDeleting) {
            // For another special case, when the user is deleting the character right after a
            // divider, need to move backward one more character to let the user see that the
            // placeholder is also deleted.
            // If that placeholder is still necessary for the new string formatting,
            // we'll add it back later.
            cursorPosition -= 1
        }
        return cursorPosition
    }

    private fun formatCardNumber(
        numberStr: String,
        cardIssuer: CardIssuer,
        editingPosition: Int,
        isDeleting: Boolean
    ): CardNumberFormattedResult {
        val dividerPositions = cardIssuer.dividerPositions

        // Check to remove the character before the divider character.
        val isDeletingDivider =
            dividerPositions.contains { position -> position.formatted == editingPosition } &&
                    isDeleting
        val preprocessed = (
                if (isDeletingDivider) numberStr.removeRange(editingPosition - 1, editingPosition)
                else numberStr
                ).asPureCreditCardNumber()

        val numberParts = mutableListOf<String>()
        // Here, we're trying to split the stripped number string(e.g. 4242424242424) with the
        // dividing information after formatting. So some transforming is necessary.
        var lastCheckedDividerPosition = 0
        for (idx in 0 until dividerPositions.count()) {
            val start = if (idx == 0) 0 else dividerPositions[idx - 1].preformat
            val end = min(dividerPositions[idx].preformat, preprocessed.length)
            numberParts.add(preprocessed.substring(start, end))

            lastCheckedDividerPosition = end
            if (end == preprocessed.length) {
                break
            }
        }
        // the last piece
        var overflowed = ""
        if (lastCheckedDividerPosition < preprocessed.length) {
            numberParts.add(
                // Make sure the end won't exceed the issuer's `numberLength`.
                preprocessed.substring(
                    lastCheckedDividerPosition,
                    min(preprocessed.length, cardIssuer.cardNumberLength)
                )
            )
            if (preprocessed.length > cardIssuer.cardNumberLength) {
                overflowed = preprocessed.substring(cardIssuer.cardNumberLength)
            }
        }

        val formattedNumber = numberParts.joinToString(" ")
        return CardNumberFormattedResult(
            numberString = formattedNumber,
            overflowedInput = overflowed
        )
    }

    private fun checkCardIssuerUpdating(input: String, inputStartPos: Int, inputCount: Int) {
        if (cardIssuer == CardIssuer.Unknown
            || (inputStartPos + inputCount) <= brandCheckingDigitsThreshold
        ) {
            val newIssuer = checkCardIssuer(input)
            if (cardIssuer !== newIssuer) {
                cardIssuer = newIssuer
                stateListener?.onCreditCardIssuerChanged(newIssuer)
            }
        }
    }

    private fun checkCardIssuer(formattedNumber: String): CardIssuer {
        val stripped = formattedNumber.asPureCreditCardNumber()
        val validIssuer = validCardIssuer.firstOrNull { issuer ->
            issuer.identificationNumber
                .firstOrNull { idNumber -> stripped.startsWith(idNumber) } != null
        }
        return validIssuer ?: CardIssuer.Unknown
    }

    private fun notifyCardNumberInputState(
        formattedResult: CardNumberFormattedResult,
        inputStartPos: Int,
        inputCount: Int,
        cursorPosition: Int
    ) {
        val cardNumberLength = cardIssuer.formattedCardNumberLength
        if (formattedResult.numberString.length >= cardNumberLength) {
            // Guard for the user's "releasing pressure" action...
            if (inputCount > 0) {
                val strippedNumber = formattedResult.numberString.asPureCreditCardNumber()
                stateListener?.onCreditCardNumberFinishedEditing(
                    strippedNumber,
                    formattedResult.overflowedInput
                )

                // Here's another edge case:
                // We want to notify that the last number's editing event.
                // But when the card is invalid, user kept pressing the keyboard,
                // it's unnecessary to notify the pressing(which may cause
                // the mock card view's last digit performs animation)
                if (inputStartPos < cardIssuer.formattedCardNumberLength) {
                    stateListener?.onEditCreditCardNumber(strippedNumber.length)
                }
            }
        } else {
            // Clear errors when this is a normal editing.
            error = null
            stateListener?.onClearCreditCardNumberErrors()
            val dividersBeforeCursor = cardIssuer.dividerPositions.count { position ->
                position.formatted < cursorPosition
            }
            stateListener?.onEditCreditCardNumber(cursorPosition - dividersBeforeCursor)
        }
    }
}
