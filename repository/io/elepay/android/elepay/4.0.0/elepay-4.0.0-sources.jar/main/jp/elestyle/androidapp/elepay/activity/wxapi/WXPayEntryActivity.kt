package jp.elestyle.androidapp.elepay.activity.wxapi

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatActivity
import com.tencent.mm.opensdk.constants.ConstantsAPI
import com.tencent.mm.opensdk.modelbase.BaseReq
import com.tencent.mm.opensdk.modelbase.BaseResp
import com.tencent.mm.opensdk.openapi.IWXAPI
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler
import com.tencent.mm.opensdk.openapi.WXAPIFactory
import jp.elestyle.androidapp.elepay.processor.WechatPayPerformer

@Keep
internal class WXPayEntryActivity : AppCompatActivity(), IWXAPIEventHandler {

    @Suppress("PrivatePropertyName")
    private val TAG = "WXPayEntryActivity"

    private lateinit var iwxApi: IWXAPI

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        iwxApi = WXAPIFactory.createWXAPI(this, WechatPayPerformer.apiKey).apply {
            registerApp(WechatPayPerformer.apiKey)
        }
        iwxApi.handleIntent(intent, this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

        setIntent(intent)
        iwxApi.handleIntent(intent, this)
    }

    override fun onReq(baseReq: BaseReq) {

    }

    override fun onResp(baseResp: BaseResp) {
        Log.d(TAG, "onPayFinish, errCode = " + baseResp.errCode)
        finish()

        if (baseResp.type == ConstantsAPI.COMMAND_PAY_BY_WX) {
            WechatPayPerformer.processWechatPayResponse(baseResp)
        }
    }
}