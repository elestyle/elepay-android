package jp.elestyle.androidapp.elepay.utils

import android.app.Activity
import android.content.Intent
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.activity.internal.ElepayWebProcessorActivity
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * A reusable payment flow that calls the execute API and handles possible 3DS2 verification.
 *
 * Flow:
 * 1. Call `ServerAPIClient.execute(chargeId, token)`
 * 2. If response has no `redirectUrl` → check `status` for success/failure
 * 3. If response has `redirectUrl` → open [ElepayWebProcessorActivity] for 3DS2 verification
 * 4. After 3DS2 → poll charge status via [ServerStatusPoller]
 *
 * This component is payment-method agnostic. Any processor can use it by calling [start] or [execute].
 */
internal object ExecutePaymentFlow {

    private val mainScope = MainScope()

    /**
     * Start the execute flow.
     *
     * @param activity      The hosting activity (used for launching 3DS WebView if needed).
     *                      This activity will be finished after the flow completes.
     * @param paymentData   Payment metadata.
     * @param token         The payment token (e.g. Google Pay token).
     */
    fun start(activity: Activity, paymentData: PaymentCommon, token: String) {
        mainScope.launch {
            val result = execute(activity, paymentData, token)
            notifyResultAndFinish(activity, result, paymentData.id)
        }
    }

    /**
     * Execute the payment flow and return the result.
     *
     * Unlike [start], this does not finish the activity or notify via [ElepayResultHandlerManager].
     * The caller is responsible for handling the returned [ElepayResult].
     *
     * @param activity      The hosting activity (used for launching 3DS WebView if needed).
     * @param paymentData   Payment metadata.
     * @param token         The payment token.
     */
    suspend fun execute(activity: Activity, paymentData: PaymentCommon, token: String): ElepayResult {
        val paymentId = paymentData.id

        return when (val result = ServerAPIClient.execute(paymentId, token)) {
            is ResultType.Failed -> {
                ElepayResult.Failed(
                    paymentId,
                    ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            paymentData.provider,
                            paymentData.method,
                            ErrorCode.FAILED_CAPTURE
                        ),
                        message = result.error.message
                    )
                )
            }

            is ResultType.Succeeded -> {
                val executeResult = result.data
                val redirectUrl = executeResult.redirectUrl

                if (redirectUrl.isNullOrEmpty()) {
                    // No 3DS required. Determine result from status.
                    when (executeResult.status) {
                        "captured" -> ElepayResult.Succeeded(paymentId)
                        "pending" -> pollResult(paymentData)
                        else -> ElepayResult.Failed(
                            paymentId,
                            ElepayError.PaymentFailure(
                                errorCode = ErrorCodeGenerator.generate(
                                    PlatformCode.SDK,
                                    paymentData.provider,
                                    paymentData.method,
                                    ErrorCode.FAILED_CAPTURE
                                ),
                                message = "Unexpected execute status: ${executeResult.status}"
                            )
                        )
                    }
                } else {
                    // 3DS2 verification required. Launch WebView.
                    perform3dsVerification(activity, paymentData, redirectUrl)
                }
            }
        }
    }

    private suspend fun perform3dsVerification(
        activity: Activity,
        paymentData: PaymentCommon,
        redirectUrl: String
    ): ElepayResult {
        val paymentId = paymentData.id
        val threeDsHandlerKey = "execute_3ds_$paymentId"

        val threeDsResult = suspendCancellableCoroutine { cont ->
            ElepayResultHandlerManager.registerResultHandler(
                { result -> cont.resume(result) },
                threeDsHandlerKey
            )

            val intent = Intent(activity, ElepayWebProcessorActivity::class.java).apply {
                putExtra(
                    ElepayWebProcessorActivity.IntentExtraKey.PAYMENT_DATA.rawValue,
                    paymentData
                )
                putExtra(
                    ElepayWebProcessorActivity.IntentExtraKey.EXPLICIT_PAYMENT_ID.rawValue,
                    threeDsHandlerKey
                )
                putExtra(
                    ElepayWebProcessorActivity.IntentExtraKey.TARGET_URL.rawValue,
                    redirectUrl
                )
            }
            activity.startActivity(intent)
        }

        if (threeDsResult is ElepayResult.Canceled) {
            return ElepayResult.Canceled(paymentId)
        }

        return pollResult(paymentData)
    }

    private suspend fun pollResult(paymentData: PaymentCommon): ElepayResult {
        val pollPolicy = ServerStatusPoller.PollPolicy(
            statusValidating = { status -> status != "pending" },
            intervalMillis = 1000L,
            maxPollingCount = 10,
            extraFailureMessage = "Execute payment flow"
        )
        return ServerStatusPoller.poll(paymentData, pollPolicy)
    }

    private fun notifyResultAndFinish(
        activity: Activity,
        result: ElepayResult,
        paymentId: String
    ) {
        ElepayResultHandlerManager.notifyResult(result, paymentId)
        activity.runOnUiThread { activity.finish() }
    }
}
