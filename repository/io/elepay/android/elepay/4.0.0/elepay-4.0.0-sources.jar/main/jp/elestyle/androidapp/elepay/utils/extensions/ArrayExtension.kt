package jp.elestyle.androidapp.elepay.utils.extensions

internal fun <T> Array<out T>.contains(predicate: (T) -> Boolean): Boolean = firstOrNull(predicate) != null