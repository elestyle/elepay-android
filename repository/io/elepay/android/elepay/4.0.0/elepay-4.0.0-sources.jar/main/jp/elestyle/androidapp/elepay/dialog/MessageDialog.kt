package jp.elestyle.androidapp.elepay.dialog

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import jp.elestyle.androidapp.elepay.R

internal class MessageDialog : DialogFragment() {
    companion object {
        fun newInstance(message: String?): MessageDialog {
            val ret = MessageDialog()
            if (message != null) {
                ret.arguments = Bundle().apply {
                    putString("message", message)
                }
            }
            return ret
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val message = arguments?.getString("message") ?: ""
        return AlertDialog.Builder(requireActivity())
            .setMessage(message)
            .setPositiveButton(R.string.button_title_close) { _, _ -> }
            .create()
    }
}