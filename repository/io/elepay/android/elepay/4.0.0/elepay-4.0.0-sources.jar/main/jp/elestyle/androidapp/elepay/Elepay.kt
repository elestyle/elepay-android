package jp.elestyle.androidapp.elepay

import android.app.Activity
import android.content.Context
import androidx.annotation.Keep
import com.tencent.mm.opensdk.modelbase.BaseResp
import jp.elestyle.androidapp.elepay.core.interfaces.CheckoutModuleProvider
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ChargeDataStatus
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.RedirectType
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.AlipayPlusProcessor
import jp.elestyle.androidapp.elepay.processor.AlipayProcessor
import jp.elestyle.androidapp.elepay.processor.AllpayProcessor
import jp.elestyle.androidapp.elepay.processor.AmazonPayProcessor
import jp.elestyle.androidapp.elepay.processor.AtoneProcessor
import jp.elestyle.androidapp.elepay.processor.AuPayProcessor
import jp.elestyle.androidapp.elepay.processor.DocomoPayProcessor
import jp.elestyle.androidapp.elepay.processor.ElepayProcessor
import jp.elestyle.androidapp.elepay.processor.GmoProcessor
import jp.elestyle.androidapp.elepay.processor.JcoinPayProcessor
import jp.elestyle.androidapp.elepay.processor.KsherProcessor
import jp.elestyle.androidapp.elepay.processor.LinePayProcessor
import jp.elestyle.androidapp.elepay.processor.MerpayProcessor
import jp.elestyle.androidapp.elepay.processor.PaidyProcessor
import jp.elestyle.androidapp.elepay.processor.PayPayProcessor
import jp.elestyle.androidapp.elepay.processor.PaygentProcessor
import jp.elestyle.androidapp.elepay.processor.RakutenBankProcessor
import jp.elestyle.androidapp.elepay.processor.RakutenPayProcessor
import jp.elestyle.androidapp.elepay.processor.SonyPaymentProcessor
import jp.elestyle.androidapp.elepay.processor.StripeProcessor
import jp.elestyle.androidapp.elepay.processor.UnionPayProcessor
import jp.elestyle.androidapp.elepay.processor.WebBrowserPayProcessor
import jp.elestyle.androidapp.elepay.processor.WechatPayPerformer
import jp.elestyle.androidapp.elepay.processor.WechatPayProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.GooglePayHelper
import jp.elestyle.androidapp.elepay.utils.InfoReporter
import jp.elestyle.androidapp.elepay.utils.IntegrationChecker
import jp.elestyle.androidapp.elepay.utils.PayPayHelper
import jp.elestyle.androidapp.elepay.utils.RCManager
import jp.elestyle.androidapp.elepay.utils.RakutenPayHelper
import jp.elestyle.androidapp.elepay.core.locale.LanguageKey
import jp.elestyle.androidapp.elepay.core.locale.Localization
import jp.elestyle.androidapp.elepay.core.theme.ElepayTheme
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.utils.parsing.DataParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject
import java.util.UUID

/**
 * Elepay SDK API
 *
 * This class is supposed to be used as the interface of the SDK. All process is performed through this class.
 */
@Suppress("unused", "MemberVisibilityCanBePrivate")
@Keep
object Elepay {
    private const val tag = "Elepay"
    private val processors = mutableMapOf(
        PaymentMethodProvider.ALIPAY to AlipayProcessor,
        PaymentMethodProvider.ALLPAY to AllpayProcessor,
        PaymentMethodProvider.WECHAT_PAY to WechatPayProcessor,
        PaymentMethodProvider.LINE_PAY to LinePayProcessor,
        PaymentMethodProvider.PAIDY to PaidyProcessor,
        PaymentMethodProvider.PAYPAY to PayPayProcessor,
        PaymentMethodProvider.MERPAY to MerpayProcessor,
        PaymentMethodProvider.KSHER to KsherProcessor,
        PaymentMethodProvider.AMAZON_PAY to AmazonPayProcessor,
        PaymentMethodProvider.DOCOMO_PAY to DocomoPayProcessor,
        PaymentMethodProvider.ATONE to AtoneProcessor,
        PaymentMethodProvider.PAYGENT to PaygentProcessor,
        PaymentMethodProvider.AUPAY to AuPayProcessor,
        PaymentMethodProvider.RAKUTEN_PAY to RakutenPayProcessor,
        PaymentMethodProvider.JCOINPAY to JcoinPayProcessor,
        PaymentMethodProvider.UNION_PAY to UnionPayProcessor,
        PaymentMethodProvider.ALIPAY_PLUS to AlipayPlusProcessor,
        PaymentMethodProvider.GMO to GmoProcessor,
        PaymentMethodProvider.RAKUTEN_BANK to RakutenBankProcessor,
        PaymentMethodProvider.SONY_PAYMENT to SonyPaymentProcessor,
        PaymentMethodProvider.ELEPAY_WEB_BROWSER_PAY to WebBrowserPayProcessor,
    ).also {
        if (IntegrationChecker.isAvailable("com.stripe.android.PaymentConfiguration")) {
            it[PaymentMethodProvider.STRIPE] = StripeProcessor
        }
    }
    private val coroutineScope = CoroutineScope(Dispatchers.Default)

    /**
     * Setup elepay SDK.
     *
     * This method should be called before calling any other elepay SDK methods.
     * The configuration passed to elepay SDK will be used only once, and all configurations are not
     * mutable.
     *
     * @param config See [ElepayConfiguration] for details.
     */
    @JvmStatic
    fun setup(config: ElepayConfiguration) {
        android.util.Log.i(tag, "setup. sdk version: ${BuildConfig.LIB_VERSION_CODE}")
        ConfigManager.update(config)
    }

    private suspend fun requireConfiguration(processor: ElepayProcessor): ElepayError? {
        if (processor.isConfigured) {
            return null
        }

        return when (val result = ConfigManager.fetchConfigs()) {
            is ResultType.Succeeded -> {
                result.data.providerConfigs.forEach { config ->
                    processors[config.asPaymentMethodProvider]?.setup(config)
                }
                null
            }

            is ResultType.Failed -> {
                result.error
            }
        }
    }

    /**
     * Check if Google Pay is ready to use.
     *
     * Make sure call this method after [setup].
     *
     * The checking is performed asynchronously.
     * This method do not verify if the app's environment is good to use Google Pay.
     */
    @JvmStatic
    fun checkIfGooglePayIsReadyToUse(
        activity: Activity,
        resultListener: IsGooglePayReadyToUseListener
    ) = checkIfGooglePayIsReadyToUse(activity) { result ->
        resultListener.onFinishCheckingIsGooglePayReadyToUse(result)
    }

    /**
     * Check if Google Pay is ready to use.
     *
     * Make sure call this method after [setup].
     *
     * The checking is performed asynchronously.
     * This method do not verify if the app's environment is good to use Google Pay.
     */
    @JvmStatic
    fun checkIfGooglePayIsReadyToUse(activity: Activity, resultHandler: (Boolean) -> Unit) =
        coroutineScope.launch {
            val result = checkIfGooglePayIsReadyToUse(activity)
            resultHandler(result)
        }

    /**
     * Check if Google Pay is ready to use.
     *
     * Make sure call this method after [setup].
     *
     * The checking is performed asynchronously.
     * This method do not verify if the app's environment is good to use Google Pay.
     */
    suspend fun checkIfGooglePayIsReadyToUse(activity: Activity): Boolean =
        GooglePayHelper.isGooglePayReadyToUse(activity)

    /**
     * Check if the PayPay app could be open for the payment processing.
     *
     * User may need this method before showing PayPay payment method. Because PayPay currently
     * only supports in-app processing, the PayPay app is required for PayPay payment processing.
     */
    @JvmStatic
    fun checkIfPayPayIsReadyToUse(activity: Activity): Boolean =
        PayPayHelper.isPayPayInstalled(activity)

    /**
     * Check if the Rakuten Pay app is installed to use Rakuten Pay.
     *
     * User may need this method before showing Rakuten Pay payment method.
     * Because Rakuten Pay currently only supports in-app processing.
     */
    fun checkIfRakutenPayIsReadyToUse(activity: Activity): Boolean =
        RakutenPayHelper.isRPayInstalled(activity)

    /**
     * Change the language which is used by elepay SDK internally.
     *
     * This change only takes effects **before** the payment processing.
     * After calling [processPayment], all changes to the [LanguageKey] will be ignored.
     *
     * @param languageKey The new language key to be applied by the elepay SDK.
     */
    @JvmStatic
    fun changeLanguageKey(languageKey: LanguageKey) {
        ConfigManager.languageKey = languageKey
    }

    /**
     * Change the theme of the elepay SDK ui components.
     *
     * This change only takes effects **before** the payment processing.
     * After calling [processPayment], [processSource] or [checkout],
     * all changes to the [theme] will be ignored.
     *
     * @param theme The new theme to be applied by the elepay SDK.
     */
    fun changeTheme(theme: ElepayTheme) {
        ConfigManager.theme = theme
    }

    /**
     * Process the payment request.
     *
     * This is a Java compatible version.
     *
     * @param chargeData A JSON object that contains the payment data, data structure may be
     * different from payment methods.
     * @param fromActivity An [Activity] instance used to redirect to show payment processing UI.
     * @param resultListener The result handler
     * @return `true` for successfully parsed the payment data and handled the data to the processor.
     */
    @JvmStatic
    fun processPayment(
        chargeData: JSONObject,
        fromActivity: Activity,
        resultListener: ElepayResultListener
    ): Boolean =
        processPayment(chargeData, fromActivity) { result -> resultListener.onElepayResult(result) }

    /**
     * Process the payment request.
     *
     * Note: This method is supposed to be used when your project could neither use Kotlin nor
     * support Java 8 lambda expression. If your project is based on Kotlin or can uses Java 8
     * lambda expressions, consider using the API that takes a [ElepayResultHandler] callback.
     *
     * @param chargeDataString The raw string value of the charge data JSON object that contains
     * the payment data.
     * @param fromActivity An [Activity] instance used to redirect to show payment processing UI.
     * @param resultListener The result handler
     * @return `true` for successfully parsed the payment data and handled the data to the processor.
     */
    @JvmStatic
    fun processPayment(
        chargeDataString: String,
        fromActivity: Activity,
        resultListener: ElepayResultListener
    ): Boolean =
        processPayment(chargeDataString, fromActivity) { result ->
            resultListener.onElepayResult(result)
        }

    /**
     * Process the payment request.
     *
     * @param chargeDataString The raw string value of the charge data JSON object that contains
     * the payment data.
     * @param fromActivity An [Activity] instance used to redirect to show payment processing UI.
     * @param resultHandler The result handler
     * @return `true` for successfully parsed the payment data and passed the data to the processor.
     */
    @JvmStatic
    fun processPayment(
        chargeDataString: String,
        fromActivity: Activity,
        resultHandler: (ElepayResult) -> Unit
    ): Boolean = try {
        val chargeData = JSONObject(chargeDataString)
        processPayment(chargeData, fromActivity, resultHandler)
    } catch (e: JSONException) {
        val error = ElepayError.InvalidPayload(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.ENDUSER,
                null,
                null,
                ErrorCode.INVALID_PAYLOAD
            ),
            message = "Failed parsing charge data string."
        )
        val failure = ElepayResult.Failed(paymentId = null, error = error)
        val invalidJsonWrapper = JSONObject().apply {
            put("invalidJson", chargeDataString)
        }
        InfoReporter.reportFailure(
            failure,
            InfoReporter.RefData(invalidJsonWrapper, PaymentDataType.CHARGE),
            fromActivity
        )
        resultHandler(failure)
        false
    }

    /**
     * Process the payment request.
     *
     * @param chargeData A JSON object that contains the payment data, data structure may be
     * different from payment methods.
     * @param fromActivity An [Activity] instance used to redirect to show payment processing UI.
     * @param resultHandler The result handler
     * @return `true` for successfully parsed the payment data and passed the data to the processor.
     */
    @JvmStatic
    fun processPayment(
        chargeData: JSONObject,
        fromActivity: Activity,
        resultHandler: (ElepayResult) -> Unit
    ): Boolean = when (val result = DataParser.parseChargeData(chargeData)) {
        is ResultType.Failed -> {
            val failure = ElepayResult.Failed(paymentId = null, error = result.error)
            InfoReporter.reportFailure(
                failure,
                InfoReporter.RefData(chargeData, PaymentDataType.CHARGE),
                fromActivity
            )
            resultHandler(failure)
            false
        }

        is ResultType.Succeeded -> {
            when {
                !ConfigManager.isInited -> {
                    val failure = generateSdkUninitFailure()
                    InfoReporter.reportFailure(
                        failure,
                        InfoReporter.RefData(chargeData, PaymentDataType.CHARGE),
                        fromActivity
                    )
                    resultHandler(failure)
                    false
                }

                result.data.status == ChargeDataStatus.PENDING -> {
                    processPayment(
                        chargeData = result.data,
                        fromActivity = fromActivity,
                        resultHandler = resultHandler
                    )
                }

                else -> {
                    resultHandler(ElepayResult.Succeeded(paymentId = result.data.id))
                    true
                }
            }
        }
    }

    private fun processPayment(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler
    ): Boolean {
        val provider = if (chargeData.redirectType != RedirectType.NATIVE)
            PaymentMethodProvider.ELEPAY_WEB_BROWSER_PAY
        else
            chargeData.provider
        val processor = processors[provider]
        if (processor == null) {
            val failure = ElepayResult.Failed(
                paymentId = chargeData.id,
                error = ElepayError.UnsupportedPaymentMethod(provider.rawValue)
            )
            InfoReporter.reportFailure(
                failure,
                InfoReporter.RefData(chargeData.rawJson, chargeData.paymentCommon.dataType),
                fromActivity
            )
            resultHandler(failure)
            return false
        }

        coroutineScope.launch {
            val wrappedHandler = prepareProcessing(
                context = fromActivity.applicationContext,
                jsonData = chargeData.rawJson,
                paymentCommon = chargeData.paymentCommon,
                originalHandler = resultHandler
            )
            when (val err = requireConfiguration(processor)) {
                is ElepayError -> {
                    wrappedHandler(ElepayResult.Failed(chargeData.id, err))
                }

                else -> {
                    processor.processCharge(chargeData, fromActivity, wrappedHandler)
                }
            }
        }

        return true
    }

    private fun generateSdkUninitFailure(): ElepayResult.Failed = ElepayResult.Failed(
        null,
        ElepayError.SDKNotSetup(
            ErrorCodeGenerator.generate(PlatformCode.ENDUSER, null, null, ErrorCode.UNINIT),
            message = "The SDK has not been initialized. Make sure the `Elepay.setup` is called correctly."
        )
    )

    private fun prepareProcessing(
        context: Context,
        jsonData: JSONObject,
        paymentCommon: PaymentCommon,
        originalHandler: ElepayResultHandler
    ): ElepayResultHandler {
        coroutineScope.launch {
            RCManager.verifyPayment(paymentCommon, context)
        }

        // Set language for every payment, so that user can change language at any time before
        // payment processing.
        Localization.setup(context, ConfigManager.languageKey)

        return { result ->
            // Release the resources created temporarily.
            Localization.cleanup()

            if (result is ElepayResult.Failed) {
                // Report if any errors occurred.
                InfoReporter.reportFailure(
                    result,
                    InfoReporter.RefData(jsonData, paymentCommon.dataType),
                    context
                )
            } else {
                // Check the pending reports on other cases.
                checkAndUploadPendingReports(context)
            }

            // Finally call the original callback.
            originalHandler(result)
        }
    }

    private fun checkAndUploadPendingReports(context: Context) {
        // Check cached reports in another coroutine.
        coroutineScope.launch {
            InfoReporter.sendCachedReports(context)
        }
    }

    /**
     * Process the source request.
     *
     * This is a Java compatible version.
     *
     * @param sourceJson A JSON object that contains the source data.
     * @param fromActivity An [Activity] instance used to redirect to show payment processing UI.
     * @param resultListener The result handler
     * @return `true` for successfully parsed the payment data and passed the data to the processor.
     */
    @JvmStatic
    fun processSource(
        sourceJson: JSONObject,
        fromActivity: Activity,
        resultListener: ElepayResultListener
    ): Boolean =
        processSource(sourceJson, fromActivity) { result -> resultListener.onElepayResult(result) }

    /**
     * Process the source request.
     *
     * Note: This method is supposed to be used when your project could neither use Kotlin nor
     * support Java 8 lambda expression. If your project is based on Kotlin or can uses Java 8
     * lambda expressions, consider using the API that takes a [ElepayResultHandler] callback.
     *
     * @param sourceString The raw string value of the source JSON object.
     * @param fromActivity An [Activity] instance used to redirect to show payment processing UI.
     * @param resultListener The result handler
     * @return `true` for successfully parsed the payment data and passed the data to the processor.
     */
    @JvmStatic
    fun processSource(
        sourceString: String,
        fromActivity: Activity,
        resultListener: ElepayResultListener
    ): Boolean =
        processSource(sourceString, fromActivity) { result ->
            resultListener.onElepayResult(result)
        }

    /**
     * Process the source request.
     *
     * @param sourceString The raw string value of the source data JSON.
     * @param fromActivity An [Activity] instance used to redirect to show payment processing UI.
     * @param resultHandler The result handler
     * @return `true` for successfully parsed the payment data and passed the data to the processor.
     */
    @JvmStatic
    fun processSource(
        sourceString: String,
        fromActivity: Activity,
        resultHandler: (ElepayResult) -> Unit
    ): Boolean = try {
        val chargeData = JSONObject(sourceString)
        processSource(chargeData, fromActivity, resultHandler)
    } catch (e: JSONException) {
        val error = ElepayError.InvalidPayload(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.ENDUSER,
                null,
                null,
                ErrorCode.INVALID_PAYLOAD
            ),
            message = "Failed parsing charge data string."
        )
        val failure = ElepayResult.Failed(paymentId = null, error = error)
        val invalidJsonWrapper = JSONObject().apply {
            put("invalidJson", sourceString)
        }
        InfoReporter.reportFailure(
            failure,
            InfoReporter.RefData(invalidJsonWrapper, PaymentDataType.SOURCE),
            fromActivity
        )
        resultHandler(failure)
        false
    }

    /**
     * Process the payment request.
     *
     * @param sourceJson A JSON object that contains the payment data, data structure may be
     * different from payment methods.
     * @param fromActivity An [Activity] instance used to redirect to show payment processing UI.
     * @param resultHandler The result handler
     * @return `true` for successfully parsed the payment data and passed the data to the processor.
     */
    @JvmStatic
    fun processSource(
        sourceJson: JSONObject,
        fromActivity: Activity,
        resultHandler: (ElepayResult) -> Unit
    ): Boolean = when (val result = DataParser.parseSourceData(sourceJson)) {
        is ResultType.Failed -> {
            val failure = ElepayResult.Failed(paymentId = null, error = result.error)
            InfoReporter.reportFailure(
                failure,
                InfoReporter.RefData(sourceJson, PaymentDataType.SOURCE),
                fromActivity
            )
            resultHandler(failure)
            false
        }

        is ResultType.Succeeded -> {
            if (!ConfigManager.isInited) {
                val failure = generateSdkUninitFailure()
                InfoReporter.reportFailure(
                    failure,
                    InfoReporter.RefData(sourceJson, PaymentDataType.SOURCE),
                    fromActivity
                )
                resultHandler(failure)
                false
            } else {
                processSource(
                    sourceData = result.data,
                    fromActivity = fromActivity,
                    resultHandler = resultHandler
                )
            }
        }
    }

    private fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler
    ): Boolean {
        val provider = if (sourceData.redirectType != RedirectType.NATIVE)
            PaymentMethodProvider.ELEPAY_WEB_BROWSER_PAY
        else
            sourceData.provider
        val processor = processors[provider]
        if (processor == null) {
            val failure = ElepayResult.Failed(
                paymentId = sourceData.id,
                error = ElepayError.UnsupportedPaymentMethod(provider.rawValue)
            )
            InfoReporter.reportFailure(
                failure,
                InfoReporter.RefData(sourceData.rawJson, sourceData.paymentCommon.dataType),
                fromActivity
            )
            resultHandler(failure)
            return false
        }

        coroutineScope.launch {
            val wrappedHandler = prepareProcessing(
                context = fromActivity.applicationContext,
                jsonData = sourceData.rawJson,
                paymentCommon = sourceData.paymentCommon,
                originalHandler = resultHandler
            )
            when (val err = requireConfiguration(processor)) {
                is ElepayError -> {
                    wrappedHandler(ElepayResult.Failed(sourceData.id, err))
                }

                else -> {
                    processor.processSource(sourceData, fromActivity, wrappedHandler)
                }
            }
        }

        return true
    }

    /**
     * Process the checkout request.
     *
     * Note: This method is supposed to be used when your project could neither use Kotlin nor
     * support Java 8 lambda expression. If your project is based on Kotlin or can uses Java 8
     * lambda expressions, consider using the API that takes a [ElepayResultHandler] callback.
     *
     * @param checkoutJsonString The raw string value of the checkout JSON object.
     * @param fromActivity An [Activity] instance used to show payment processing UI.
     * @param resultListener The result handler
     */
    @JvmStatic
    fun checkout(
        checkoutJsonString: String,
        fromActivity: Activity,
        resultListener: ElepayResultListener
    ) = checkout(checkoutJsonString, fromActivity) {
        resultListener.onElepayResult(it)
    }

    /**
     * Process the checkout request.
     *
     * Note: This method is supposed to be used when your project could neither use Kotlin nor
     * support Java 8 lambda expression. If your project is based on Kotlin or can uses Java 8
     * lambda expressions, consider using the API that takes a [ElepayResultHandler] callback.
     *
     * @param checkoutJson A JSON object contains the checkout data.
     * @param fromActivity An [Activity] instance used to show payment processing UI.
     * @param resultListener The result handler
     */
    @JvmStatic
    fun checkout(
        checkoutJson: JSONObject,
        fromActivity: Activity,
        resultListener: ElepayResultListener
    ) = checkout(checkoutJson, fromActivity) {
        resultListener.onElepayResult(it)
    }

    /**
     * Process the checkout request.
     *
     * @param checkoutJsonString A string value represents the JSON object which contains the
     * checkout data.
     * @param fromActivity An [Activity] instance used to show processing UI.
     * @param resultHandler The result handler
     */
    @JvmStatic
    fun checkout(
        checkoutJsonString: String,
        fromActivity: Activity,
        resultHandler: (ElepayResult) -> Unit
    ) = try {
        checkout(JSONObject(checkoutJsonString), fromActivity, resultHandler)
    } catch (e: JSONException) {
        val error = ElepayError.InvalidPayload(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.ENDUSER,
                null,
                null,
                ErrorCode.INVALID_PAYLOAD
            ),
            message = "Failed parsing checkout data string."
        )
        val failure = ElepayResult.Failed(paymentId = null, error = error)
        val invalidJsonWrapper = JSONObject().apply {
            put("invalidJson", checkoutJsonString)
        }
        InfoReporter.reportFailure(
            failure,
            InfoReporter.RefData(invalidJsonWrapper, PaymentDataType.CHECKOUT),
            fromActivity
        )
        resultHandler(failure)
    }

    /**
     * Process the checkout request.
     *
     * @param checkoutJson A JSON object contains the checkout data.
     * @param fromActivity An [Activity] instance used to show processing UI.
     * @param resultHandler The result handler
     */
    @JvmStatic
    fun checkout(
        checkoutJson: JSONObject,
        fromActivity: Activity,
        resultHandler: (ElepayResult) -> Unit
    ) {
        if (!ConfigManager.isInited) {
            val failure = generateSdkUninitFailure()
            InfoReporter.reportFailure(
                failure,
                InfoReporter.RefData(checkoutJson, PaymentDataType.CHECKOUT),
                fromActivity
            )
            resultHandler(failure)
            return
        }

        val codeId = checkoutJson.optString("id", "").run {
            ifEmpty { UUID.randomUUID().toString() }
        }

        val checkout = CheckoutModuleProvider.getInstance()
        if (checkout != null && checkout.isCheckoutAvailable()) {
            checkout.startCheckout(fromActivity, checkoutJson, resultHandler, codeId)
        } else {
            val error = ElepayError.PaymentFailure(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    null,
                    null,
                    ErrorCode.UNINIT
                ),
                message = "Checkout module is not available. Make sure the elepay-checkout module is included in your project."
            )
            val failure = ElepayResult.Failed(paymentId = null, error = error)
            resultHandler(failure)
        }
    }

    /**
     * Process the Wechat Pay response explicitly.
     *
     * When start the Wechat Pay from elepay SDK and you have your own customised
     * WXPayEntryActivity for other purpose, you can pass the response here to let elepay handle
     * the result properly.
     *
     * @param baseResponse The response instance passed into WXPayEntryActivity.onResp
     */
    @JvmStatic
    fun processWechatPayResponse(baseResponse: BaseResp) {
        WechatPayPerformer.processWechatPayResponse(baseResponse)
    }

    internal fun retrieveProcessor(provider: PaymentMethodProvider): ElepayProcessor? =
        processors[provider]
}
