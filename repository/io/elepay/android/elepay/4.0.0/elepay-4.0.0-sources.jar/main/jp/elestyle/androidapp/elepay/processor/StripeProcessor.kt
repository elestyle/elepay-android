package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import com.alipay.sdk.app.PayTask
import com.stripe.android.ApiResultCallback
import com.stripe.android.GooglePayConfig
import com.stripe.android.Stripe
import com.stripe.android.model.Source
import com.stripe.android.model.SourceParams
import com.stripe.android.model.Token
import jp.elestyle.androidapp.elepay.BuildConfig
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.googlepay.GooglePayProcessingActivity
import jp.elestyle.androidapp.elepay.activity.googlepay.StripeIntentGooglePayActivity
import jp.elestyle.androidapp.elepay.activity.internal.CreditCardProcessingActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.AlipayResultHelper.parseAlipayResult
import jp.elestyle.androidapp.elepay.processor.creditcard.LegacyStripeCreditCardProcessor
import jp.elestyle.androidapp.elepay.processor.creditcard.StripeIntentCreditCardProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.GooglePayHelper
import jp.elestyle.androidapp.elepay.utils.IntegrationChecker
import jp.elestyle.androidapp.elepay.utils.creditcard.CreditCardProcessingCenter
import jp.elestyle.androidapp.elepay.core.log
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Created by tanyin on 2018/02/05.
 */

internal object StripeProcessor : ElepayProcessor() {
    private val mainScope = MainScope()

    var publishableKey: String = ""
        private set
    private var appScheme: String = ""

    override fun setup(providerConfig: ElepayProviderConfig) {
        super.setup(providerConfig)
        if (providerConfig is ElepayProviderConfig.Stripe) {
            this.appScheme = providerConfig.appScheme
            this.publishableKey = providerConfig.publishableKey
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = when (chargeData.method) {

        PaymentMethod.ALIPAY -> {
            if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
            else processAlipay(
                chargeData = chargeData,
                resultHandler = resultHandler,
                fromActivity = fromActivity
            )
        }

        PaymentMethod.CREDIT_CARD -> {
            val clientSecret = chargeData.payload?.runCatching {
                JSONObject(this).optString("clientSecret").takeIf { it.isNotEmpty() }
            }?.getOrNull()
            processCreditCard(
                paymentData = chargeData.paymentCommon,
                clientSecret = clientSecret,
                fromActivity = fromActivity,
                resultHandler = resultHandler
            )
        }

        PaymentMethod.GOOGLE_PAY -> {
            val clientSecret = chargeData.payload?.runCatching {
                JSONObject(this).optString("clientSecret").takeIf { it.isNotEmpty() }
            }?.getOrNull()
            processGooglePay(
                clientSecret = clientSecret,
                paymentData = chargeData.paymentCommon,
                amount = chargeData.amount,
                currency = chargeData.currency,
                fromActivity = fromActivity,
                resultHandler = resultHandler
            )
        }

        else -> {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    paymentId = chargeData.id,
                    error = ElepayError.UnsupportedPaymentMethod("stripe ${chargeData.method.rawValue}")
                )
            )
            false
        }
    }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = when (sourceData.method) {
        PaymentMethod.CREDIT_CARD -> {
            val clientSecret = sourceData.payload?.runCatching {
                JSONObject(this).optString("clientSecret").takeIf { it.isNotEmpty() }
            }?.getOrNull()
            processCreditCard(
                sourceData.paymentCommon,
                clientSecret,
                fromActivity,
                resultHandler
            )
        }

        PaymentMethod.GOOGLE_PAY -> {
            val clientSecret = sourceData.payload?.runCatching {
                JSONObject(this).optString("clientSecret").takeIf { it.isNotEmpty() }
            }?.getOrNull()
            processGooglePay(
                clientSecret = clientSecret,
                paymentData = sourceData.paymentCommon,
                amount = "0", // Must be 0
                currency = "JPY", // Fixed to JPY since API does not return the currency data.
                fromActivity,
                resultHandler
            )
        }

        else -> {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    paymentId = sourceData.id,
                    error = ElepayError.UnsupportedPaymentMethod("stripe ${sourceData.method.rawValue}")
                )
            )

            false
        }
    }

    private fun processAlipay(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (!IntegrationChecker.isAlipayAvailable()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.id,
                    error = ElepayError.UninitializedPaymentMethod(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            null,
                            null,
                            ErrorCode.UNINIT
                        ),
                        paymentMethod = PaymentMethod.ALIPAY.rawValue,
                        message = "Have you installed Alipay sdk to your project?"
                    )
                ),
                handler = resultHandler
            )
            return false
        }
        if (appScheme.isEmpty() || publishableKey.isEmpty()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.id,
                    error = ElepayError.UninitializedPaymentMethod(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.STRIPE,
                            PaymentMethod.ALIPAY,
                            ErrorCode.UNINIT
                        ),
                        paymentMethod = PaymentMethod.ALIPAY.rawValue,
                        message = "Alipay is not well configured."
                    )
                ),
                handler = resultHandler
            )
            return false
        }

        val sourceParams = SourceParams.createAlipaySingleUseParams(
            chargeData.amount.toLong(),
            chargeData.currency,
            chargeData.name,
            chargeData.email,
            appScheme
        ).apply { metadata = mapOf("number" to chargeData.id) }

        Stripe(fromActivity, publishableKey).createSource(
            sourceParams = sourceParams,
            callback = object : ApiResultCallback<Source> {
                override fun onSuccess(result: Source) {
                    invokeAlipay(fromActivity, chargeData.id, result, resultHandler)
                }

                override fun onError(e: java.lang.Exception) {
                    if (BuildConfig.DEBUG) e.printStackTrace()
                    val err = ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.STRIPE,
                            PaymentMethod.ALIPAY,
                            ErrorCode.INVALID_DATA
                        ),
                        message = e.message ?: ""
                    )
                    postElepayResult(ElepayResult.Failed(chargeData.id, err), resultHandler)
                }

            })

        return true
    }

    private fun invokeAlipay(
        fromActivity: Activity,
        paymentId: String,
        stripeSource: Source,
        resultHandler: ElepayResultHandler?
    ) {
        stripeSource.sourceTypeData?.get("data_string")?.also { dataString ->
            if (dataString is String && JSONObject.NULL != dataString) {
                val payRunnable = Runnable {
                    val alipay = PayTask(fromActivity)
                    val result = alipay.payV2(dataString, true)
                    log("AlipayProcessor", result.toString())

                    parseAlipayResult(rawResult = result).apply {
                        // 判断resultStatus 为9000则代表支付成功
                        if (status == "9000") {
                            postElepayResult(
                                result = ElepayResult.Succeeded(paymentId),
                                handler = resultHandler
                            )
                        } else {
                            val error = ElepayError.PaymentFailure(
                                errorCode = ErrorCodeGenerator.generate(
                                    PlatformCode.SDK,
                                    PaymentMethodProvider.STRIPE,
                                    PaymentMethod.ALIPAY,
                                    ErrorCode.FAILED
                                ),
                                message = "Stripe-Alipay failed. $status"
                            )
                            postElepayResult(
                                result = ElepayResult.Failed(paymentId, error),
                                handler = resultHandler
                            )
                        }
                    }
                }

                Thread(payRunnable).start()
            } else {
                val error = ElepayError.PaymentFailure(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.STRIPE,
                        PaymentMethod.ALIPAY,
                        ErrorCode.FAILED
                    ),
                    message = "Invalid data_string."
                )
                postElepayResult(
                    result = ElepayResult.Failed(paymentId, error),
                    handler = resultHandler
                )
            }
        }
    }

    private fun processGooglePay(
        clientSecret: String?,
        paymentData: PaymentCommon,
        amount: String,
        currency: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {

        if (publishableKey.isEmpty() || ConfigManager.googlePayEnvironment == null) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = paymentData.id,
                    error = ElepayError.UninitializedPaymentMethod(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.STRIPE,
                            PaymentMethod.GOOGLE_PAY,
                            ErrorCode.UNINIT
                        ),
                        paymentMethod = PaymentMethod.GOOGLE_PAY.rawValue,
                        message = "Not well configured, or forgot to set Google Pay Env."
                    )
                ),
                handler = resultHandler
            )
            return false
        }

        if (clientSecret != null) {
            processStripeIntentGooglePay(clientSecret, paymentData, currency, fromActivity, resultHandler)
        } else {
            mainScope.launch {
                processLegacyGooglePay(paymentData, amount, currency, fromActivity, resultHandler)
            }
        }

        return true
    }

    private fun processStripeIntentGooglePay(
        clientSecret: String,
        paymentData: PaymentCommon,
        currency: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ) {
        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentData.id)
        }
        val intent = Intent(fromActivity, StripeIntentGooglePayActivity::class.java)
            .apply {
                putExtra(
                    StripeIntentGooglePayActivity.IntentExtraKey.CLIENT_SECRET.rawValue,
                    clientSecret
                )
                putExtra(
                    StripeIntentGooglePayActivity.IntentExtraKey.PAYMENT_BASE_DATA.rawValue,
                    paymentData
                )
                putExtra(
                    GooglePayProcessingActivity.IntentExtraKey.PAYMENT_DATA_CURRENCY.rawValue,
                    currency
                )
            }
        fromActivity.startActivity(intent)
    }

    private suspend fun processLegacyGooglePay(
        paymentData: PaymentCommon,
        amount: String,
        currency: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ) {
        if (!GooglePayHelper.isGooglePayReadyToUse(fromActivity)) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = paymentData.id,
                    error = ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            null,
                            null,
                            ErrorCode.DEVICE_NOT_SUPPORTED
                        ),
                        message = "This device does not support Google Pay."
                    )
                ),
                handler = resultHandler
            )
            return
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentData.id)
        }
        // Save this parser first. Google Pay will generate a "token" which is actually a json
        // object that could be processed by stripe. We'll parse it to get the real token that
        // could be processed by our server.
        GooglePayHelper.storeGatewayTokenParser(
            parser = { token ->
                try {
                    Token.fromJson(JSONObject(token))?.id ?: ""
                } catch (e: Exception) {
                    ""
                }
            },
            key = paymentData.id
        )
        val intent = Intent(fromActivity, GooglePayProcessingActivity::class.java)
            .apply {
                putExtra(
                    GooglePayProcessingActivity.IntentExtraKey.PAYMENT_BASE_DATA.rawValue,
                    paymentData
                )
                putExtra(
                    GooglePayProcessingActivity.IntentExtraKey.PAYMENT_DATA_AMOUNT.rawValue,
                    amount
                )
                putExtra(
                    GooglePayProcessingActivity.IntentExtraKey.PAYMENT_DATA_CURRENCY.rawValue,
                    currency
                )
                putExtra(
                    GooglePayProcessingActivity.IntentExtraKey.PAYMENT_DATA_REQUEST_JSON.rawValue,
                    composeGooglePayPaymentDataRequest().toString()
                )
            }
        fromActivity.startActivity(intent)
    }

    private fun composeGooglePayPaymentDataRequest(): JSONObject {
        val tokenizedSpec = GooglePayConfig(publishableKey).tokenizationSpecification
        val cardPaymentMethod = GooglePayHelper.generateCardParameters()
            .put("tokenizationSpecification", tokenizedSpec)
        return GooglePayHelper.generateBaseGooglePayParameter()
            .put("allowedPaymentMethods", JSONArray().put(cardPaymentMethod))
    }

    private fun processCreditCard(
        paymentData: PaymentCommon,
        clientSecret: String?,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (publishableKey.isEmpty()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = paymentData.id,
                    error = ElepayError.UninitializedPaymentMethod(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.STRIPE,
                            PaymentMethod.CREDIT_CARD,
                            ErrorCode.UNINIT
                        ),
                        paymentMethod = paymentData.method.rawValue,
                        message = "not well configured"
                    )
                ),
                handler = resultHandler
            )
            return false
        }

        val paymentId = paymentData.id
        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
        }
        CreditCardProcessingCenter[paymentId] = if (clientSecret == null) {
            val stripeInstance = Stripe(fromActivity.applicationContext, publishableKey)
            LegacyStripeCreditCardProcessor(stripeInstance, paymentData)
        } else {
            StripeIntentCreditCardProcessor(publishableKey, clientSecret, paymentData)
        }
        val intent = Intent(fromActivity, CreditCardProcessingActivity::class.java).apply {
            putExtra(CreditCardProcessingActivity.IntentExtraKey.PAYMENT_ID.rawValue, paymentId)
        }
        fromActivity.startActivity(intent)

        return true
    }
}
