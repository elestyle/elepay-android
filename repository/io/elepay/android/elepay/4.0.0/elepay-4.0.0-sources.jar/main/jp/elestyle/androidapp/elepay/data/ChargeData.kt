package jp.elestyle.androidapp.elepay.data

import android.os.Build
import android.os.Parcel
import android.os.Parcelable
import org.json.JSONObject

internal enum class ChargeDataStatus {
    PENDING, CAPTURED
}

/**
 * Internal used data structure.
 */
internal data class ChargeData(
    val paymentCommon: PaymentCommon,

    val amount: String,
    val currency: String,
    val name: String,
    val email: String,

    val payload: String?,

    val redirectUrl: String?,
    val redirectType: RedirectType,

    val status: ChargeDataStatus,

    val rawJson: JSONObject
) : Parcelable {
    // For convenience and compatibility
    val id: String get() = paymentCommon.id
    val method: PaymentMethod get() = paymentCommon.method
    val provider: PaymentMethodProvider get() = paymentCommon.provider

    constructor(parcel: Parcel) : this(
        paymentCommon = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            parcel.readParcelable(
                PaymentCommon::class.java.classLoader,
                PaymentCommon::class.java
            )!!
        } else {
            @Suppress("DEPRECATION")
            parcel.readParcelable<PaymentCommon>(PaymentCommon::class.java.classLoader)!!
        },
        amount = parcel.readString() ?: "",
        currency = parcel.readString() ?: "",
        name = parcel.readString() ?: "",
        email = parcel.readString() ?: "",
        payload = parcel.readString()?.run { if (this == "null") null else this },
        redirectUrl = parcel.readString()?.run { if (this == "null") null else this },
        redirectType = RedirectType.from(parcel.readString() ?: "any") ?: RedirectType.NATIVE,
        status = ChargeDataStatus.values()[parcel.readInt()],
        rawJson = JSONObject(parcel.readString() ?: "{}")
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeParcelable(paymentCommon, 0)
        parcel.writeString(amount)
        parcel.writeString(currency)
        parcel.writeString(name)
        parcel.writeString(email)
        parcel.writeString(payload)
        parcel.writeString(redirectType.rawValue)
        parcel.writeString(redirectUrl)
        parcel.writeInt(status.ordinal)
        parcel.writeString(rawJson.toString())
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object {
        @Suppress("unused")
        @JvmField
        val CREATOR = object : Parcelable.Creator<ChargeData> {
            override fun createFromParcel(parcel: Parcel): ChargeData {
                return ChargeData(parcel)
            }

            override fun newArray(size: Int): Array<ChargeData?> {
                return arrayOfNulls(size)
            }
        }
    }
}