package jp.elestyle.androidapp.elepay.utils

object ApiVersion {
    /**
     * The latest server API version code.
     *
     * This is irrelative to the SDK's version. Just used by the server validation.
     * If the user does not require a specific version, this is the default value.
     */
    private const val currentVersionCode = "2020-06-16"

    /**
     * User can change this value to require the server uses another specific API version.
     * Note: If you want to do the change, make sure the value is valid. Contact an elepay support
     * is recommended.
     */
    var versionCode: String = currentVersionCode
}