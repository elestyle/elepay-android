package jp.elestyle.androidapp.elepay.view

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Context
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.AttributeSet
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.view.doOnLayout
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.utils.creditcard.CardIssuer

internal class MockCreditCardNumberView : LinearLayout {

    @Suppress("unused")
    private val logTag = MockCreditCardNumberView::class.java.simpleName

    private var cardIssuer: CardIssuer = CardIssuer.Unknown
    private var totalWidth: Int = 0
    private val dotViewCache = mutableListOf<ImageView>()

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : this(
        context,
        attrs,
        defStyleAttr,
        0
    )

    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(
        context, attrs, defStyleAttr, defStyleRes
    )

    override fun onFinishInflate() {
        super.onFinishInflate()

        setup()

        doOnLayout {
            if (width != totalWidth) {
                totalWidth = width
                relayoutDots(animated = false)
            }
        }
    }

    fun updateWithCardIssuer(issuer: CardIssuer) {
        cardIssuer = issuer

        // Make sure the subviews are not less than the new card number length.
        if (dotViewCache.isEmpty()) {
            setupDotViewCache()
        }
        val lacked = cardIssuer.cardNumberLength - dotViewCache.count()
        if (lacked > 0) {
            repeat(lacked) {
                val newDot = generateDot()
                dotViewCache.add(newDot)
                addView(newDot)
            }
        }

        relayoutDots(animated = true)
    }

    fun animateNumber(digit: Int) {
        if (digit !in 1..dotViewCache.count()) {
            return
        }

        val idx = digit - 1
        val offset = dotViewCache[idx].height
        dotViewCache[idx]
            .animate()
            .setDuration(100L)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    dotViewCache[idx]
                        .animate()
                        .setDuration(100L)
                        .translationY(0f)
                        .start()
                }
            })
            .translationY(-offset.toFloat())
            .start()
    }

    private fun setup() {
        gravity = Gravity.BOTTOM

        setupDotViewCache()
        for (dotView in dotViewCache) {
            addView(dotView)
        }
    }

    private fun shouldDivideAt(position: Int): Boolean {
        var ret = false
        for (dividerPos in cardIssuer.dividerPositions) {
            if (dividerPos.preformat == position) {
                ret = true
                break
            } else if (dividerPos.preformat > position) {
                break
            }
        }
        return ret
    }

    private fun setupDotViewCache() {
        if (dotViewCache.isNotEmpty()) {
            dotViewCache.clear()
        }

        repeat(cardIssuer.cardNumberLength) {
            dotViewCache.add(generateDot())
        }
    }

    private fun generateDot(): ImageView {
        return ImageView(context).apply {
            setImageResource(R.drawable.credit_card_number_mock)
        }
    }

    private fun relayoutDots(animated: Boolean) {
        if (animated) {
            // This does not have to be done at first.
            // Because the animation is performed at the next draw cycle, so all values changed
            // here does not effect the "current scene" of the transition.
            TransitionManager.beginDelayedTransition(this, AutoTransition().apply {
                duration = 250L
            })
        }

        val dotDimen = (totalWidth * 0.032).toInt()
        val totalSpace = totalWidth - dotDimen * cardIssuer.cardNumberLength

        // Make space for the animation.
        val selfLp = layoutParams.apply { height = dotDimen * 3 }
        layoutParams = selfLp

        // divderInterval = 5 * dotInterval
        // (numberLength - 1 - dividerCount) * dotInterval + dividerCount * dividerInterval = totalSpace
        val dividersCount = cardIssuer.dividerPositions.count()
        val dotInterval =
            totalSpace / (dividersCount * 5 + cardIssuer.cardNumberLength - 1 - dividersCount)
        val dividerInterval = 5 * dotInterval

        for (i in 0 until cardIssuer.cardNumberLength) {
            val leftMargin = if (shouldDivideAt(i)) dividerInterval else dotInterval
            val newLp = (dotViewCache[i].layoutParams as LayoutParams).apply {
                this.width = dotDimen
                this.height = dotDimen
                if (i > 0) {
                    this.leftMargin = leftMargin
                }
            }
            dotViewCache[i].layoutParams = newLp
        }
    }
}