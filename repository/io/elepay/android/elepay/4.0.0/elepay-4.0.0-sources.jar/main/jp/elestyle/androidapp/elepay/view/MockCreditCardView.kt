package jp.elestyle.androidapp.elepay.view

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.animation.addListener
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.utils.creditcard.CardIssuer

internal class MockCreditCardView : FrameLayout {
    private lateinit var front: View
    private lateinit var back: View
    private lateinit var brandIconView: ImageView
    private lateinit var brandBgView: ImageView
    private lateinit var backBrandBgView: ImageView
    private lateinit var numberView: MockCreditCardNumberView
    private lateinit var dateView: MockCreditCardDateView
    private lateinit var frontCvcView: MockCreditCardCvcView
    private lateinit var backCvcView: MockCreditCardCvcView

    enum class FocusTarget {
        NUMBER, DATE, CVC
    }

    private val animationDuration = 300L
    private var cardIssuer: CardIssuer = CardIssuer.Unknown
    private var isShowingFront = true
    private val flipToBackAnimator: AnimatorSet by lazy {
        val fromAlpha = ObjectAnimator.ofFloat(front, "alpha", 1.0f, 0.0f).apply {
            duration = animationDuration / 2
            addListener(onEnd = {
                front.visibility = View.INVISIBLE
            })
        }
        val fromRotation = ObjectAnimator.ofFloat(front, "rotationY", 0f, 180f).apply {
            duration = animationDuration
        }
        val toAlpha = ObjectAnimator.ofFloat(back, "alpha", 0.0f, 1.0f).apply {
            duration = animationDuration / 2
            addListener(onStart = {
                back.visibility = View.VISIBLE
            })
        }
        val toRotation = ObjectAnimator.ofFloat(back, "rotationY", -180f, 0f).apply {
            duration = animationDuration
        }

        return@lazy AnimatorSet().apply {
            play(fromRotation).with(fromAlpha).with(toRotation)
            play(toAlpha).after(fromAlpha)
            addListener(onEnd = {
                isShowingFront = false
            })
        }
    }
    private val flipToFrontAnimator: AnimatorSet by lazy {
        val fromAlpha = ObjectAnimator.ofFloat(back, "alpha", 1.0f, 0.0f).apply {
            duration = animationDuration / 2
            addListener(onEnd = {
                back.visibility = View.INVISIBLE
            })
        }
        val fromRotation = ObjectAnimator.ofFloat(back, "rotationY", 0f, -180f).apply {
            duration = animationDuration
        }
        val toAlpha = ObjectAnimator.ofFloat(front, "alpha", 0.0f, 1.0f).apply {
            duration = animationDuration / 2
            addListener(onStart = {
                front.visibility = View.VISIBLE
            })
        }
        val toRotation = ObjectAnimator.ofFloat(front, "rotationY", 180f, 0f).apply {
            duration = animationDuration
        }

        return@lazy AnimatorSet().apply {
            play(fromRotation).with(fromAlpha).with(toRotation)
            play(toAlpha).after(fromAlpha)
            addListener(onEnd = {
                isShowingFront = true
            })
        }
    }

    private val brandShowingAnimator: AnimatorSet by lazy {
        val iconAlpha = ObjectAnimator.ofFloat(brandIconView, "alpha", 0.0f, 1.0f)
        val bgAlpha = ObjectAnimator.ofFloat(brandBgView, "alpha", 0.0f, 1.0f)
        // Back brand bg is not animating since it won't be seen during the brand show/hide.

        return@lazy AnimatorSet().apply {
            duration = animationDuration
            play(iconAlpha).with(bgAlpha)
            interpolator = DecelerateInterpolator()
            addListener(onStart = {
                brandIconView.visibility = View.VISIBLE
                brandBgView.visibility = View.VISIBLE
                backBrandBgView.visibility = View.VISIBLE
            })
        }
    }
    private val brandHidingAnimator: AnimatorSet by lazy {
        val iconAlpha = ObjectAnimator.ofFloat(brandIconView, "alpha", 1.0f, 0.0f)
        val bgAlpha = ObjectAnimator.ofFloat(brandBgView, "alpha", 1.0f, 0.0f)
        // Back brand bg is not animating since it won't be seen during the brand show/hide.

        return@lazy AnimatorSet().apply {
            duration = animationDuration
            play(iconAlpha).with(bgAlpha)
            interpolator = DecelerateInterpolator()
            addListener(onEnd = {
                brandIconView.visibility = View.INVISIBLE
                brandBgView.visibility = View.INVISIBLE
                backBrandBgView.visibility = View.INVISIBLE
            })
        }
    }


    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : this(
        context,
        attrs,
        defStyleAttr,
        0
    )

    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(
        context,
        attrs,
        defStyleAttr,
        defStyleRes
    )


    override fun onFinishInflate() {
        super.onFinishInflate()

        front = findViewById(R.id.creditCardFront)
        front.findViewById<View>(R.id.mockCreditCardFrontContentContainer).apply {
            clipToOutline = true
        }
        back = findViewById(R.id.creditCardBack)
        back.findViewById<View>(R.id.mockCreditCardBackContentContainer).apply {
            clipToOutline = true
        }

        brandIconView = findViewById(R.id.mockCreditCardBrandIcon)
        brandBgView = findViewById(R.id.mockCreditCardFrontDimmedBrandBg)
        backBrandBgView = findViewById(R.id.mockCreditCardBackDimmedBrandBg)
        numberView = front.findViewById(R.id.mockCreditCardNumber)

        dateView = front.findViewById(R.id.mockCreditCardExpireDate)
        dateView.gravity = Gravity.END or Gravity.CENTER_VERTICAL

        frontCvcView = front.findViewById(R.id.mockCreditCardFrontCvc)
        frontCvcView.gravity = Gravity.END or Gravity.BOTTOM

        backCvcView = back.findViewById(R.id.mockCreditCardBackCvc)
        backCvcView.gravity = Gravity.END or Gravity.CENTER_VERTICAL

        // According to the do, camera distance value is based on the screen density.
        // To make sure the whole view is visible while animating, choose the larger dimension as
        // the base instance and make it 10 times multiply with the display.density.
        val distance = resources.displayMetrics.let {
            it.heightPixels * 10 * it.density
        }
        front.cameraDistance = distance
        back.cameraDistance = distance
    }

    fun changeFocusedTarget(target: FocusTarget) {
        when (target) {
            FocusTarget.NUMBER, FocusTarget.DATE ->
                showFront(true)
            FocusTarget.CVC -> {
                if (cardIssuer !== CardIssuer.Amex) {
                    showBack(true)
                } else {
                    frontCvcView.updateMaxLength(cardIssuer.cvcLength, animated = false)
                    frontCvcView.show()
                }
            }
        }
    }

    fun updateCardIssuer(issuer: CardIssuer) {
        cardIssuer = issuer

        val resourceIds = issuer.logoResourceIds()
        if (resourceIds.first > 0) {
            brandIconView.setImageResource(resourceIds.first)
        }
        if (resourceIds.second > 0) {
            brandBgView.setImageResource(resourceIds.second)
            backBrandBgView.setImageResource(resourceIds.second)
        }

        when (issuer) {
            is CardIssuer.Unknown -> {
                brandShowingAnimator.cancel()
                // Always hide stuff for unknown issuer.
                brandHidingAnimator.start()
                frontCvcView.hide()
            }

            is CardIssuer.Amex -> {
                brandHidingAnimator.cancel()
                brandShowingAnimator.start()
                frontCvcView.updateMaxLength(cardIssuer.cvcLength, animated = false)
                frontCvcView.show()
            }

            else -> {
                brandHidingAnimator.cancel()
                brandShowingAnimator.start()
                frontCvcView.hide()
            }
        }

        numberView.updateWithCardIssuer(issuer)
    }

    fun animateDigit(target: FocusTarget, digit: Int) {
        when (target) {
            FocusTarget.NUMBER -> {
                numberView.animateNumber(digit)
            }
            FocusTarget.DATE -> {
                dateView.animateDateDigit(digit)
            }
            FocusTarget.CVC -> {
                frontCvcView.animateCvcDigit(digit)
                backCvcView.animateCvcDigit(digit)
            }
        }
    }

    @Suppress("SameParameterValue")
    private fun showFront(animated: Boolean) {
        if (isShowingFront) return

        if (animated) {
            flipToFrontAnimator.start()
        } else {
            isShowingFront = true

            front.visibility = View.VISIBLE
            front.alpha = 1.0f

            back.visibility = View.INVISIBLE
            back.alpha = 0.0f
        }
    }

    @Suppress("SameParameterValue")
    private fun showBack(animated: Boolean) {
        if (!isShowingFront) return

        if (animated) {
            flipToBackAnimator.start()
        } else {
            isShowingFront = false

            front.visibility = View.INVISIBLE
            front.alpha = 0.0f

            back.visibility = View.VISIBLE
            back.alpha = 1.0f
        }
    }
}

private fun CardIssuer.logoResourceIds(): Pair<Int, Int> = when (this) {
    CardIssuer.Amex -> Pair(
        R.drawable.ic_creditcard_brand_amex,
        R.drawable.ic_creditcard_brand_amex_bg
    )
    CardIssuer.Jcb -> Pair(
        R.drawable.ic_creditcard_brand_jcb,
        R.drawable.ic_creditcard_brand_jcb_bg
    )
    CardIssuer.DinersClub -> Pair(
        R.drawable.ic_creditcard_brand_diners,
        R.drawable.ic_creditcard_brand_diners_bg
    )
    CardIssuer.Visa -> Pair(
        R.drawable.ic_creditcard_brand_visa,
        R.drawable.ic_creditcard_brand_visa_bg
    )
    CardIssuer.Mastercard -> Pair(
        R.drawable.ic_creditcard_brand_mastercard,
        R.drawable.ic_creditcard_brand_mastercard_bg
    )
    CardIssuer.Unionpay -> Pair(
        R.drawable.ic_creditcard_brand_unionpay,
        R.drawable.ic_creditcard_brand_unionpay_bg
    )
    else -> Pair(0, 0)
}