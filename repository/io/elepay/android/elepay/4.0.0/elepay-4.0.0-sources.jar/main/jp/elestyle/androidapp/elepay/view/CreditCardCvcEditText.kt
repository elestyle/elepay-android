package jp.elestyle.androidapp.elepay.view

import android.content.Context
import android.text.Editable
import android.text.InputFilter
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import androidx.core.widget.addTextChangedListener
import com.google.android.material.textfield.TextInputEditText
import jp.elestyle.androidapp.elepay.utils.creditcard.CardIssuer

internal class CreditCardCvcEditText : TextInputEditText {
    /**
     * Special flag for method `acceptInput()`.
     * We still want to trigger the text-formatting-mechanism when that method is called but may
     * need to treatthe input specially.
     */
    private var isExternalInput = false
    private var maxLength = CardIssuer.Unknown.cvcLength

    interface StateListener {
        fun onCreditCardCvcCleanedUp()
        fun onEditCreditCardCvc(digit: Int)
        fun onCreditCardCvcFinishedEditing(cvc: String)
        fun onClearCreditCardCvcErrors()
    }

    var stateListener: StateListener? = null

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    override fun onFinishInflate() {
        super.onFinishInflate()

        setup()
    }

    fun acceptInput(input: String) {
        isExternalInput = true
        setText(input)
        setSelection(input.length)
    }

    fun updateMaxLength(length: Int) {
        maxLength = length
        filters = arrayOf(InputFilter.LengthFilter(length))
    }

    private fun setup() {
        filters = arrayOf(InputFilter.LengthFilter(maxLength))

        setOnKeyListener { _, _, event ->
            processKeyevent(event)
        }

        setOnEditorActionListener { _, actionId, _ ->
            processEditorAction(actionId)
        }

        addTextChangedListener { text ->
            handleTextChange(text)
        }
    }

    private fun processKeyevent(event: KeyEvent): Boolean =
        if (text != null
            && text.toString().isEmpty()
            && event.keyCode == KeyEvent.KEYCODE_DEL
            && event.action == KeyEvent.ACTION_DOWN
        ) {
            stateListener?.onCreditCardCvcCleanedUp()
            true
        } else false

    private fun processEditorAction(actionId: Int): Boolean =
        if (actionId == EditorInfo.IME_ACTION_NEXT) {
            stateListener?.onCreditCardCvcFinishedEditing(text.toString())
            true
        } else false

    private fun handleTextChange(text: Editable?) {
        if (text == null || text.isEmpty()) {
            if (!isExternalInput) {
                stateListener?.onCreditCardCvcCleanedUp()
            }
        } else {
            // Clear error state when start editing cvc number.
            stateListener?.onClearCreditCardCvcErrors()

            if (text.length >= maxLength) {
                stateListener?.onCreditCardCvcFinishedEditing(text.toString())
            }

            stateListener?.onEditCreditCardCvc(text.length)
        }

        // Clean up the special flag after all changes are handled.
        isExternalInput = false
    }
}