package jp.elestyle.androidapp.elepay.utils

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

@Suppress("unused")
internal object PermissionChecker {
    /**
     * Check if the given permission is granted by user.
     * @param context The context object use to perform checking.
     * @param permission The permission to be checked.
     * @return true for granted
     */
    fun isPermissionGranted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    /**
     * Check if all of the given permissions are granted.
     * @param context The context object used to check permission state.
     * @param permissions Array of permissions to be checked.
     * @return true for all permissions are granted, false for at lease one permission are not.
     */
    fun arePermissionsGranted(context: Context, permissions: Array<String>): Boolean {
        for (permission in permissions) {
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                return false
            }
        }
        return true
    }

    /**
     * Check if the given list of permission are granted.
     * @return A list of permissions that are not granted yet.
     */
    fun filterUngrantedPermissions(permissions: Array<String>, context: Context): List<String> =
        permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
}