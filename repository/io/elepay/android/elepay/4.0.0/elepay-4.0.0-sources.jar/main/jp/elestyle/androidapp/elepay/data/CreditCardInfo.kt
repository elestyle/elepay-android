package jp.elestyle.androidapp.elepay.data

import android.os.Parcelable
import com.stripe.android.model.CardParams
import kotlinx.parcelize.Parcelize

@Parcelize
class CreditCardInfo(
    val number: String,
    val month: Int,
    val year: Int,
    val cvc: String,
) : Parcelable {
    internal fun asStripeCardParams(): CardParams = CardParams(
        number, month, year, cvc
    )
}