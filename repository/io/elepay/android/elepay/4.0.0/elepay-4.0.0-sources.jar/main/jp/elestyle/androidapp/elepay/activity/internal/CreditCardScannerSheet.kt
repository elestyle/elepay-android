package jp.elestyle.androidapp.elepay.activity.internal

import android.content.Context
import android.content.Intent
import android.os.Parcelable
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.launch
import androidx.core.content.IntentCompat
import jp.elestyle.androidapp.elepay.data.CreditCardInfo
import kotlinx.parcelize.Parcelize

internal sealed class CreditCardScannerResult : Parcelable {
    @Parcelize
    data class Completed(val cardInfo: CreditCardInfo) : CreditCardScannerResult()

    @Parcelize
    object Canceled : CreditCardScannerResult()
}

internal class CreditCardScannerSheet private constructor() {
    private lateinit var launcher: ActivityResultLauncher<Unit>

    private val contract =
        object : ActivityResultContract<Unit, CreditCardScannerResult>() {
            override fun createIntent(context: Context, input: Unit): Intent =
                Intent(context, CardNumberScannerActivity::class.java)

            override fun parseResult(resultCode: Int, intent: Intent?): CreditCardScannerResult =
                intent?.let {
                    IntentCompat.getParcelableExtra(
                        it,
                        CardNumberScannerActivity.scanningResultKey,
                        CreditCardScannerResult::class.java
                    )
                } ?: CreditCardScannerResult.Canceled
        }

    fun interface CardScannerResultCallback {
        fun onCreditCardScannerResult(result: CreditCardScannerResult)
    }

    fun show() {
        launcher.launch()
    }

    fun dismiss() {
        launcher.unregister()
    }

    companion object {
        fun create(
            from: ComponentActivity,
            resultCallback: CardScannerResultCallback
        ): CreditCardScannerSheet = CreditCardScannerSheet().apply {
            launcher = from.registerForActivityResult(
                contract,
                resultCallback::onCreditCardScannerResult
            )
        }
    }
}