package jp.elestyle.androidapp.elepay.data

internal data class ExecuteResult(
    val status: String,
    val redirectUrl: String?
)
