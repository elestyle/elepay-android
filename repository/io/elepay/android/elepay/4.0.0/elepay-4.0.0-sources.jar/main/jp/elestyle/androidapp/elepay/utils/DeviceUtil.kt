package jp.elestyle.androidapp.elepay.utils

import android.annotation.SuppressLint
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

internal object DeviceUtil {
    enum class DeviceIdType {
        IMEI, SERIAL_NUMBER, ANDROID_ID, IDFA
    }

    @SuppressLint("HardwareIds")
    suspend fun getDeviceRelatedIds(context: Context): Map<DeviceIdType, String> {
        val (imei, serialNum) = getImeiAndSerialNum(context)

        val androidId =
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: ""

        return mapOf(
            DeviceIdType.IMEI to imei,
            DeviceIdType.SERIAL_NUMBER to serialNum,
            DeviceIdType.ANDROID_ID to androidId,
            // As sdk version <= 3.0.0, this id could be retrieved by play-services-ads sdk.
            // But from play-services-ads 21.4.0, to get this id, we have to set a
            // "com.google.android.gms.ads.APPLICATION_ID" in AndroidManifest.xml, that's beyond
            // our request so from sdk version 3.0.2, this id is fixed to a special string.
            DeviceIdType.IDFA to "unknown from 3.0.2"
        )
    }

    @SuppressLint("MissingPermission", "HardwareIds")
    private fun getImeiAndSerialNum(context: Context): Pair<String, String> {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
            return Pair("", "")
        }

        val hasPhonePermission = PermissionChecker
            .isPermissionGranted(context, android.Manifest.permission.READ_PHONE_STATE)
        return if (hasPhonePermission) {
            ContextCompat.getSystemService(context, TelephonyManager::class.java)?.run {
                @Suppress("DEPRECATION")
                val imei = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    imei ?: meid ?: ""
                } else {
                    deviceId ?: ""
                }
                val serialNum = simSerialNumber ?: ""
                Pair(imei, serialNum)
            } ?: Pair("", "")
        } else Pair("", "")
    }

    fun getBatteryInfo(context: Context): Map<String, String> {
        val ret = mutableMapOf<String, String>()
        val batteryManager =
            context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return mapOf()

        val percentage = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        ret["percentage"] =
            if (percentage != Integer.MIN_VALUE) percentage.toString() else "unknown"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ret["status"] =
                when (batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)) {
                    BatteryManager.BATTERY_STATUS_CHARGING -> "charging"
                    BatteryManager.BATTERY_STATUS_DISCHARGING -> "discharging"
                    BatteryManager.BATTERY_STATUS_FULL -> "full"
                    BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "not charging"
                    BatteryManager.BATTERY_STATUS_UNKNOWN -> "unknown"
                    else -> "unknown"
                }
        } else {
            ret["status"] = "unable to fetch"
        }

        return ret
    }

    val deviceInfo: Map<String, String>
        get() {
            val baseOS = Build.VERSION.BASE_OS
            val securityPatch = Build.VERSION.SECURITY_PATCH

            return mapOf(
                "device" to Build.DEVICE,
                "brand" to Build.BRAND,
                "model" to Build.MODEL,
                "manufacturer" to Build.MANUFACTURER,
                "product" to Build.PRODUCT,
                "buildId" to Build.ID,
                "buildDisplayId" to Build.DISPLAY,
                "bootloader" to Build.BOOTLOADER,
                "hardware" to Build.HARDWARE,
                "baseOS" to baseOS,
                "systemName" to Build.VERSION.RELEASE,
                "systemCodeName" to Build.VERSION.CODENAME,
                "sdkNumber" to Build.VERSION.SDK_INT.toString(),
                "securityPatch" to securityPatch
            )
        }
}
