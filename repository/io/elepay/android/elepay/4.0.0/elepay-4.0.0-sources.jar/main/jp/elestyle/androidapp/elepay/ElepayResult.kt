package jp.elestyle.androidapp.elepay

import androidx.annotation.Keep

/**
 * The result of payment request.
 */
@Keep
sealed class ElepayResult {
    /**
     * The payment process succeeded.
     */
    @Keep
    class Succeeded(
        /**
         * The id of the payment that is processed successfully.
         */
        val paymentId: String
    ) : ElepayResult()

    /**
     * The payment failed, with an associated error object.
     */
    @Keep
    class Failed(
        /**
         * The id of the payment which is failed processing.
         * This value could be `null` if the error occurred before the payment id could be retrieved.
         */
        val paymentId: String?,

        /**
         * The specific [ElepayError] that occurred. Uses this value to retrieve the error's detail.
         */
        val error: ElepayError
    ) : ElepayResult()

    /**
     * The payment is canceled.
     */
    @Keep
    class Canceled(
        /**
         * The id of the payment which is cancelled by the user.
         */
        val paymentId: String
    ) : ElepayResult()
}
