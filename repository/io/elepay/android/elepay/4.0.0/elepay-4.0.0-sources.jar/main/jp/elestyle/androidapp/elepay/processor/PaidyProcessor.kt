package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.internal.ElepayWebProcessorActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator

internal object PaidyProcessor : ElepayProcessor(true) {

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else when (chargeData.method) {
            PaymentMethod.PAIDY -> {
                val paymentUrl = chargeData.redirectUrl ?: run {
                    val error = ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.PAIDY,
                            PaymentMethod.PAIDY,
                            ErrorCode.INVALID_AUTH_URL
                        ),
                        "No available url for authorization."
                    )
                    resultHandler?.invoke(ElepayResult.Failed(chargeData.id, error))
                    return false
                }
                processPaidy(paymentUrl, chargeData.paymentCommon, fromActivity, resultHandler)
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = chargeData.id,
                        error = ElepayError.UnsupportedPaymentMethod(chargeData.method.rawValue)
                    )
                )
                false
            }
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(sourceData.paymentCommon, fromActivity, resultHandler)) true
        else when (sourceData.method) {
            PaymentMethod.PAIDY -> {
                val paymentUrl = sourceData.redirectUrl ?: run {
                    val error = ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.PAIDY,
                            PaymentMethod.PAIDY,
                            ErrorCode.INVALID_AUTH_URL
                        ),
                        "No available url for authorization."
                    )
                    resultHandler?.invoke(ElepayResult.Failed(sourceData.id, error))
                    return false
                }
                processPaidy(paymentUrl, sourceData.paymentCommon, fromActivity, resultHandler)
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = sourceData.id,
                        error = ElepayError.UnsupportedPaymentMethod(sourceData.method.rawValue)
                    )
                )
                false
            }
        }

    private fun processPaidy(
        paymentUrl: String,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentData.id)
        }
        val intent = Intent(fromActivity, ElepayWebProcessorActivity::class.java).apply {
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.PAYMENT_DATA.rawValue, paymentData)
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.TARGET_URL.rawValue, paymentUrl)
        }
        fromActivity.startActivity(intent)
        return true
    }
}