package jp.elestyle.androidapp.elepay.data

import org.json.JSONObject

internal data class RequestError(
    val code: String,
    val message: String,
    val extra: Map<String, Any>,
    val errorCode: ErrorCode,
)

internal typealias APIResult = ResultType<JSONObject, RequestError>

