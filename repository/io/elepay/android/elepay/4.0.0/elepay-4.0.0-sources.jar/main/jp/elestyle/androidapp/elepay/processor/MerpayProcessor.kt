package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.SystemUtil
import org.json.JSONObject

internal object MerpayProcessor : ElepayProcessor(), CallbackProcessable {
    private var processingData: CallbackProcessable.ProcessingPaymentInfo? = null

    override fun setup(providerConfig: ElepayProviderConfig) {
        super.setup(providerConfig)
        if (providerConfig is ElepayProviderConfig.Merpay) {
            callbackScheme = providerConfig.appScheme
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        processMerpay(chargeData.paymentCommon, chargeData.payload, fromActivity, resultHandler)


    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        processMerpay(sourceData.paymentCommon, sourceData.payload, fromActivity, resultHandler)

    override var callbackScheme: String = ""
        private set

    override fun retrieveProcessingPaymentInfo(
        disposeImmediately: Boolean
    ): CallbackProcessable.ProcessingPaymentInfo? {
        val ret = processingData
        if (disposeImmediately) {
            processingData = null
        }
        return ret
    }

    override suspend fun continueCallbackProcessing(
        data: CallbackProcessingData
    ): CallbackProcessable.ProcessedResult {
        val paymentId = data.paymentData.id
        val elepayResult = when (data.params["type"]?.lowercase()) {
            null -> ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        data.paymentData.provider,
                        data.paymentData.method,
                        ErrorCode.FAILED
                    ),
                    "No valid type found."
                )
            )
            "confirm" -> ElepayResult.Succeeded(paymentId)
            else -> ElepayResult.Canceled(paymentId)
        }

        return CallbackProcessable.ProcessedResult(paymentId, elepayResult)
    }

    private fun processMerpay(
        paymentData: PaymentCommon,
        payload: String?,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(paymentData, fromActivity, resultHandler)) true
        else when (paymentData.method) {
            PaymentMethod.MERPAY -> {
                if (callbackScheme.isEmpty()) {
                    resultHandler?.invoke(
                        ElepayResult.Failed(
                            paymentId = paymentData.id,
                            error = ElepayError.UninitializedPaymentMethod(
                                ErrorCodeGenerator.generate(
                                    PlatformCode.SDK,
                                    PaymentMethodProvider.MERPAY,
                                    PaymentMethod.MERPAY,
                                    ErrorCode.UNINIT
                                ),
                                PaymentMethod.MERPAY.rawValue,
                                "Not well configured"
                            )
                        )
                    )
                    false
                } else {
                    processProdModeMerpay(payload, paymentData, fromActivity, resultHandler)
                }
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = paymentData.id,
                        error = ElepayError.UnsupportedPaymentMethod(paymentData.method.rawValue)
                    )
                )
                false
            }
        }

    private fun processProdModeMerpay(
        payload: String?,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val paymentId = paymentData.id
        if (payload.isNullOrEmpty()) {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    paymentId = paymentId,
                    error = ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.MERPAY,
                            PaymentMethod.MERPAY,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        "${PaymentMethod.MERPAY.rawValue} charge error."
                    )
                )
            )
            return false
        }

        val jsonPayload = try {
            JSONObject(payload)
        } catch (e: Exception) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.MERPAY,
                    PaymentMethod.MERPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.MERPAY.rawValue} charge error."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentId, error = error))
            return false
        }

        val paymentUrl = jsonPayload.optString("paymentUrl") ?: run {
            resultHandler?.invoke(createInvalidAuthUrlFailure(paymentId = paymentId))
            return false
        }
        if (paymentUrl.isEmpty()) {
            resultHandler?.invoke(createInvalidAuthUrlFailure(paymentId = paymentId))
            return false
        }

        return try {
            val uri = Uri.parse(paymentUrl)

            processingData = CallbackProcessable.ProcessingPaymentInfo(paymentData)
            if (resultHandler != null) {
                ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
            }

            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.kouzoh.mercari")
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            if (SystemUtil.isIntentLaunchable(intent, fromActivity)) {
                fromActivity.startActivity(intent)
            } else {
                intent.setPackage(null)
                fromActivity.startActivity(intent)
            }

            true
        } catch (e: Exception) {
            resultHandler?.invoke(createInvalidAuthUrlFailure(paymentId = paymentId))
            false
        }
    }

    private fun createInvalidAuthUrlFailure(paymentId: String): ElepayResult.Failed =
        ElepayResult.Failed(
            paymentId = paymentId,
            error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.MERPAY,
                    PaymentMethod.MERPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "Url for payment processing is invalid."
            )
        )

}