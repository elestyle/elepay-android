package jp.elestyle.androidapp.elepay.activity.allpay

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.allpayx.sdk.AllPayEngine
import com.allpayx.sdk.constants.AllPayConst
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import org.json.JSONException
import org.json.JSONObject

internal class AllpayIntermediateActivity : Activity() {

    private var paymentId: String = ""

    enum class IntentExtraKey(val rawValue: String) {
        USES_DEVELOPMENT_ENVIRONMENT("uses_dev_env"),
        PAYMENT_ID("payment_id"),
        PAYMENT_TN("payment_tn")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        intent.extras?.run {
            paymentId = getString(IntentExtraKey.PAYMENT_ID.rawValue) ?: ""
            val usesDevEnv = getBoolean(IntentExtraKey.USES_DEVELOPMENT_ENVIRONMENT.rawValue)

            getString(IntentExtraKey.PAYMENT_TN.rawValue)?.also { tn ->
                // According to Allpay's sdk doc, when the last parameter is `false`, it uses dev env.
                AllPayEngine.pay(this@AllpayIntermediateActivity, tn, !usesDevEnv)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == AllPayConst.VTPAY_PAY_REQUESR_CODE
            && resultCode == AllPayConst.VTPAY_PAY_RESULT_CODE
        ) {
            data?.extras?.getString("pay_result")?.also { resultStr ->
                val payResult = try {
                    val jsonResult = JSONObject(resultStr)
                    when (jsonResult.optString("state", "")) {
                        "success" -> ElepayResult.Succeeded(paymentId)
                        "fail" -> {
                            val errMessage = jsonResult.optString("errorDetail", resultStr)
                            ElepayResult.Failed(
                                paymentId,
                                ElepayError.PaymentFailure(
                                    errorCode = ErrorCodeGenerator.generate(
                                        PlatformCode.SDK,
                                        PaymentMethodProvider.ALLPAY,
                                        null,
                                        ErrorCode.FAILED
                                    ),
                                    message = errMessage
                                )
                            )
                        }
                        "cancel" -> ElepayResult.Canceled(paymentId)
                        else -> ElepayResult.Failed(
                            paymentId,
                            ElepayError.PaymentFailure(
                                errorCode = ErrorCodeGenerator.generate(
                                    PlatformCode.SDK,
                                    PaymentMethodProvider.ALLPAY,
                                    null,
                                    ErrorCode.FAILED
                                ),
                                message = "allpay failed. $resultStr"
                            )
                        )
                    }
                } catch (e: JSONException) {
                    ElepayResult.Failed(
                        paymentId = paymentId,
                        error = ElepayError.PaymentFailure(
                            ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                PaymentMethodProvider.ALLPAY,
                                null,
                                ErrorCode.FAILED
                            ),
                            "allpay failed. $resultStr"
                        )
                    )
                }

                Handler(Looper.getMainLooper()).postDelayed({
                    ElepayResultHandlerManager.notifyResult(payResult, paymentId)
                    finish()
                }, 100)
            }
        }
    }
}
