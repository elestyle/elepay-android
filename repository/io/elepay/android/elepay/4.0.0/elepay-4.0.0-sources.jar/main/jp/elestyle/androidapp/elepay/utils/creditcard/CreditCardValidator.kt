package jp.elestyle.androidapp.elepay.utils.creditcard

import jp.elestyle.androidapp.elepay.data.CreditCardInfo
import jp.elestyle.androidapp.elepay.utils.extensions.asPureCreditCardNumber
import java.util.Calendar

internal object CreditCardValidator {
    /**
     * Validate the card with the complete card information.
     */
    fun validateCard(card: CreditCardInfo, cardIssuer: CardIssuer): Boolean =
        if (cardIssuer is CardIssuer.Unknown) {
            false
        } else {
            validateCardNumber(card.number, cardIssuer) &&
                    validateCardExpirationDate(card.month, card.year) &&
                    validateCvc(card.cvc, cardIssuer)
        }

    /**
     * Validate the card number only.
     */
    fun validateCardNumber(numberString: String, cardIssuer: CardIssuer): Boolean =
        if (cardIssuer is CardIssuer.Unknown) {
            false
        } else {
            val normalized = numberString.asPureCreditCardNumber()
            cardIssuer.cardNumberLength == normalized.length && performLuhnCheck(normalized)
        }

    /**
     * Validate the expiration date of the card.
     */
    fun validateCardExpirationDate(month: Int, year: Int): Boolean {
        // basic month check
        val validMonth = month in 1..12
        if (!validMonth) {
            return false
        }

        val now = Calendar.getInstance()
        val normalizedYear =
            if (year in 0..99)
                now.get(Calendar.YEAR) / 100 * 100 + year
            else year
        return when {
            // Year has past.
            normalizedYear < now.get(Calendar.YEAR) -> false

            // It's the same year, check if the month has past.
            normalizedYear == now.get(Calendar.YEAR) -> {
                // Calendar.MONTH starts from 0...
                month >= now.get(Calendar.MONTH) + 1
            }

            // Year is later than now, no further checking.
            else -> true
        }
    }

    private fun validateCvc(cvc: String, cardIssuer: CardIssuer): Boolean {
        val validLen = cvc.length == cardIssuer.cvcLength
        var isAllNum = true
        for (i in cvc.indices) {
            if (!cvc[i].isDigit()) {
                isAllNum = false
                break
            }
        }

        return validLen && isAllNum
    }

    private fun performLuhnCheck(numberString: String): Boolean {
        var total = 0
        var shouldMultiplyTwo = false
        for (i in numberString.length - 1 downTo 0) {
            val ch = numberString[i]
            if (!ch.isDigit()) {
                return false
            }
            var digit = Character.getNumericValue(ch)
            if (shouldMultiplyTwo) {
                digit *= 2
            }
            if (digit > 9) {
                digit -= 9
            }
            total += digit

            shouldMultiplyTwo = !shouldMultiplyTwo
        }

        return total % 10 == 0
    }
}