package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.googlepay.GooglePayProcessingActivity
import jp.elestyle.androidapp.elepay.activity.internal.CreditCardProcessingActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaygentGooglePayConfig
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.creditcard.WebViewCreditCardProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.GooglePayHelper
import jp.elestyle.androidapp.elepay.utils.creditcard.CreditCardProcessingCenter
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import org.json.JSONObject

internal object PaygentProcessor : ElepayProcessor() {
    private var googlePayConfig: PaygentGooglePayConfig? = null
    private val mainScope = MainScope()

    override fun setup(providerConfig: ElepayProviderConfig) {
        super.setup(providerConfig)
        if (providerConfig is ElepayProviderConfig.Paygent) {
            this.googlePayConfig = providerConfig.googlePayConfig
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else when (chargeData.method) {

            PaymentMethod.CREDIT_CARD -> {
                processCreditCard(chargeData, fromActivity, resultHandler)
            }

            PaymentMethod.GOOGLE_PAY -> {
                processGooglePay(chargeData, fromActivity, resultHandler)
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = chargeData.id,
                        error = ElepayError.UnsupportedPaymentMethod("paygent ${chargeData.method.rawValue}")
                    )
                )
                false
            }
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    private fun processCreditCard(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val processingUrl = retrieveProcessingUrlFrom(chargeData)
        if (processingUrl.isEmpty()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.paymentCommon.id,
                    error = ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            PaymentMethodProvider.PAYGENT,
                            PaymentMethod.CREDIT_CARD,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "No creditcard processing url for paygent payment."
                    )
                ),
                handler = resultHandler
            )
            return false
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, chargeData.id)
        }
        CreditCardProcessingCenter[chargeData.id] = WebViewCreditCardProcessor(
            paymentData = chargeData.paymentCommon,
            processingUrl = processingUrl,
            activity = fromActivity
        )
        val intent = Intent(fromActivity, CreditCardProcessingActivity::class.java).apply {
            putExtra(
                CreditCardProcessingActivity.IntentExtraKey.PAYMENT_ID.rawValue,
                chargeData.id
            )
        }
        fromActivity.startActivity(intent)

        return true
    }

    private fun retrieveProcessingUrlFrom(chargeData: ChargeData): String =
        if (chargeData.payload == null) ""
        else try {
            val jsonPayload = JSONObject(chargeData.payload)
            val url = jsonPayload.optString("creditcard")
            if (url.contains("<key>")) {
                url.replaceFirst("<key>", ConfigManager.appKey)
            } else ""
        } catch (e: Exception) {
            ""
        }

    private fun processGooglePay(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (googlePayConfig == null ||
            googlePayConfig!!.paymentDataRequestBase.length() == 0 ||
            googlePayConfig!!.merchantId.isEmpty() ||
            ConfigManager.googlePayEnvironment == null
        ) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.id,
                    error = ElepayError.UninitializedPaymentMethod(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.PAYGENT,
                            PaymentMethod.GOOGLE_PAY,
                            ErrorCode.UNINIT
                        ),
                        paymentMethod = PaymentMethod.GOOGLE_PAY.rawValue,
                        message = "Not configured correctly, or forgot to set Google Pay Env."
                    )
                ),
                handler = resultHandler
            )
            return false
        }

        mainScope.launch {
            if (!GooglePayHelper.isGooglePayReadyToUse(fromActivity)) {
                postElepayResult(
                    result = ElepayResult.Failed(
                        paymentId = chargeData.id,
                        error = ElepayError.PaymentFailure(
                            errorCode = ErrorCodeGenerator.generate(
                                PlatformCode.ENDUSER,
                                null,
                                null,
                                ErrorCode.DEVICE_NOT_SUPPORTED
                            ),
                            message = "This device does not support Google Pay."
                        )
                    ),
                    handler = resultHandler
                )
                return@launch
            }

            if (resultHandler != null) {
                ElepayResultHandlerManager.registerResultHandler(resultHandler, chargeData.id)
            }

            GooglePayHelper.storeGatewayTokenParser(
                { token -> token },
                chargeData.id
            )

            Intent(fromActivity, GooglePayProcessingActivity::class.java)
                .apply {
                    putExtra(
                        GooglePayProcessingActivity.IntentExtraKey.PAYMENT_BASE_DATA.rawValue,
                        chargeData.paymentCommon
                    )
                    putExtra(
                        GooglePayProcessingActivity.IntentExtraKey.PAYMENT_DATA_AMOUNT.rawValue,
                        chargeData.amount
                    )
                    putExtra(
                        GooglePayProcessingActivity.IntentExtraKey.PAYMENT_DATA_CURRENCY.rawValue,
                        chargeData.currency
                    )
                    putExtra(
                        GooglePayProcessingActivity.IntentExtraKey.PAYMENT_DATA_REQUEST_JSON.rawValue,
                        composeFinalGooglePayPaymentDataRequest().toString()
                    )
                }
                .also { fromActivity.startActivity(it) }
        }

        return true
    }

    // Loop the base payment data in `googlePayConfig`, locate the "card" configuration, then
    // append a tokenized data to it.
    private fun composeFinalGooglePayPaymentDataRequest(): JSONObject {
        val tokenizedSpecification = generateGooglePayTokenizedSpecification()
        val finalGooglePayParams = JSONObject()
        for (key in googlePayConfig!!.paymentDataRequestBase.keys()) {
            if (key == "allowedPaymentMethods") {
                val methodsJsonArray =
                    googlePayConfig!!.paymentDataRequestBase.optJSONArray("allowedPaymentMethods")
                if (methodsJsonArray != null) {
                    for (i in 0 until methodsJsonArray.length()) {
                        val methodJson = methodsJsonArray.optJSONObject(i) ?: continue
                        if (methodJson.optString("type").lowercase() == "card") {
                            methodJson.put("tokenizationSpecification", tokenizedSpecification)
                            methodsJsonArray.put(i, methodJson)
                        }
                    }
                }
                finalGooglePayParams.put(key, methodsJsonArray)
            } else {
                finalGooglePayParams.put(key, googlePayConfig!!.paymentDataRequestBase[key])
            }
        }

        return finalGooglePayParams
    }

    // data structure is defined as:
    // https://developers.google.com/pay/api/android/reference/request-objects#gateway
    private fun generateGooglePayTokenizedSpecification(): JSONObject =
        JSONObject()
            .put("type", "PAYMENT_GATEWAY")
            .put(
                "parameters", JSONObject()
                    .put("gateway", "paygent")
                    .put("gatewayMerchantId", googlePayConfig!!.merchantId)
            )

}