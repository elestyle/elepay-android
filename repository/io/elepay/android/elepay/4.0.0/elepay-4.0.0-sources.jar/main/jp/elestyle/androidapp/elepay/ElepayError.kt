package jp.elestyle.androidapp.elepay

import androidx.annotation.Keep

/**
 * Defines the errors that the client may receive.
 */
@Keep
sealed class ElepayError {
    /**
     * The SDK has not been initialized correctly.
     * Make sure the `Elepay.setup` is correctly called.
     */
    @Keep
    data class SDKNotSetup(
        /**
         * The error code.
         */
        val errorCode: String,
        /**
         * The helping message may or may not be empty indicating the state.
         */
        val message: String,
    ) : ElepayError()

    /**
     * The specified payment method is not supported.
     */
    @Keep
    data class UnsupportedPaymentMethod(
        /**
         * The payment method which is not supported yet.
         */
        val paymentMethod: String
    ) : ElepayError()

    /**
     * The specified payment is in processing now.
     */
    @Keep
    data class AlreadyMakingPayment(
        /**
         * The id of the payment that is currently in processing.
         */
        val paymentId: String
    ) : ElepayError()

    /**
     * The data of the payment is invalid. You may use the [errorCode] for technical support.
     */
    @Keep
    data class InvalidPayload(
        /**
         * The error code indicates what the specific error occurred. You may use this value for our technical support.
         */
        val errorCode: String,

        /**
         * A message associated with this error.
         */
        val message: String
    ) : ElepayError()

    /**
     * The specified payment method is not been initialized correctly.
     * You may use the [errorCode] for technical support.
     */
    @Keep
    data class UninitializedPaymentMethod(
        /**
         * The error code indicates what the specific error occurred. You may use this value for our technical support.
         */
        val errorCode: String,

        /**
         * A string value refers to the payment method which has not initialized yet.
         */
        val paymentMethod: String,

        /**
         * A simple brief message indicating what's going wrong.
         */
        val message: String
    ) : ElepayError()

    /**
     * An internal system error.
     *
     * You may use the [errorCode] for technical support.
     */
    @Keep
    data class SystemError(
        /**
         * The error code indicates what the specific error occurred. You may use this value for our technical support.
         */
        val errorCode: String,

        /**
         * A message associated with this error.
         */
        val message: String
    ) : ElepayError()

    /**
     * Payment is failed.
     *
     * You may use the [errorCode] for technical support.
     */
    @Keep
    data class PaymentFailure(
        /**
         * The error code indicates what the specific error occurred. You may use this value for our technical support.
         */
        val errorCode: String,

        /**
         * A message associated with this error.
         */
        val message: String
    ) : ElepayError()

    /**
     * The required permissions are not granted for the current payment processing.
     */
    @Keep
    data class PermissionRequired(
        /**
         * A list of permission strings that has not granted.
         * The values of this list are the same as the ones in package [android.Manifest.permission]
         */
        val permissions: List<String>
    ) : ElepayError()
}