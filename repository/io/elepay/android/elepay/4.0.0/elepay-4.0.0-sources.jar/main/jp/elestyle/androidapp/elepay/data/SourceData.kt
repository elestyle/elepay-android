package jp.elestyle.androidapp.elepay.data

import android.os.Build
import android.os.Parcel
import android.os.Parcelable
import org.json.JSONObject

internal data class SourceData(
    val paymentCommon: PaymentCommon,
    val payload: String?,
    val redirectType: RedirectType,
    val redirectUrl: String?,
    val rawJson: JSONObject
) : Parcelable {
    // For convenience
    val id: String get() = paymentCommon.id
    val provider: PaymentMethodProvider get() = paymentCommon.provider
    val method: PaymentMethod get() = paymentCommon.method

    constructor(parcel: Parcel) : this(
        paymentCommon = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            parcel.readParcelable(
                PaymentCommon::class.java.classLoader,
                PaymentCommon::class.java
            )!!
        } else {
            @Suppress("DEPRECATION")
            parcel.readParcelable(PaymentCommon::class.java.classLoader)!!
        },
        payload = parcel.readString()?.run { if (this == "null") null else this },
        redirectType = RedirectType.from(parcel.readString() ?: "any") ?: RedirectType.NATIVE,
        redirectUrl = parcel.readString()?.run { if (this == "null") null else this },
        rawJson = JSONObject(parcel.readString() ?: "{}")
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeParcelable(paymentCommon, 0)
        parcel.writeString(payload)
        parcel.writeString(redirectType.rawValue)
        parcel.writeString(redirectUrl)
        parcel.writeString(rawJson.toString())
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object {
        @Suppress("unused")
        @JvmField
        val CREATOR = object : Parcelable.Creator<SourceData> {
            override fun createFromParcel(parcel: Parcel): SourceData {
                return SourceData(parcel)
            }

            override fun newArray(size: Int): Array<SourceData?> {
                return arrayOfNulls(size)
            }
        }
    }
}