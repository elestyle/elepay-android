package jp.elestyle.androidapp.elepay.utils

import android.content.Context

internal object AuPayHelper {
    private const val auPayPackageName = "jp.auone.wallet"

    fun isAuPayInstalled(context: Context): Boolean =
        SystemUtil.isPackageInstalled(auPayPackageName, context)
}