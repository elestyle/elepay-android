package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.utils.AuPayHelper
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.ServerAPIClient
import org.json.JSONObject

internal object AuPayProcessor : ElepayProcessor(), CallbackProcessable {
    private var processingData: CallbackProcessable.ProcessingPaymentInfo? = null

    override fun setup(providerConfig: ElepayProviderConfig) {
        super.setup(providerConfig)
        if (providerConfig is ElepayProviderConfig.AuPay) {
            callbackScheme = providerConfig.appScheme
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else when (chargeData.method) {
            PaymentMethod.AUPAY ->
                processAuPay(chargeData, fromActivity, resultHandler)

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = chargeData.id,
                        error = ElepayError.UnsupportedPaymentMethod(chargeData.method.rawValue)
                    )
                )
                false
            }
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    override var callbackScheme: String = ""
        private set

    override fun retrieveProcessingPaymentInfo(
        disposeImmediately: Boolean
    ): CallbackProcessable.ProcessingPaymentInfo? {
        val ret = processingData
        if (disposeImmediately) {
            processingData = null
        }
        return ret
    }

    override suspend fun continueCallbackProcessing(
        data: CallbackProcessingData
    ): CallbackProcessable.ProcessedResult {
        val paymentId = data.paymentData.id
        val elepayResult = when (data.params["status"]?.lowercase()) {
            "captured" -> capturePayment(paymentId, "")

            "cancelled" -> ElepayResult.Canceled(paymentId)

            else -> ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        PaymentMethodProvider.AUPAY,
                        PaymentMethod.AUPAY,
                        ErrorCode.FAILED
                    ),
                    "No valid status found."
                )
            )
        }

        return CallbackProcessable.ProcessedResult(paymentId, elepayResult)
    }

    private fun processAuPay(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (chargeData.payload.isNullOrEmpty()) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    PaymentMethodProvider.AUPAY,
                    PaymentMethod.AUPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.AUPAY.rawValue} charge error."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = chargeData.id, error = error))
            return false
        }

        val jsonPayload = try {
            JSONObject(chargeData.payload)
        } catch (e: Exception) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    PaymentMethodProvider.AUPAY,
                    PaymentMethod.AUPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.AUPAY.rawValue} charge error."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = chargeData.id, error = error))
            return false
        }

        val paymentUrl = jsonPayload.optString("paymentUrl", "")
        if (paymentUrl.isEmpty()) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.AUPAY,
                    PaymentMethod.AUPAY,
                    ErrorCode.INVALID_AUTH_URL
                ),
                "No available url for authorization."
            )
            resultHandler?.invoke(ElepayResult.Failed(chargeData.id, error))
            return false
        }

        var finishedLaunching = false

        if (AuPayHelper.isAuPayInstalled(fromActivity)) {
            finishedLaunching = try {
                val uri = Uri.parse(paymentUrl)
                fromActivity.startActivity(Intent(Intent.ACTION_VIEW, uri))
                processingData = CallbackProcessable.ProcessingPaymentInfo(chargeData.paymentCommon)
                if (resultHandler != null) {
                    ElepayResultHandlerManager.registerResultHandler(resultHandler, chargeData.id)
                }
                true
            } catch (e: Exception) {
                false
            }
        }

        if (!finishedLaunching) {
            val error = ElepayError.PaymentFailure(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    null,
                    null,
                    ErrorCode.APP_NOT_INSTALLED
                ),
                message = "au PAY app could not be opened for the processing."
            )
            resultHandler?.invoke(ElepayResult.Failed(chargeData.id, error))
        }
        return true
    }

    private suspend fun capturePayment(paymentId: String, token: String): ElepayResult =
        when (ServerAPIClient.capture(paymentId, token)) {
            is ResultType.Failed ->
                ElepayResult.Failed(
                    paymentId,
                    ElepayError.PaymentFailure(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.AUPAY,
                            PaymentMethod.AUPAY,
                            ErrorCode.FAILED_CAPTURE
                        ),
                        "Failed to capture."
                    )
                )

            is ResultType.Succeeded -> ElepayResult.Succeeded(paymentId)
        }
}