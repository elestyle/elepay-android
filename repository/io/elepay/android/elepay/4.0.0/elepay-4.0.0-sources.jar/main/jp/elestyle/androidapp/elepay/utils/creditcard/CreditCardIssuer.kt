package jp.elestyle.androidapp.elepay.utils.creditcard

internal class CardDividerPosition(val preformat: Int, val formatted: Int)

@Suppress("unused")
internal sealed class CardIssuer(
    // Reference: https://en.wikipedia.org/wiki/Payment_card_number#Issuer_identification_number_.28IIN.29
    val identificationNumber: Array<String>,
    /**
     * The length of this card number, before formatting.
     * Default is 16. Currently, amex is 15, diners is 14
     */
    val cardNumberLength: Int = DEFAULT_CARD_NUMBER_LENGTH,
    /**
     * The length of the cvc of this card. Normally, it's 3, for amex, it's 4.
     */
    val cvcLength: Int = DEFAULT_CVC_LENGTH,
    /**
     * The positions of the divider after the card is formatted.
     * e.g. for "4242 4242 4242 4242", this value is [4, 9, 14].
     * Amex and Diners are: [4, 11],
     */
    val dividerPositions: Array<CardDividerPosition> = DEFAULT_CARD_DIVIDER_POSITIONS
) {
    object Amex : CardIssuer(
        identificationNumber = arrayOf("34", "37"),
        cardNumberLength = 15,
        cvcLength = 4,
        dividerPositions = arrayOf(
            CardDividerPosition(4, 4),
            CardDividerPosition(10, 11)
        )
    )

    object Discover : CardIssuer(identificationNumber = arrayOf("60", "64", "65"))

    object Jcb : CardIssuer(identificationNumber = arrayOf("35"))

    object DinersClub : CardIssuer(
        identificationNumber = arrayOf("300", "301", "302", "303", "304", "305", "309", "36", "38", "39"),
        cardNumberLength = 14,
        dividerPositions = arrayOf(
            CardDividerPosition(4, 4),
            CardDividerPosition(10, 11)
        )
    )

    object Visa : CardIssuer(identificationNumber = arrayOf("4"))

    object Mastercard : CardIssuer(
        identificationNumber = arrayOf(
            "2221", "2222", "2223", "2224", "2225", "2226", "2227", "2228", "2229",
            "223", "224", "225", "226", "227", "228", "229",
            "23", "24", "25", "26",
            "270", "271", "2720",
            "50", "51", "52", "53", "54", "55", "67"
        )
    )

    object Unionpay : CardIssuer(identificationNumber = arrayOf("62"))

    /**
     * The default issuer, all fields are filled up by default values.
     * Its `identificationNumber` is empty to match all number prefix.
     */
    object Unknown : CardIssuer(identificationNumber = arrayOf(""))

    private companion object {
        const val DEFAULT_CARD_NUMBER_LENGTH = 16
        const val DEFAULT_CVC_LENGTH = 3
        val DEFAULT_CARD_DIVIDER_POSITIONS = arrayOf(
            CardDividerPosition(4, 4),
            CardDividerPosition(8, 9),
            CardDividerPosition(12, 14)
        )
    }

    /**
     * Computed field indicating the length of the total card number string after formatted.
     */
    val formattedCardNumberLength: Int get() = cardNumberLength + dividerPositions.count()
}