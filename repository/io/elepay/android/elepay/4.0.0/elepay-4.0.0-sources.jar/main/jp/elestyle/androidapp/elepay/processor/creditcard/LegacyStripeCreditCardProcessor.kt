package jp.elestyle.androidapp.elepay.processor.creditcard

import com.stripe.android.Stripe
import com.stripe.android.model.SourceParams
import com.stripe.android.model.Token
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.CreditCardInfo
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.ServerAPIClient

internal class LegacyStripeCreditCardProcessor(
    private val stripe: Stripe,
    private val paymentData: PaymentCommon,
) : CreditCardProcessor {

    override suspend fun processCard(card: CreditCardInfo): ElepayResult {
        return when (paymentData.dataType) {
            PaymentDataType.CHARGE -> {
                runCatching {
                    stripe.createCardTokenSynchronous(card.asStripeCardParams())
                        ?.let { captureToken(it) }
                        ?: generateFailure(
                            ErrorCode.INVALID_TOKEN,
                            "Failed creating stripe token for credit card."
                        )
                }.getOrElse {
                    generateFailure(
                        ErrorCode.INVALID_TOKEN,
                        it.localizedMessage ?: "Failed creating stripe token for credit card."
                    )
                }
            }

            PaymentDataType.SOURCE -> {
                runCatching {
                    val sourceParams = SourceParams.createCardParams(card.asStripeCardParams())
                    stripe.createSourceSynchronous(sourceParams)
                        ?.id
                        ?.let { sourceId -> confirmSource(sourceId) }
                        ?: generateFailure(
                            ErrorCode.INVALID_TOKEN,
                            "Failed creating stripe source for credit card."
                        )
                }.getOrElse {
                    generateFailure(
                        ErrorCode.INVALID_TOKEN,
                        it.localizedMessage ?: "Failed creating stripe source for credit card."
                    )
                }
            }

            PaymentDataType.CHECKOUT ->
                ElepayResult.Failed(
                    paymentData.id,
                    ElepayError.PaymentFailure(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            paymentData.provider,
                            paymentData.method,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "CHECKOUT data should not pass to stripe processing."
                    )
                )
        }
    }

    override fun cancelProcessing() {}

    private suspend fun captureToken(token: Token): ElepayResult =
        when (val res = ServerAPIClient.capture(paymentData.id, token.id)) {
            is ResultType.Failed ->
                generateFailure(ErrorCode.FAILED_CAPTURE, "${res.error.code} ${res.error.message}")

            is ResultType.Succeeded -> ElepayResult.Succeeded(paymentData.id)
        }

    private suspend fun confirmSource(sourceId: String): ElepayResult =
        when (val res = ServerAPIClient.confirm(paymentData.id, sourceId)) {
            is ResultType.Failed ->
                generateFailure(ErrorCode.FAILED_CONFIRM, "${res.error.code} ${res.error.message}")

            is ResultType.Succeeded -> ElepayResult.Succeeded(paymentData.id)
        }

    private fun generateFailure(errorCode: ErrorCode, message: String): ElepayResult.Failed {
        val paymentError = ElepayError.PaymentFailure(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.SDK,
                PaymentMethodProvider.STRIPE,
                PaymentMethod.CREDIT_CARD,
                errorCode
            ),
            message = message
        )
        return ElepayResult.Failed(paymentData.id, paymentError)
    }
}