package jp.elestyle.androidapp.elepay.activity

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.Intent
import android.os.Bundle
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessingResult
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.core.theme.checkAndApplyElepayTheme
import jp.elestyle.androidapp.elepay.core.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

/**
 * Entry activity for payment callbacks delivered through a deep link from an external app or
 * browser (au PAY, PayPay, Merpay, LINE Pay, J-Coin Pay, Alipay+, external-browser web flow).
 *
 * The hosting app registers this activity (or a subclass) in its own manifest against the elepay
 * callback scheme `ep<appId>`. Because the deep link is opened by the *external* app, this
 * activity is resumed on top of that external app's task; merely calling [finish] would return
 * the user to the external app instead of the host's business screen. After delivering the
 * result we therefore bring the host task back to the foreground via [returnToHostApp].
 *
 * In-app flows (e.g. 3-D Secure / web payment handled by `ElepayWebProcessorActivity`) never
 * reach this activity, so the host-task restoration here only runs when the user is genuinely
 * returning from an external app.
 */
@Keep
open class ElepayCallbackActivity : AppCompatActivity(), CoroutineScope by MainScope() {

    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        checkAndApplyElepayTheme(ConfigManager.theme)

        super.onCreate(savedInstanceState)

        setContentView(R.layout.callback_activity)

        handleCallbackIntent(intent)
    }

    /**
     * When this activity runs as `singleTask` and an instance already exists, subsequent deep
     * links are delivered through [onNewIntent] rather than [onCreate]. Handle them here too,
     * otherwise the callback uri would be silently dropped and the result never delivered.
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleCallbackIntent(intent)
    }

    private fun handleCallbackIntent(intent: Intent) {
        val uri = intent.data ?: run {
            // Not a callback deep link: nothing to process and nowhere external to return from.
            finish()
            return
        }

        lifecycleScope.launch {
            val processedRes = when (val res = CallbackProcessor.processCallbackUri(uri)) {
                is CallbackProcessingResult.InvalidUri -> {
                    // Could not pass this error back to user, since we don't know the "paymentId"
                    log("ElepayCallbackActivity", "Invalid uri $uri. Extra msg: ${res.message}")
                    null
                }

                is CallbackProcessingResult.Result -> res.result
            }

            finishCallback(processedRes)
        }
    }

    private fun finishCallback(result: CallbackProcessable.ProcessedResult?) {
        if (result != null) {
            ElepayResultHandlerManager.notifyResult(result.elepayResult, result.paymentId)
        }
        runOnUiThread {
            returnToHostApp()
            finish()
        }
    }

    /**
     * Brings the host app's own task back to the foreground so the user returns to the host app
     * instead of being left on the external payment app. Invoked on the main thread right before
     * this activity finishes, for every callback that arrived through a deep link uri (including
     * ones whose result could not be resolved, e.g. after the host process was recreated).
     *
     * Default strategy:
     * 1. Move the host's launcher task to the front via [ActivityManager.AppTask.moveToFront],
     *    preserving its existing back stack and UI state.
     * 2. Fall back to relaunching the host through [getLaunchIntentForPackage] when no such task
     *    is found (e.g. it was swiped away from recents during payment).
     *
     * Every step is guarded so that OEM quirks, missing task info or security restrictions can
     * never throw into the callback flow; in the worst case this activity simply finishes.
     *
     * Hosts with non-standard task/navigation requirements (e.g. some Flutter / React Native
     * setups) may override this. The SDK still guarantees [finish] is called afterwards.
     */
    protected open fun returnToHostApp() {
        if (moveHostLauncherTaskToFront()) return
        relaunchHostApp()
    }

    /**
     * Moves the host's launcher task to the front. Returns `true` if such a task was found and
     * the move was issued, `false` otherwise (including on any failure), so the caller can fall
     * back to relaunching the host.
     */
    private fun moveHostLauncherTaskToFront(): Boolean = runCatching {
        val activityManager = getSystemService(ActivityManager::class.java)
        val launcherTask = activityManager?.appTasks?.firstOrNull { task ->
            val baseIntent = runCatching { task.taskInfo.baseIntent }.getOrNull()
            baseIntent?.action == Intent.ACTION_MAIN &&
                baseIntent.hasCategory(Intent.CATEGORY_LAUNCHER)
        }
        launcherTask?.moveToFront()
        launcherTask != null
    }.getOrDefault(false)

    private fun relaunchHostApp() {
        runCatching {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: return
            launchIntent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
            startActivity(launchIntent)
        }
    }
}
