package jp.elestyle.androidapp.elepay.checkout.utils.parsing

import android.util.Base64
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.checkout.data.CheckoutData
import jp.elestyle.androidapp.elepay.checkout.data.CheckoutPayload
import jp.elestyle.androidapp.elepay.checkout.data.CheckoutProduct
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.checkout.data.CodeSettings
import jp.elestyle.androidapp.elepay.checkout.data.PaymentMethodData
import jp.elestyle.androidapp.elepay.checkout.data.PaymentMethodResourceInfo
import jp.elestyle.androidapp.elepay.checkout.utils.CheckoutResult
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.utils.InnerConfigManagerWrap
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.core.encryptor.ContentConverter
import org.json.JSONArray
import org.json.JSONObject

object DataParser {
    var base64Decoding: (String) -> ByteArray = { encoded ->
        Base64.decode(encoded, Base64.DEFAULT)
    }

    internal fun parseCheckout(jsonCheckout: JSONObject): CheckoutResult<CheckoutData> {
        val codeId = jsonCheckout.optString("id", "")
        if (codeId.isEmpty()) {
            return CheckoutResult.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "No code id."
                )
            )
        }

        val orderId = jsonCheckout.optString("orderNo", "")
        if (orderId.isEmpty()) {
            return CheckoutResult.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "No order id."
                )
            )
        }

        val payloadStr = jsonCheckout.optString("payload", "")
        if (payloadStr.isEmpty()) {
            return CheckoutResult.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "no checkout payload"
                )
            )
        }
        val jsonPayload = ContentConverter.retrieveEncryptedContent(payloadStr)
            ?.let { encryptedContent ->
                try {
                    JSONObject(ContentConverter.decrypt(encryptedContent, base64Decoding))
                } catch (e: Exception) {
                    null
                }
            }
            ?: return CheckoutResult.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "invalid checkout payload"
                )
            )
        val appId = jsonPayload.optString("appId", "")
        val pk = jsonPayload.optString("key")
        if (appId.isEmpty() || pk.isEmpty()) {
            return CheckoutResult.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "invalid checkout payload content"
                )
            )
        }
        if (pk != InnerConfigManagerWrap.appKey) {
            return CheckoutResult.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "The public key dose not match."
                )
            )
        }
        val payload = CheckoutPayload(appId, pk)

        val amount = jsonCheckout.optString("amount", "")
        val currency = jsonCheckout.optString("currency", "JPY")
        val expiryDuration = jsonCheckout.optLong("expiryPeriod", 0L)

        val items = jsonCheckout.optJSONArray("items")?.let { jsonItems ->
            val products = mutableListOf<CheckoutProduct>()
            for (i in 0 until jsonItems.length()) {
                val jsonItem = jsonItems.optJSONObject(i) ?: continue

                val imageUrl = jsonItem.optString("image", "")
                val title = jsonItem.optString("name", "")
                val unitPrice = jsonItem.optString("price", "")
                val count = jsonItem.optInt("count", 1)
                products.add(CheckoutProduct(imageUrl, title, unitPrice, count))
            }
            return@let products
        }

        return CheckoutResult.Succeeded(
            CheckoutData(
                codeId,
                orderId,
                amount,
                currency,
                expiryDuration,
                items,
                payload
            )
        )
    }

    internal fun parseCodeSettings(jsonCodeSettings: JSONObject): CheckoutResult<CodeSettings> {
        val payloadStr = jsonCodeSettings.optString("payload")
        if (payloadStr.isEmpty()) {
            return CheckoutResult.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "no code-setting payload."
                )
            )
        }

        val jsonPayload = ContentConverter.retrieveEncryptedContent(payloadStr)
            ?.let { encryptedContent ->
                try {
                    JSONObject(ContentConverter.decrypt(encryptedContent, base64Decoding))
                } catch (e: Exception) {
                    null
                }
            }
            ?: return CheckoutResult.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "invalid checkout payload."
                )
            )

        val basic = jsonPayload.optJSONObject("basic") ?: JSONObject()
        val paymentFilters = jsonPayload.optJSONArray("paymentFilters") ?: JSONArray()

        val jsonPaymentMethods = jsonPayload.optJSONArray("paymentMethods") ?: JSONArray()
        val methodsData = mutableListOf<PaymentMethodData>()
        for (i in 0 until jsonPaymentMethods.length()) {
            val jsonPm = jsonPaymentMethods.optJSONObject(i) ?: continue

            // Filter pms which is not for android.
            val jsonResources = jsonPm.optJSONArray("resources") ?: continue
            var isAndroidResource = false
            for (j in 0 until jsonResources.length()) {
                val res = jsonResources.optString(j, "")
                if (res == "android") {
                    isAndroidResource = true
                    break
                }
            }
            if (!isAndroidResource) continue

            val pm = jsonPm.optString("paymentMethod", "")
                .let {
                    PaymentMethod.from(it)
                }
                ?: continue
            val brands = jsonPm.optJSONArray("brand")?.let { jsonBrands ->
                val brandStrings = mutableListOf<String>()
                for (brandIdx in 0 until jsonBrands.length()) {
                    brandStrings.add(jsonBrands.optString(brandIdx))
                }
                brandStrings
            } ?: listOf()
            methodsData.add(PaymentMethodData(pm, brands))
        }

        return CheckoutResult.Succeeded(CodeSettings(basic, paymentFilters, methodsData))
    }

    internal fun parsePaymentMethodResourceInfo(json: JSONObject): Map<String, PaymentMethodResourceInfo> {
        val ret = mutableMapOf<String, PaymentMethodResourceInfo>()
        for (key in json.keys()) {
            val jsonPaymentMethodResource = json.optJSONObject(key) ?: continue
            val jsonName = jsonPaymentMethodResource.optJSONObject("name") ?: continue
            val jsonImage = jsonPaymentMethodResource.optJSONObject("image") ?: continue

            val nameMap = mutableMapOf<String, String>()
            for (i18nKey in jsonName.keys()) {
                nameMap[i18nKey] = jsonName.optString(i18nKey)
            }

            val imageUrlMap = mutableMapOf<String, String>()
            for (imageUrlKey in jsonImage.keys()) {
                imageUrlMap[imageUrlKey] = jsonImage.optString(imageUrlKey)
            }

            ret[key] = PaymentMethodResourceInfo(nameMap, imageUrlMap)
        }
        return ret
    }

    internal fun generateUserAwareInvalidPayloadError(
        errorCode: ErrorCode,
        message: String = "charge error"
    ): ElepayError.InvalidPayload =
        ElepayError.InvalidPayload(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.ENDUSER,
                errorCode
            ),
            message = message
        )
}