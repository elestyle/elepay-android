package jp.elestyle.androidapp.elepay.checkout.data

import android.os.Build
import android.os.Parcel
import android.os.Parcelable
import org.json.JSONArray
import org.json.JSONObject

internal data class CodeSettings(
    // Currently this field is not used, so leave it as the raw json.
    val basic: JSONObject,

    // Currently this field is not used, so leave it as the raw json.
    val paymentFilters: JSONArray,

    val paymentMethodsData: List<PaymentMethodData>
) : Parcelable {
    @Suppress("UNCHECKED_CAST")
    constructor(parcel: Parcel) : this(
        basic = (parcel.readString() ?: "").run {
            if (isEmpty()) JSONObject() else {
                try {
                    JSONObject(this)
                } catch (e: Exception) {
                    JSONObject()
                }
            }
        },
        paymentFilters = (parcel.readString() ?: "").run {
            if (isEmpty()) JSONArray() else {
                try {
                    JSONArray(this)
                } catch (e: Exception) {
                    JSONArray()
                }
            }
        },
        paymentMethodsData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            parcel.readParcelableArray(
                PaymentMethodData::class.java.classLoader,
                PaymentMethodData::class.java
            )!!
        } else {
            @Suppress("DEPRECATION")
            parcel.readParcelableArray(PaymentMethodData::class.java.classLoader)
        }?.toList() as? List<PaymentMethodData> ?: listOf()
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(basic.toString())
        dest.writeString(paymentFilters.toString())
        dest.writeParcelableArray(paymentMethodsData.toTypedArray(), 0)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<CodeSettings> {
        override fun createFromParcel(source: Parcel): CodeSettings = CodeSettings(source)

        override fun newArray(size: Int): Array<CodeSettings?> = arrayOfNulls(size)
    }
}