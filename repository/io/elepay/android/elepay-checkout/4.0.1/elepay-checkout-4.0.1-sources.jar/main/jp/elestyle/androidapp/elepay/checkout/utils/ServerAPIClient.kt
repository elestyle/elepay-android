package jp.elestyle.androidapp.elepay.checkout.utils

import jp.elestyle.androidapp.elepay.utils.InnerConfigManagerWrap
import jp.elestyle.androidapp.elepay.utils.InnerServerAPIClientWrap
import jp.elestyle.androidapp.elepay.utils.InnerServerAPIClientWrap.fetchCommonHeaders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

internal object ServerAPIClient {

    suspend fun retrieveCheckout(code: String, domain: String) = withContext(Dispatchers.IO) {
        val header = mapOf(
            "origin" to domain
        )
        InnerServerAPIClientWrap.get(url = "${InnerConfigManagerWrap.apiBaseUrl}/codes-checkout/$code", headers = header)
    }

    suspend fun retrieveCheckoutSetting(pkey: String) = withContext(Dispatchers.IO) {
        InnerServerAPIClientWrap.get(
            url = "${InnerConfigManagerWrap.apiBaseUrl}/config/app-code-setting",
            headers = fetchCommonHeaders(pkey)
        )
    }

    suspend fun retrievePaymentMethodResourceInfo() = withContext(Dispatchers.IO) {
        InnerServerAPIClientWrap.get(
            url = "https://resource.elecdn.com/payment-methods/info.json",
            headers = fetchCommonHeaders()
        )
    }

    suspend fun createChargeForCheckout(
        codeId: String,
        pKey: String,
        paymentMethod: String,
        resource: String
    ) = withContext(Dispatchers.IO) {
        val params = JSONObject().apply {
            put("paymentMethod", paymentMethod)
            put("resource", resource)
        }
        InnerServerAPIClientWrap.post(
            url = "${InnerConfigManagerWrap.apiBaseUrl}/codes/$codeId/charge",
            headers = fetchCommonHeaders(pKey),
            json = params
        )
    }
}