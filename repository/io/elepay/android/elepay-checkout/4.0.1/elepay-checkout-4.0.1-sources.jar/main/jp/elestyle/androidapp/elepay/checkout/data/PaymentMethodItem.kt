package jp.elestyle.androidapp.elepay.checkout.data

import android.os.Build
import android.os.Parcel
import android.os.Parcelable
import jp.elestyle.androidapp.elepay.data.PaymentMethod

internal data class PaymentMethodItem(
    val brand: PaymentMethodBrand,
    val data: PaymentMethod,
    val associatedBrands: List<PaymentMethodBrand>
) : Parcelable {
    @Suppress("UNCHECKED_CAST")
    constructor(parcel: Parcel) : this(
        brand = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            parcel.readParcelable(
                PaymentMethodBrand::class.java.classLoader,
                PaymentMethodBrand::class.java
            )!!
        } else {
            @Suppress("DEPRECATION")
            parcel.readParcelable(PaymentMethodBrand::class.java.classLoader)!!
        },
        data = PaymentMethod.values()[parcel.readInt()],
        associatedBrands = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            parcel.readParcelableArray(
                PaymentMethodBrand::class.java.classLoader,
                PaymentMethodBrand::class.java
            )!!
        } else {
            @Suppress("DEPRECATION")
            parcel.readParcelableArray(PaymentMethodBrand::class.java.classLoader)
        }?.toList() as? List<PaymentMethodBrand> ?: listOf()
    )

    override fun describeContents(): Int = 0

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeParcelable(brand, 0)
        dest.writeInt(data.ordinal)
        dest.writeParcelableArray(associatedBrands.toTypedArray(), 0)
    }

    companion object {
        @Suppress("unused")
        @JvmField
        val CREATOR = object : Parcelable.Creator<PaymentMethodItem> {
            override fun createFromParcel(parcel: Parcel): PaymentMethodItem {
                return PaymentMethodItem(parcel)
            }

            override fun newArray(size: Int): Array<PaymentMethodItem?> {
                return arrayOfNulls(size)
            }
        }
    }
}