package jp.elestyle.androidapp.elepay.checkout.utils

import jp.elestyle.androidapp.elepay.ElepayError

internal sealed class CheckoutResult<out T> {
    data class Succeeded<T>(val data: T) : CheckoutResult<T>()
    data class Failed(val error: ElepayError): CheckoutResult<Nothing>()
}