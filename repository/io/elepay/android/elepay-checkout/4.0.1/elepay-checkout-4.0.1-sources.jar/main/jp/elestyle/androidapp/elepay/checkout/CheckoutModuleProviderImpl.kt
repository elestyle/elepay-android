package jp.elestyle.androidapp.elepay.checkout

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.checkout.activity.CheckoutActivity
import androidx.annotation.Keep
import jp.elestyle.androidapp.elepay.core.interfaces.CheckoutModuleProvider
import org.json.JSONObject

@Keep
class CheckoutModuleProviderImpl : CheckoutModuleProvider {

    companion object {
        private val resultHandlers = mutableMapOf<String, ElepayResultHandler>()

        fun setResultHandler(handlerId: String, handler: ElepayResultHandler) {
            resultHandlers[handlerId] = handler
        }

        fun handlePaymentResult(result: ElepayResult, resultHandlerId: String) {
            val handler = resultHandlers.remove(resultHandlerId)
            Handler(Looper.getMainLooper()).postDelayed({
                handler?.invoke(result)
            }, 100)
        }
    }

    override fun startCheckout(
        fromActivity: Activity,
        checkoutJson: JSONObject,
        resultHandler: Any,
        resultHandlerId: String,
    ) {
        @Suppress("UNCHECKED_CAST")
        val handler = resultHandler as ElepayResultHandler
        setResultHandler(resultHandlerId, handler)

        val intent = Intent(fromActivity, CheckoutActivity::class.java).apply {
            putExtra(CheckoutActivity.IntentKey.CHECKOUT_JSON.name, checkoutJson.toString())
            putExtra(CheckoutActivity.IntentKey.RESULT_HANDLER_ID.name, resultHandlerId)
        }

        fromActivity.startActivity(intent)
    }

    override fun isCheckoutAvailable(): Boolean = true
}
