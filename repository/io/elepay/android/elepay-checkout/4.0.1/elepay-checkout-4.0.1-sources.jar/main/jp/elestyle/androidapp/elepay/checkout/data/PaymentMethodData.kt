package jp.elestyle.androidapp.elepay.checkout.data

import android.os.Parcel
import android.os.Parcelable
import jp.elestyle.androidapp.elepay.data.PaymentMethod

internal data class PaymentMethodData(
    val method: PaymentMethod,
    val associatedBrands: List<String>,
) : Parcelable {
    constructor(parcel: Parcel) : this(
        method = PaymentMethod.values()[parcel.readInt()],
        associatedBrands = mutableListOf<String>().let { ret ->
            parcel.readStringList(ret)
            ret
        }
    )

    override fun describeContents(): Int = 0

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeInt(method.ordinal)
        dest.writeStringList(associatedBrands)
    }

    companion object CREATOR : Parcelable.Creator<PaymentMethodData> {
        override fun createFromParcel(parcel: Parcel): PaymentMethodData {
            return PaymentMethodData(parcel)
        }

        override fun newArray(size: Int): Array<PaymentMethodData?> {
            return arrayOfNulls(size)
        }
    }
}