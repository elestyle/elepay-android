package jp.elestyle.androidapp.elepay.checkout.fragment

import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import jp.elestyle.androidapp.elepay.Elepay
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.core.R as CoreR
import jp.elestyle.androidapp.elepay.checkout.R
import jp.elestyle.androidapp.elepay.checkout.utils.parsing.DataParser
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.checkout.data.CheckoutData
import jp.elestyle.androidapp.elepay.checkout.data.CheckoutProduct
import jp.elestyle.androidapp.elepay.checkout.data.CodeSettings
import jp.elestyle.androidapp.elepay.checkout.data.PaymentMethodBrand
import jp.elestyle.androidapp.elepay.checkout.data.PaymentMethodItem
import jp.elestyle.androidapp.elepay.checkout.utils.CheckoutDataSource
import jp.elestyle.androidapp.elepay.checkout.utils.CheckoutResult
import jp.elestyle.androidapp.elepay.checkout.utils.ServerAPIClient
import jp.elestyle.androidapp.elepay.utils.InnerConfigManagerWrap
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.checkout.utils.extensions.applyElepayThemeColor
import jp.elestyle.androidapp.elepay.checkout.utils.extensions.isDarkMode
import jp.elestyle.androidapp.elepay.core.locale.Localization
import jp.elestyle.androidapp.elepay.core.log
import jp.elestyle.androidapp.elepay.checkout.utils.symbolizeCurrency
import jp.elestyle.androidapp.elepay.utils.InnerServerAPIClientWrap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URL
import java.util.Calendar

internal class CheckoutFragment : Fragment(R.layout.checkout_payment_fragment) {

    interface ActionListener {
        fun onTapPaymentMethod(paymentMethod: PaymentMethod)
        fun onTapProductList(products: List<CheckoutProduct>, currencySymbol: String)
        fun onCheckoutStart()
        fun onCheckoutFinish(elepayResult: ElepayResult)
        fun onCheckoutCanceled()
    }

    private enum class ArgumentsKey(val raw: String) {
        CHECKOUT_JSON("checkout_json_data")
    }

    var actionListener: ActionListener? = null

    private var checkoutData: CheckoutData? = null
    private var selectedPaymentMethod: PaymentMethod? = null
    private val mainScope = MainScope()
    private val bgScope = CoroutineScope(Dispatchers.IO)
    private var countDownTimer: CountDownTimer? = null
    private var isProcessingCheckout = false
    private var doubleBackToExitPressedOnce = false

    private lateinit var paymentMethodLogoView: ImageView
    private lateinit var paymentMethodNameView: TextView
    private lateinit var countDownTextView: TextView
    private lateinit var amountView: TextView
    private lateinit var loadingContainer: ViewGroup

    companion object {
        fun newInstance(checkoutJsonStr: String): CheckoutFragment = CheckoutFragment().also {
            it.init(checkoutJsonStr)
        }
    }

    private fun init(checkoutJsonStr: String) {
        arguments = Bundle().apply {
            putString(ArgumentsKey.CHECKOUT_JSON.raw, checkoutJsonStr)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = super.onCreateView(inflater, container, savedInstanceState)?.also { ret ->
        ret.findViewById<Toolbar>(R.id.paymentFgToolBar).apply {
            title = Localization.string(R.string.checkoutPaymentFragmentTitle)

            val closeIcon = ResourcesCompat
                .getDrawable(resources, R.drawable.ic_close_24, null)
                ?.apply {
                    applyElepayThemeColor(CoreR.color.elepayTextColorPrimary, resources)
                }

            navigationIcon = closeIcon

            setNavigationOnClickListener {
                if (isProcessingCheckout) {
                    log("CheckoutFragment", "block nav-up button when checkout.")

                    if (doubleBackToExitPressedOnce) {
                        isProcessingCheckout = false
                        actionListener?.onCheckoutCanceled()
                        return@setNavigationOnClickListener
                    }

                    doubleBackToExitPressedOnce = true
                    Toast.makeText(requireContext(), Localization.string(R.string.msgPressAgainToCancelCheckout), Toast.LENGTH_SHORT).show()

                    Handler(Looper.getMainLooper()).postDelayed({
                        doubleBackToExitPressedOnce = false
                    }, 2000)

                    return@setNavigationOnClickListener
                }
                actionListener?.onCheckoutCanceled()
            }
        }

        ret.findViewById<TextView>(R.id.paymentFgCountDownPrompt).apply {
            text = Localization.string(R.string.checkoutPaymentFragmentCountDownPrompt)
        }
        countDownTextView = ret.findViewById(R.id.paymentFgCountDownTimer)
        ret.findViewById<TextView>(R.id.paymentFgAmountPrompt).apply {
            text = Localization.string(R.string.checkoutPaymentFragmentAmountPrompt)
        }
        ret.findViewById<TextView>(R.id.paymentFgPaymentMethodPrompt).apply {
            text = Localization.string(R.string.checkoutPaymentFragmentPaymentMethodPrompt)
        }
        ret.findViewById<TextView>(R.id.paymentFgProductsPrompt).apply {
            text = Localization.string(R.string.checkoutPaymentFragmentProductsPrompt)
        }
        paymentMethodLogoView = ret.findViewById(R.id.paymentMethodBrandLogo)
        paymentMethodNameView = ret.findViewById(R.id.paymentMethodBrandName)
        amountView = ret.findViewById(R.id.paymentFgAmountValue)
        loadingContainer = ret.findViewById(R.id.paymentFgLoadingContainer)
        loadingContainer.setOnClickListener {
            // Just consume the touch event to make it impossible to trigger the click event on
            // the ui elements covered by this loading view.
            log("CheckoutFragment", "Don't touch me...")
        }
        ret.findViewById<Button>(R.id.paymentFgPayButton).setOnClickListener {
            processCheckoutCharge()
        }

        return ret
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (checkoutData == null || !CheckoutDataSource.isDataValid) {
            mainScope.launch {
                showLoading(animated = false)
            }
            fetchCheckoutData()
        } else {
            loadCheckoutData(checkoutData!!)
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        countDownTimer?.cancel()
        try {
            mainScope.cancel()
            bgScope.cancel()
        } catch (e: IllegalStateException) {
            log("CheckoutFragment", "cancel scope without jobs")
        }
    }

    fun setPaymentMethod(paymentMethod: PaymentMethodItem) {
        selectedPaymentMethod = paymentMethod.data
        Glide
            .with(requireContext())
            .load(paymentMethod.brand.logoUrl)
            .placeholder(R.drawable.ic_checkout_product_default)
            .into(paymentMethodLogoView)
        paymentMethodNameView.text = paymentMethod.brand.name
    }

    private fun fetchCheckoutData() {
        val codeUrl = retrieveCodeUrl() ?: run {
            notifyFailure(
                ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    "Invalid checkout data: ${arguments?.getString(ArgumentsKey.CHECKOUT_JSON.raw) ?: ""}"
                )
            )
            return
        }

        val domain = codeUrl.host
        val code = codeUrl.path.split("/")[2]

        bgScope.launch {
            val jsonCheckoutData = ServerAPIClient.retrieveCheckout(code, domain).fold(
                onSuccess = { it },
                onFailure = { exception ->
                    val apiErr = exception as InnerServerAPIClientWrap.InnerException
                    val err = ElepayError.SystemError(
                        errorCode = apiErr.code,
                        message = apiErr.message ?: "",
                    )
                    notifyFailure(err)
                    return@launch
                }
            )

            val checkoutData =
                when (val temp = DataParser.parseCheckout(jsonCheckoutData)) {
                    is CheckoutResult.Succeeded -> temp.data
                    is CheckoutResult.Failed -> {
                        notifyFailure(temp.error)
                        null
                    }
                } ?: return@launch

            val jsonCodeSettings = ServerAPIClient.retrieveCheckoutSetting(checkoutData.payload.pKey).fold(
                onSuccess = { it },
                onFailure = { exception ->
                    val apiErr = exception as InnerServerAPIClientWrap.InnerException
                    val err = ElepayError.SystemError(
                        errorCode = apiErr.code,
                        message = apiErr.message ?: "",
                    )
                    notifyFailure(err)
                    return@launch
                }
            )

            val codeSettings =
                when (val temp = DataParser.parseCodeSettings(jsonCodeSettings)) {
                    is CheckoutResult.Succeeded -> temp.data
                    is CheckoutResult.Failed -> {
                        notifyFailure(temp.error)
                        null
                    }
                } ?: return@launch

            val jsonPaymentMethodResInfo = ServerAPIClient.retrievePaymentMethodResourceInfo().fold(
                onSuccess = { it },
                onFailure = { exception ->
                    val apiErr = exception as InnerServerAPIClientWrap.InnerException
                    val err = ElepayError.SystemError(
                        errorCode = apiErr.code,
                        message = apiErr.message ?: "",
                    )
                    notifyFailure(err)
                    return@launch
                }
            )

            val paymentMethodResources = DataParser.parsePaymentMethodResourceInfo(jsonPaymentMethodResInfo)

            // Make sure the loading indicator is visible.
            // When network condition is excellent, this loading finished immediately
            // and caused an animation jerk.
            delay(700)

            mainScope.launch {
                CheckoutDataSource.codeSettings = codeSettings
                CheckoutDataSource.paymentMethodResources = paymentMethodResources
                finishCheckoutDataFetching(checkoutData, codeSettings)
            }
        }
    }

    private fun retrieveCodeUrl(): URL? {
        val checkoutJson = arguments?.getString(ArgumentsKey.CHECKOUT_JSON.raw) ?: return null
        return try {
            val jsonCheckout = JSONObject(checkoutJson)
            val codeUrlStr = jsonCheckout.optString("codeUrl", "")
            URL(codeUrlStr)
        } catch (e: Exception) {
            null
        }
    }

    private fun finishCheckoutDataFetching(checkout: CheckoutData, codeSettings: CodeSettings) {
        checkoutData = checkout

        if (selectedPaymentMethod == null) {
            selectedPaymentMethod = codeSettings.paymentMethodsData.firstOrNull()?.method
        }

        if (selectedPaymentMethod == null) {
            showState(
                R.string.checkoutPaymentStateNoValidPaymentMethod,
                R.drawable.ic_state_exclamation_67
            )
        } else {
            loadCheckoutData(checkout)
        }

        mainScope.launch {
            hideLoading(animated = true)
        }
    }

    private fun loadCheckoutData(checkoutData: CheckoutData) {
        val paymentMethodResources = CheckoutDataSource.paymentMethodResources
            .takeIf { it.isNotEmpty() }
            ?: return

        amountView.text = checkoutData.amountFormattedWithCurrency

        val isDarkMode = resources.configuration.isDarkMode

        val brandKey = selectedPaymentMethod!!.rawValue
        val resourceInfo = paymentMethodResources[brandKey]!!
        PaymentMethodBrand.generateFrom(brandKey, resourceInfo, isDarkMode)?.run {
            Glide
                .with(requireContext())
                .load(logoUrl)
                .placeholder(R.drawable.ic_pm_logo_placeholder)
                .into(paymentMethodLogoView)
            paymentMethodNameView.text = name
        }

        view?.findViewById<LinearLayout>(R.id.paymentFgPaymentMethodLine)?.setOnClickListener {
            actionListener?.onTapPaymentMethod(selectedPaymentMethod!!)
        }

        if (checkoutData.products != null) {
            view?.findViewById<LinearLayout>(R.id.paymentFgPaymentProductsConfirmationLine)?.apply {
                visibility = View.VISIBLE
                setOnClickListener {
                    actionListener?.onTapProductList(
                        products = checkoutData.products!!,
                        currencySymbol = symbolizeCurrency(checkoutData.currency)
                    )
                }
            }
        }

        startCountDown()
    }

    private fun startCountDown() {
        if (checkoutData == null) {
            return
        }

        if (countDownTimer == null) {
            countDownTimer = object : CountDownTimer(checkoutData!!.expiryDuration, 1000) {
                override fun onFinish() {
                    showState(
                        R.string.checkoutPaymentStateExpired,
                        R.drawable.ic_state_exclamation_67
                    )
                    countDownTimer = null
                }

                override fun onTick(millisUntilFinished: Long) {
                    val cal = Calendar.getInstance().apply { timeInMillis = millisUntilFinished }
                    countDownTextView.text = DateFormat.format("mm:ss", cal).toString()
                }
            }
            countDownTimer!!.start()
        }
    }

    private fun processCheckoutCharge() {
        if (checkoutData == null || selectedPaymentMethod == null) {
            return
        }

        mainScope.launch {
            isProcessingCheckout = true
            actionListener?.onCheckoutStart()
            showLoading(animated = true)
        }
        bgScope.launch {
            val jsonCharge = ServerAPIClient.createChargeForCheckout(
                checkoutData!!.codeId,
                InnerConfigManagerWrap.appKey,
                selectedPaymentMethod!!.rawValue,
                "android"
            ).fold(
                onSuccess = { it },
                onFailure = { exception ->
                    val apiErr = exception as InnerServerAPIClientWrap.InnerException
                    notifyFailure(
                        ElepayError.PaymentFailure(
                            apiErr.code,
                            apiErr.message ?: ""
                        )
                    )
                    return@launch
                }
            )

            if (!isActive) return@launch

            Elepay.processPayment(jsonCharge, requireActivity()) { elepayRes ->
                val context = try {
                    requireContext()
                } catch (e: java.lang.IllegalStateException) {
                    return@processPayment
                }

                Localization.setup(context, InnerConfigManagerWrap.languageKey)
                notifyElepayResult(elepayRes)
            }
        }
    }

    private fun notifyFailure(error: ElepayError) {
        notifyElepayResult(ElepayResult.Failed(checkoutData?.codeId, error))
    }

    private fun notifyElepayResult(result: ElepayResult) {
        mainScope.launch {
            hideLoading(animated = false)
            when (result) {
                is ElepayResult.Failed ->
                    actionListener?.onCheckoutFinish(result)

                is ElepayResult.Succeeded -> {
                    showState(0, R.drawable.ic_state_success_67)
                    delay(1500)
                    actionListener?.onCheckoutFinish(result)
                }

                is ElepayResult.Canceled ->
                    actionListener?.onCheckoutFinish(result)
            }
            isProcessingCheckout = false
        }
    }

    private suspend fun showLoading(animated: Boolean) {
        loadingContainer.visibility = View.VISIBLE
        if (animated) {
            loadingContainer.animate()
                .alpha(1f)
                .setDuration(200L)
                .start()
            delay(200L)
        }
    }

    private suspend fun hideLoading(animated: Boolean) {
        if (animated) {
            loadingContainer
                .animate()
                .alpha(0f)
                .setDuration(200L)
                .withEndAction {
                    loadingContainer.visibility = View.INVISIBLE
                    loadingContainer.alpha = 1f
                }
                .start()
            delay(200L)
        } else {
            loadingContainer.visibility = View.INVISIBLE
            loadingContainer.alpha = 1f
        }
    }

    private fun showState(messageResId: Int, imageResId: Int) {
        view?.findViewById<ViewGroup>(R.id.paymentFgStateIndicatorContainer)?.visibility =
            View.VISIBLE
        view?.findViewById<TextView>(R.id.paymentFgStateIndicatorContent)?.apply {
            if (messageResId > 0) {
                text = Localization.string(messageResId)
            }
            setCompoundDrawablesRelativeWithIntrinsicBounds(0, imageResId, 0, 0)
        }
    }
}