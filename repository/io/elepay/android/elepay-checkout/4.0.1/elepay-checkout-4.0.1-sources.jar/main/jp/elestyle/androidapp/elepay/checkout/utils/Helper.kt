package jp.elestyle.androidapp.elepay.checkout.utils

import java.util.Locale

internal fun symbolizeCurrency(currency: String): String =
    when (currency.lowercase(Locale.ROOT)) {
        "jpy" -> "\u00A5"
        else -> ""
    }