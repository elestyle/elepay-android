package jp.elestyle.androidapp.elepay.checkout.data

internal data class PaymentMethodResourceInfo(
    val name: Map<String, String>,
    val imageUrl: Map<String, String>,
)