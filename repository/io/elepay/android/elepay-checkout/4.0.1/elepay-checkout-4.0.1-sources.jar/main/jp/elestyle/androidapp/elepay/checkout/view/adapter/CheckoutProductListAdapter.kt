package jp.elestyle.androidapp.elepay.checkout.view.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import jp.elestyle.androidapp.elepay.checkout.R
import jp.elestyle.androidapp.elepay.checkout.data.CheckoutProduct

internal class CheckoutProductListViewHolder(container: View) : RecyclerView.ViewHolder(container) {
    val imageView: ImageView = container.findViewById(R.id.productItemImage)
    val titleView: TextView = container.findViewById(R.id.productItemName)
    val unitPriceView: TextView = container.findViewById(R.id.productItemUnitPrice)
    val countView: TextView = container.findViewById(R.id.productItemCount)
}

internal class CheckoutProductListAdapter(
    private val products: List<CheckoutProduct>,
    private val currencySymbol: String
) : RecyclerView.Adapter<CheckoutProductListViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CheckoutProductListViewHolder = CheckoutProductListViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.product_item, parent, false)
    )

    override fun getItemCount(): Int = products.count()

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: CheckoutProductListViewHolder, position: Int) {
        val product = products[position]

        Glide
            .with(holder.imageView.context)
            .load(product.imageUrl)
            .placeholder(R.drawable.ic_checkout_product_default)
            .into(holder.imageView)
        holder.titleView.text = product.title
        holder.unitPriceView.text = currencySymbol + product.unitPrice
        holder.countView.text = "x ${product.count}"
    }
}