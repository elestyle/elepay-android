package jp.elestyle.androidapp.elepay.utils

import jp.elestyle.androidapp.elepay.data.APIResult
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.RequestError
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.utils.extensions.urlEncoded
import jp.elestyle.androidapp.elepay.utils.parsing.JsonConverter
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.IOException
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL

internal sealed class ApiPostRequestBody {
    abstract val composedPOSTBody: String
    abstract val relatedContentType: String

    @Suppress("unused")
    data class KeyValuePairs(val params: Map<String, Any>) : ApiPostRequestBody() {
        override val composedPOSTBody: String
            get() = params.entries.joinToString("&") {
                it.key.urlEncoded + "=" + it.value.toString().urlEncoded
            }

        override val relatedContentType: String = "application/x-www-form-urlencoded"
    }

    data class JsonObject(val json: JSONObject) : ApiPostRequestBody() {
        override val composedPOSTBody: String get() = json.toString()

        override val relatedContentType: String = "application/json;charset=utf-8"
    }
}

internal object ApiRequester {
    private const val CONNECTION_TIME_OUT = 30000
    private const val READ_TIME_OUT = 30000

    fun get(
        url: String,
        headers: Map<String, String> = mapOf(),
        params: Map<String, Any> = mapOf(),
        connectTimeout: Int = CONNECTION_TIME_OUT,
        readTimeout: Int = READ_TIME_OUT
    ): APIResult {
        val finalUrl: String = if (params.isEmpty()) url else {
            val queryStr = params.entries.joinToString("&") {
                it.key.urlEncoded + "=" + it.value.toString().urlEncoded
            }
            "$url?$queryStr"
        }

        return performRequest(finalUrl) { conn ->
            conn.connectTimeout = connectTimeout
            conn.readTimeout = readTimeout
            headers.forEach { entry ->
                conn.setRequestProperty(entry.key, entry.value)
            }

            return@performRequest JSONObject(String(conn.inputStream.readBytes()))
        }
    }

    fun post(
        url: String,
        headers: Map<String, String> = mapOf(),
        bodyData: ApiPostRequestBody,
        connectTimeout: Int = CONNECTION_TIME_OUT,
        readTimeout: Int = READ_TIME_OUT
    ): APIResult = performRequest(url) { conn ->
        conn.requestMethod = "POST"
        conn.connectTimeout = connectTimeout
        conn.readTimeout = readTimeout
        headers.forEach { entry ->
            conn.setRequestProperty(entry.key, entry.value)
        }
        conn.setRequestProperty("Content-Type", bodyData.relatedContentType)

        val outputStream = conn.outputStream
        val writer = BufferedWriter(OutputStreamWriter(outputStream))
        writer.write(bodyData.composedPOSTBody)
        writer.flush()
        writer.close()
        outputStream.close()

        JSONObject(String(conn.inputStream.readBytes()))
    }


    private fun performRequest(
        url: String,
        performer: (HttpURLConnection) -> JSONObject
    ): APIResult {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            val json = performer(conn)
            ResultType.Succeeded(json)
        } catch (e: MalformedURLException) {
            val err = createRequestError(
                ErrorCode.BAD_NETWORK,
                e.localizedMessage.orEmpty(),
                mapOf("url" to url)
            )
            ResultType.Failed(err)
        } catch (e: IOException) {
            val err = conn?.handleError(e)
                ?: createRequestError(
                    ErrorCode.BAD_NETWORK, e.localizedMessage.orEmpty(), mapOf("url" to url)
                )
            ResultType.Failed(err)
        } catch (e: JSONException) {
            val err = createRequestError(
                ErrorCode.INVALID_RESPONSE,
                e.localizedMessage.orEmpty(),
                mapOf("url" to url)
            )
            ResultType.Failed(err)
        }
    }

    private fun createRequestError(
        errorCode: ErrorCode,
        message: String,
        extra: Map<String, Any>
    ): RequestError = RequestError(
        code = ErrorCodeGenerator.generate(PlatformCode.ENDUSER, null, null, errorCode),
        message = message,
        extra = extra
    )

}

private fun HttpURLConnection.handleError(exception: Exception): RequestError {
    var rawErrorString = ""
    errorStream?.bufferedReader()?.use { reader ->
        rawErrorString += reader.readLine()
    }
    return try {
        val errorMap = JsonConverter.toMap(JSONObject(rawErrorString))
        val code = errorMap["code"] as? String ?: responseCode.toString()
        val message = errorMap["message"] as? String ?: ""

        @Suppress("UNCHECKED_CAST")
        val extra = errorMap["params"] as? Map<String, Any> ?: mapOf()
        RequestError(code = code, message = message, extra = extra)
    } catch (e: Exception) {
        RequestError(
            code = ErrorCodeGenerator.generate(
                PlatformCode.ENDUSER,
                null,
                null,
                ErrorCode.BAD_NETWORK
            ),
            message = exception.localizedMessage.orEmpty(),
            extra = mapOf(
                "url" to try {
                    this.url
                } catch (e: java.lang.Exception) {
                    "unknown"
                }
            )
        )
    }
}