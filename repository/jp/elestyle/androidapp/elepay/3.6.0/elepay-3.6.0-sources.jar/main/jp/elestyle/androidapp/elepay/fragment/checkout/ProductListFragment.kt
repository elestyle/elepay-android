package jp.elestyle.androidapp.elepay.fragment.checkout

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.Toolbar
import androidx.core.content.res.ResourcesCompat
import androidx.core.os.BundleCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.checkout.CheckoutProduct
import jp.elestyle.androidapp.elepay.utils.extensions.applyElepayThemeColor
import jp.elestyle.androidapp.elepay.utils.locale.Localization
import jp.elestyle.androidapp.elepay.view.adapter.CheckoutProductListAdapter

internal class ProductListFragment : Fragment(R.layout.checkout_products_list_fragment) {
    companion object {
        fun newInstance(
            products: List<CheckoutProduct>,
            currencySymbol: String
        ): ProductListFragment =
            ProductListFragment().apply {
                arguments = Bundle().apply {
                    putString("co_products_symbol", currencySymbol)
                    putParcelableArray("co_products_data", products.toTypedArray())
                }
            }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = super.onCreateView(inflater, container, savedInstanceState)?.also { ret ->
        val products = arguments?.let {
            @Suppress("UNCHECKED_CAST")
            BundleCompat.getParcelableArray(it, "co_products_data", CheckoutProduct::class.java)!!
                    as? Array<CheckoutProduct>
        } ?: return ret
        val symbol = arguments?.getString("co_products_symbol") ?: return ret

        ret.findViewById<Toolbar>(R.id.productsListFgToolBar).apply {
            title = Localization.string(R.string.checkoutPaymentFragmentProductsPrompt)
            navigationIcon = ResourcesCompat
                .getDrawable(resources, R.drawable.ic_arrow_back_light_24dp, null)
                ?.apply {
                    applyElepayThemeColor(R.color.elepayTextColorPrimary, resources)
                }
            setNavigationOnClickListener {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        }

        ret.findViewById<RecyclerView>(R.id.productsListFgProductListView).apply {
            adapter = CheckoutProductListAdapter(products.toList(), symbol)
            layoutManager = LinearLayoutManager(ret.context, LinearLayoutManager.VERTICAL, false)
            ResourcesCompat.getDrawable(resources, R.drawable.horizontal_divider, null)
                ?.also { dividerDrawable ->
                    val divider = DividerItemDecoration(context, LinearLayoutManager.VERTICAL)
                        .apply { setDrawable(dividerDrawable) }
                    addItemDecoration(divider)
                }
        }
    }
}