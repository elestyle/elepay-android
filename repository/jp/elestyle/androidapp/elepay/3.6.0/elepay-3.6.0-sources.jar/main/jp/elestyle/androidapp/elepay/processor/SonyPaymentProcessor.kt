package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.internal.CreditCardProcessingActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.creditcard.WebViewCreditCardProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.creditcard.CreditCardProcessingCenter
import org.json.JSONObject

internal object SonyPaymentProcessor : ElepayProcessor {
    // Always considered as well-configured. Because the credit card processing do not require
    // configs.
    override val isWellConfigured: Boolean = true

    override fun setup(providerConfig: ElepayProviderConfig) {}

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else when (chargeData.method) {

            PaymentMethod.CREDIT_CARD -> {
                processCreditCard(chargeData, fromActivity, resultHandler)
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = chargeData.id,
                        error = ElepayError.UnsupportedPaymentMethod("Sony Payment ${chargeData.method.rawValue}")
                    )
                )
                false
            }
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    private fun processCreditCard(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val processingUrl = retrieveProcessingUrlFrom(chargeData)
        if (processingUrl.isEmpty()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.paymentCommon.id,
                    error = ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            PaymentMethodProvider.SONY_PAYMENT,
                            PaymentMethod.CREDIT_CARD,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "No creditcard processing url for Sony Payment."
                    )
                ),
                handler = resultHandler
            )
            return true
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, chargeData.id)
        }
        CreditCardProcessingCenter[chargeData.id] = WebViewCreditCardProcessor(
            paymentData = chargeData.paymentCommon,
            processingUrl = processingUrl,
            activity = fromActivity
        )
        val intent = Intent(fromActivity, CreditCardProcessingActivity::class.java).apply {
            putExtra(
                CreditCardProcessingActivity.IntentExtraKey.PAYMENT_ID.rawValue,
                chargeData.id
            )
        }
        fromActivity.startActivity(intent)

        return true
    }

    private fun retrieveProcessingUrlFrom(chargeData: ChargeData): String =
        if (chargeData.payload == null) ""
        else try {
            val jsonPayload = JSONObject(chargeData.payload)
            val url = jsonPayload.optString("creditcard")
            if (url.contains("<key>")) {
                url.replaceFirst("<key>", ConfigManager.appKey)
            } else ""
        } catch (e: Exception) {
            ""
        }
}