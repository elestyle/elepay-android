package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.internal.ElepayWebProcessorActivity
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.ServerAPIClient
import jp.elestyle.androidapp.elepay.utils.ServerStatusPoller
import jp.elestyle.androidapp.elepay.utils.log
import org.json.JSONObject

internal object AlipayPlusProcessor : ElepayProcessor, CallbackProcessable {
    private var processingData: CallbackProcessable.ProcessingPaymentInfo? = null
    private var isWebProcessing = false

    override var callbackScheme: String = ""

    override val isWellConfigured: Boolean
        get() = callbackScheme.isNotEmpty()

    override fun setup(providerConfig: ElepayProviderConfig) {
        if (providerConfig is ElepayProviderConfig.AlipayPlus) {
            callbackScheme = providerConfig.appScheme
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = when {
        processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler) -> true

        chargeData.redirectUrl.isNullOrEmpty() -> {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    chargeData.id, ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            chargeData.provider,
                            chargeData.method,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "No redirect url."
                    )
                )
            )
            false
        }

        else -> processAlipayPlusCharge(chargeData, fromActivity, resultHandler)
    }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = when {
        processTestModePayment(sourceData.paymentCommon, fromActivity, resultHandler) -> true

        sourceData.redirectUrl.isNullOrEmpty() -> {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    sourceData.id, ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            sourceData.provider,
                            sourceData.method,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "No redirect url."
                    )
                )
            )
            false
        }

        else -> processAlipayPlusSource(sourceData, fromActivity, resultHandler)
    }

    override fun retrieveProcessingPaymentInfo(
        disposeImmediately: Boolean
    ): CallbackProcessable.ProcessingPaymentInfo? {
        if (isWebProcessing) {
            log("AlipayPlus", "retrieveProcessingPaymentInfo: ignore for web processing.")
            return null
        }

        val ret = processingData
        if (disposeImmediately) {
            processingData = null
        }
        return ret
    }

    override suspend fun continueCallbackProcessing(
        data: CallbackProcessingData
    ): CallbackProcessable.ProcessedResult =
        when (data.paymentData.dataType) {
            PaymentDataType.CHARGE -> processChargeCallback(data.paymentData)

            PaymentDataType.SOURCE -> processSourceCallback(data)

            else -> CallbackProcessable.ProcessedResult(
                data.paymentData.id,
                ElepayResult.Failed(
                    paymentId = data.paymentData.id,
                    error = ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            data.paymentData.provider,
                            data.paymentData.method,
                            ErrorCode.INVALID_RESPONSE
                        ),
                        "Callback url contains non-processable type: ${data.paymentData.dataType}."
                    )
                )
            )
        }

    private fun processAlipayPlusCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val paymentUrl = chargeData.redirectUrl
        val paymentId = chargeData.id
        processingData = CallbackProcessable.ProcessingPaymentInfo(chargeData.paymentCommon)

        return try {
            if (resultHandler != null) {
                ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
            }

            val intent = if (chargeData.payload == "waiting") {
                isWebProcessing = true
                Intent(fromActivity, ElepayWebProcessorActivity::class.java).apply {
                    putExtra(
                        ElepayWebProcessorActivity.IntentExtraKey.PAYMENT_DATA.rawValue,
                        chargeData.paymentCommon
                    )
                    putExtra(
                        ElepayWebProcessorActivity.IntentExtraKey.TARGET_URL.rawValue,
                        paymentUrl
                    )
                }
            } else {
                val uri = Uri.parse(paymentUrl)
                Intent(Intent.ACTION_VIEW, uri).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            }
            fromActivity.startActivity(intent)
            true
        } catch (e: Exception) {
            val failure = ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        chargeData.provider,
                        chargeData.method,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    "Url for payment processing is invalid."
                )
            )
            resultHandler?.invoke(failure)
            false
        }
    }

    private suspend fun processChargeCallback(paymentData: PaymentCommon): CallbackProcessable.ProcessedResult {
        val pollingPolicy = ServerStatusPoller.PollPolicy(
            statusValidating = { status -> status == "captured" },
            intervalMillis = 3000L,
            maxPollingCount = 5,
            extraFailureMessage = "Alipay-plus"
        )
        val elepayResult = ServerStatusPoller.poll(paymentData, pollingPolicy)
        return CallbackProcessable.ProcessedResult(paymentData.id, elepayResult)
    }

    private fun processAlipayPlusSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val paymentId = sourceData.id
        processingData = CallbackProcessable.ProcessingPaymentInfo(sourceData.paymentCommon)

        return if (processAlipayAppUrl(sourceData, fromActivity)) {
            if (resultHandler != null) {
                ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
            }
            true
        } else {
            val failure = ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        sourceData.provider,
                        sourceData.method,
                        ErrorCode.APP_NOT_INSTALLED
                    ),
                    "Url for source processing could not be opened."
                )
            )
            resultHandler?.invoke(failure)
            false
        }
    }

    private fun processAlipayAppUrl(sourceData: SourceData, fromActivity: Activity): Boolean =
        try {
            // First try: redirectUrl
            sourceData.redirectUrl?.run {
                tryOpenUrl(this, fromActivity)
                true
            } ?: throw Exception()
        } catch (e: Exception) {
            // Then try the following:
            // - payload.applinkUrl
            // - payload.normalUrl
            val jsonPayload = sourceData.payload
                ?.runCatching { JSONObject(this) }
                ?.getOrNull()
                ?: run { return false }

            try {
                tryOpenUrl(jsonPayload.optString("applinkUrl"), fromActivity)
                true
            } catch (e: Exception) {
                try {
                    tryOpenUrl(jsonPayload.optString("normalUrl"), fromActivity)
                    true
                } catch (e: Exception) {
                    false
                }
            }
        }

    private fun tryOpenUrl(url: String, fromActivity: Activity) {
        val uri = Uri.parse(url)
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        fromActivity.startActivity(intent)
    }

    private suspend fun processSourceCallback(data: CallbackProcessingData): CallbackProcessable.ProcessedResult {
        val paymentId = data.paymentData.id
        val authCode = data.params["authCode"] ?: return CallbackProcessable.ProcessedResult(
            paymentId,
            ElepayResult.Failed(
                paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        data.paymentData.provider,
                        data.paymentData.method,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    "Callback url does not contains auth code."
                )
            )
        )
        val elepayRes = when (val res = ServerAPIClient.confirm(data.paymentData.id, authCode)) {
            is ResultType.Failed -> {
                ElepayResult.Failed(
                    paymentId = paymentId,
                    error = ElepayError.PaymentFailure(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            data.paymentData.provider,
                            data.paymentData.method,
                            ErrorCode.FAILED_CONFIRM
                        ),
                        "Failed to confirm ${res.error.code}, ${res.error.message}."
                    )
                )
            }

            is ResultType.Succeeded -> ElepayResult.Succeeded(paymentId)
        }
        return CallbackProcessable.ProcessedResult(paymentId, elepayRes)
    }
}