package jp.elestyle.androidapp.elepay.utils

import android.content.Context
import android.util.Log
import jp.elestyle.androidapp.elepay.BuildConfig
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.utils.parsing.ContentConverter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream

/**
 * Used to manage errors uploading.
 */
internal object InfoReporter {
    /**
     * The associated data of the report
     */
    data class RefData(val data: JSONObject, val dataType: PaymentDataType)

    private val logTag = InfoReporter::class.java.simpleName

    private const val cacheFilePrefix = "elepay_report_cache_"
    private const val fileContentSeparator = "--------"

    // How many content(error) can be stored in each file.
    // As a brief test(20201021), the encoded data is about 3KB.
    // Max to 300KB for each remote-uploading and file-writing is a reasonable value.
    private const val fileContentCapacity = 100

    // How many files could be stored.
    private const val fileCapacity = 10

    private val bgScope = CoroutineScope(Dispatchers.IO)
    private val cache: MutableMap<String, MutableList<String>> = mutableMapOf()

    // Guard for duplicated setup.
    private var isSetup = false

    // Record the oldest file name to remove when over capacity.
    private var oldestFileName: String = ""

    // Record the latest file name to cache quickly.
    private var latestFileName: String = ""

    fun reportFailure(failure: ElepayResult.Failed, refData: RefData, context: Context) {
        prepareCache(context)

        val key = SecuredDataStore.retrieveKey()
        val data = JSONObject().apply {
            put("refId", failure.paymentId ?: "")
            put("refType", refData.dataType.stringPresentation)
            put("refObject", refData.data)
            put("resource", "android")
            put("sdkVersion", BuildConfig.LIB_VERSION_CODE)
            put("device", JSONObject(DeviceUtil.deviceInfo))
            put("error", failure.error.serialized())
            put("timestamp", System.currentTimeMillis().toString())
        }
        val encrypted = ContentConverter.encrypt(data.toString(), key)

        // Always save to local storage first.
        cacheData(encrypted, context)

        sendCachedReports(context)
    }

    /**
     * Upload the cached report data in the order of latest -> oldest.
     *
     * The contents are uploaded by files.
     */
    fun sendCachedReports(context: Context) {
        // Make sure internal data structure are setup correctly.
        prepareCache(context)

        val reportsForUploading = synchronized(this) { cache[latestFileName] }
            ?: return
        bgScope.launch {
            when (val res = ServerAPIClient.report(reportsForUploading)) {
                is ResultType.Succeeded -> {
                    removeLatestCache(context)
                    sendCachedReports(context)
                }

                is ResultType.Failed -> {
                    // Nothing to do, the data has already been cached.
                    if (BuildConfig.DEBUG) Log.d(logTag, "${res.error}")
                }
            }
        }
    }

    @Synchronized
    private fun prepareCache(context: Context) {
        if (isSetup) return

        val files = context.cacheDir.listFiles()
            ?.filter { it.name.startsWith(cacheFilePrefix) }
            ?: listOf()

        for (file in files) {
            val contents = String(FileInputStream(file).readBytes())
                .split(fileContentSeparator)
                .toMutableList()
            cache[file.name] = contents
        }

        if (cache.keys.isNotEmpty()) {
            val sorted = cache.keys.sorted()
            oldestFileName = sorted.first()
            latestFileName = sorted.last()
        }

        isSetup = true

    }

    // Cache the data to both memory cache and temp file cache.
    @Synchronized
    private fun cacheData(data: String, context: Context) {
        // In case this is the first data to be cached.
        ensureFileNamePointers()

        if (cache[latestFileName] != null && cache[latestFileName]!!.count() < fileContentCapacity) {
            // Cache to the current file only when the file exists and not over capacity.
            cache[latestFileName]!!.add(data)
        } else {
            // When the file content is over capacity, need to create a new cache file.
            if (cache[latestFileName] != null) {
                latestFileName = generateCacheFileName()
            }

            cache[latestFileName] = mutableListOf(data)
            if (cache.count() > fileCapacity) {
                cache.remove(oldestFileName)
                deleteCacheFile(oldestFileName, context)

                oldestFileName = cache.keys.minOrNull()!!
            }
        }

        val newContent = cache[latestFileName]!!.joinToString(fileContentSeparator)
        cacheDataToFile(latestFileName, context, newContent)
    }

    @Synchronized
    private fun removeLatestCache(context: Context) {
        ensureFileNamePointers()

        if (cache[latestFileName] != null) {
            cache.remove(latestFileName)
            deleteCacheFile(latestFileName, context)

            if (cache.isEmpty()) {
                latestFileName = ""
                oldestFileName = ""
            } else {
                latestFileName = cache.keys.maxOrNull()!!
            }
        }
    }

    private fun ensureFileNamePointers() {
        if (latestFileName.isEmpty()) {
            latestFileName = generateCacheFileName()
        }

        if (oldestFileName.isEmpty()) {
            oldestFileName = latestFileName
        }
    }

    private fun generateCacheFileName(): String = "$cacheFilePrefix${System.currentTimeMillis()}"

    private fun cacheDataToFile(fileName: String, context: Context, data: String) {
        try {
            val stream = File(context.cacheDir, fileName).outputStream()
            stream.write(data.toByteArray())
            stream.flush()
        } catch (e: Exception) {
            if (BuildConfig.DEBUG) e.printStackTrace()
        }
    }

    private fun deleteCacheFile(fileName: String, context: Context) {
        try {
            File(context.cacheDir, fileName).delete()
        } catch (e: Exception) {
            if (BuildConfig.DEBUG) e.printStackTrace()
        }
    }
}

private fun ElepayError.serialized(): JSONObject =
    when (this) {
        is ElepayError.SDKNotSetup -> JSONObject().apply {
            put("reason", "SDK not init")
            put("code", errorCode)
            put("message", message)
        }

        is ElepayError.UnsupportedPaymentMethod -> JSONObject().apply {
            put("reason", "Unsupported payment method")
            put("code", "")
            put("message", paymentMethod)
        }

        is ElepayError.AlreadyMakingPayment -> JSONObject().apply {
            put("reason", "Already making payment")
            put("code", "")
            put("message", paymentId)
        }

        is ElepayError.InvalidPayload -> JSONObject().apply {
            put("reason", "Invalid payload")
            put("code", errorCode)
            put("message", message)
        }

        is ElepayError.UninitializedPaymentMethod -> JSONObject().apply {
            put("reason", "Uninitialized payment method")
            put("code", errorCode)
            put("message", message)
        }

        is ElepayError.SystemError -> JSONObject().apply {
            put("reason", "System error")
            put("code", errorCode)
            put("message", message)
        }

        is ElepayError.PaymentFailure -> JSONObject().apply {
            put("reason", "Payment failure")
            put("code", errorCode)
            put("message", message)
        }

        is ElepayError.PermissionRequired -> JSONObject().apply {
            put("reason", "Missing permissions")
            put("code", "")
            put("message", permissions.joinToString(", "))
        }
    }