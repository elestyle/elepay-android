package jp.elestyle.androidapp.elepay.activity.googlepay

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.core.os.BundleCompat
import com.google.android.gms.wallet.AutoResolveHelper
import com.google.android.gms.wallet.PaymentDataRequest
import com.google.android.gms.wallet.PaymentsClient
import com.google.android.gms.wallet.Wallet
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.asWalletConstantsValue
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.GooglePayHelper
import jp.elestyle.androidapp.elepay.utils.ServerAPIClient
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject
import com.google.android.gms.wallet.PaymentData as GooglePaymentData

internal class GooglePayProcessingActivity : Activity() {
    enum class IntentExtraKey(val rawValue: String) {
        PAYMENT_BASE_DATA("google_pay_payment_common"),
        PAYMENT_DATA_AMOUNT("google_pay_payment_amount"),
        PAYMENT_DATA_CURRENCY("google_pay_payment_currency"),
        PAYMENT_DATA_REQUEST_JSON("google_pay_payment_data_request_json"),
    }

    @Suppress("PrivatePropertyName")
    private val GOOGLE_PAY_LOAD_PAYMENT_DATA_REQUEST_CODE = 2347

    private lateinit var paymentData: PaymentCommon
    private lateinit var amount: String
    private lateinit var currency: String
    private lateinit var paymentDataParams: JSONObject
    private lateinit var googlePayClient: PaymentsClient

    private val mainScope = MainScope()
    private val paymentId: String
        get() = paymentData.id

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        intent.extras!!.run {
            paymentData = BundleCompat.getParcelable(
                this,
                IntentExtraKey.PAYMENT_BASE_DATA.rawValue,
                PaymentCommon::class.java
            )!!
            amount = getString(IntentExtraKey.PAYMENT_DATA_AMOUNT.rawValue) ?: "0"
            currency = getString(IntentExtraKey.PAYMENT_DATA_CURRENCY.rawValue) ?: "JPY"
            paymentDataParams = getString(IntentExtraKey.PAYMENT_DATA_REQUEST_JSON.rawValue)!!.let {
                try {
                    JSONObject(it)
                } catch (e: java.lang.Exception) {
                    JSONObject()
                }
            }
        }

        val env = ConfigManager.googlePayEnvironment
        if (env == null) {
            val error = ElepayError.UninitializedPaymentMethod(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.ENDUSER,
                    paymentData.provider,
                    PaymentMethod.GOOGLE_PAY,
                    ErrorCode.UNINIT
                ),
                paymentMethod = PaymentMethod.GOOGLE_PAY.rawValue,
                message = "Google Pay Environment is not set."
            )
            notifyResult(ElepayResult.Failed(paymentId, error))
            finish()
            return
        }

        val options = Wallet.WalletOptions.Builder()
            .setEnvironment(env.asWalletConstantsValue())
            .build()
        googlePayClient = Wallet.getPaymentsClient(this, options)

        val request = createPaymentDataRequest()
        AutoResolveHelper.resolveTask(
            googlePayClient.loadPaymentData(request),
            this,
            GOOGLE_PAY_LOAD_PAYMENT_DATA_REQUEST_CODE
        )
    }

    override fun onDestroy() {
        super.onDestroy()

        mainScope.cancel()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            GOOGLE_PAY_LOAD_PAYMENT_DATA_REQUEST_CODE -> finishGooglePay(data, resultCode)
            else -> {
                // Not interested in other requests...
            }
        }
    }

    private fun createPaymentDataRequest(): PaymentDataRequest {
        val transaction = JSONObject()
            .put("totalPrice", amount)
            .put("totalPriceStatus", "FINAL")
            .put("currencyCode", currency)

        val paymentDataRequest = paymentDataParams
            .put("transactionInfo", transaction)
            .toString()

        return PaymentDataRequest.fromJson(paymentDataRequest)
    }

    private fun finishGooglePay(data: Intent?, resultCode: Int) {
        val failure = ElepayResult.Failed(
            paymentId,
            ElepayError.PaymentFailure(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    paymentData.provider,
                    paymentData.method,
                    ErrorCode.FAILED
                ),
                message = "Failed charging."
            )
        )
        when (resultCode) {
            RESULT_OK -> {
                if (data == null) {
                    notifyResult(failure)
                    return
                }

                val gatewayToken = GooglePaymentData.getFromIntent(data)
                    ?.toJson()
                    ?.let { paymentInfoJsonString ->
                        try {
                            JSONObject(paymentInfoJsonString)
                                .optJSONObject("paymentMethodData")
                                ?.optJSONObject("tokenizationData")
                                ?.optString("token")
                        } catch (e: java.lang.Exception) {
                            null
                        }
                    }
                if (gatewayToken == null) {
                    notifyResult(failure)
                    return
                }

                // Let a gateway token parser transform the generated token.
                // e.g. When using Stripe as the gateway, the token generated here is actually a
                // json string.
                val token = GooglePayHelper.retrieveGatewayTokenParser(paymentId)
                    ?.invoke(gatewayToken)
                    ?: gatewayToken
                when (paymentData.dataType) {
                    PaymentDataType.CHARGE -> capturePayment(token)
                    PaymentDataType.SOURCE -> confirmPayment(token)
                    // Impossible
                    PaymentDataType.CHECKOUT -> {
                        val error = ElepayError.PaymentFailure(
                            errorCode = ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                paymentData.provider,
                                paymentData.method,
                                ErrorCode.FAILED_CAPTURE
                            ),
                            message = "Unable to process checkout for GooglePay"
                        )
                        notifyResult(ElepayResult.Failed(paymentId, error))
                    }
                }
            }

            RESULT_CANCELED -> notifyResult(ElepayResult.Canceled(paymentId))

            AutoResolveHelper.RESULT_ERROR -> notifyResult(failure)
        }
    }

    private fun capturePayment(token: String) = mainScope.launch {
        when (val result = ServerAPIClient.capture(paymentId = paymentId, token = token)) {
            is ResultType.Failed ->
                notifyResult(
                    ElepayResult.Failed(
                        paymentId,
                        ElepayError.PaymentFailure(
                            ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                paymentData.provider,
                                paymentData.method,
                                ErrorCode.FAILED_CAPTURE
                            ), result.error.message
                        )
                    )
                )

            is ResultType.Succeeded ->
                notifyResult(ElepayResult.Succeeded(paymentId))
        }
    }

    private fun confirmPayment(token: String) = mainScope.launch {
        when (val result = ServerAPIClient.confirm(sourceId = paymentId, token = token)) {
            is ResultType.Failed ->
                notifyResult(
                    ElepayResult.Failed(
                        paymentId,
                        ElepayError.PaymentFailure(
                            ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                paymentData.provider,
                                paymentData.method,
                                ErrorCode.FAILED_CAPTURE
                            ), result.error.message
                        )
                    )
                )

            is ResultType.Succeeded ->
                notifyResult(ElepayResult.Succeeded(paymentId))
        }
    }

    private fun notifyResult(result: ElepayResult) {
        ElepayResultHandlerManager.notifyResult(result, paymentId)
        runOnUiThread { finish() }
    }
}