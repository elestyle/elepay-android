package jp.elestyle.androidapp.elepay.view

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageButton
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.material.textfield.TextInputLayout
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.CreditCardInfo
import jp.elestyle.androidapp.elepay.utils.creditcard.CardIssuer
import jp.elestyle.androidapp.elepay.utils.locale.Localization

internal interface CreditCardEditorActionListener {
    fun onCreditCardIssuerChanged(newIssuer: CardIssuer)
    fun onCreditCardInputFocusChanged(focusedWidget: CreditCardEditorWidget.InputEditorIdentity)
    fun onInputCreditCardInformation(target: CreditCardEditorWidget.InputEditorIdentity, digit: Int)
    fun onValidateCreditCardNumber(numberString: String, cardIssuer: CardIssuer): Boolean
    fun onValidateExpirationDate(month: Int, year: Int): Boolean
    fun onScanCardNumber()
}

internal class CreditCardEditorWidget : ConstraintLayout {

    // Hold layout instance to show error message.
    private lateinit var numberEditorLayout: TextInputLayout
    private lateinit var expirationDateEditorLayout: TextInputLayout
    private lateinit var cvcEditorLayout: TextInputLayout
    private lateinit var numberEditor: CreditCardNumberEditText
    private lateinit var expirationDateEditor: ExpiryDateEditText
    private lateinit var cvcEditor: CreditCardCvcEditText
    private lateinit var numberScanButton: ImageButton

    private var isViewCreated = false
    private var cardIssuer: CardIssuer = CardIssuer.Unknown

    var actionListener: CreditCardEditorActionListener? = null

    enum class InputEditorIdentity {
        CARD_NUMBER, EXPIRY_DATE, CVC
    }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : this(
        context,
        attrs,
        defStyleAttr,
        0
    )

    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(
        context, attrs, defStyleAttr, defStyleRes
    )


    override fun onFinishInflate() {
        super.onFinishInflate()

        numberEditorLayout = findViewById(R.id.creditCardNumberEditorLayout)
        numberEditorLayout.hint = Localization.string(R.string.credit_card_card_number_prompt_text)
        numberEditor = findViewById<CreditCardNumberEditText>(R.id.creditCardNumberEditor).apply {
            setOnFocusChangeListener { editor, hasFocus ->
                handleNumberEditorFocusChanges(editor as EditText, hasFocus)
            }
            stateListener = object : CreditCardNumberEditText.StateListener {
                override fun onCreditCardIssuerChanged(issuer: CardIssuer) {
                    handleCardIssuerChanging(issuer)
                }

                override fun onEditCreditCardNumber(digit: Int) {
                    actionListener?.onInputCreditCardInformation(
                        InputEditorIdentity.CARD_NUMBER,
                        digit
                    )
                }

                override fun onCreditCardNumberFinishedEditing(
                    cardNumber: String,
                    extraInput: String
                ) {
                    processCardNumberInput(cardNumber, extraInput)
                }

                override fun onClearCreditCardNumberErrors() {
                    clearErrors(InputEditorIdentity.CARD_NUMBER)
                }
            }
        }
        numberScanButton = findViewById<ImageButton>(R.id.creditCardNumberScanButton).apply {
            setOnClickListener {
                actionListener?.onScanCardNumber()
            }
        }

        expirationDateEditorLayout = findViewById(R.id.creditCardExpirationDateEditorLayout)
        expirationDateEditorLayout.hint =
            Localization.string(R.string.credit_card_expiration_date_prompt_text)
        expirationDateEditor =
            findViewById<ExpiryDateEditText>(R.id.creditCardExpirationDateEditor).apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    setAutofillHints(AUTOFILL_HINT_CREDIT_CARD_EXPIRATION_DATE)
                }

                setOnFocusChangeListener { editor, hasFocus ->
                    handleExpiryDateEditorFocusChange(editor as EditText, hasFocus)
                }

                stateListener = object : ExpiryDateEditText.StateListener {
                    override fun onCreditCardExpiryDateCleanedUp() {
                        moveCursorTo(numberEditor)
                    }

                    override fun onEditCreditCardExpiryDate(digit: Int) {
                        actionListener?.onInputCreditCardInformation(
                            InputEditorIdentity.EXPIRY_DATE,
                            digit
                        )
                    }

                    override fun onCreditCardExpiryDateFinishedEditing(
                        month: Int,
                        year: Int,
                        extraInput: String
                    ) {
                        processExpiryDateInput(month, year, extraInput)
                    }

                    override fun onClearCreditCardExpiryDateErrors() {
                        clearErrors(InputEditorIdentity.EXPIRY_DATE)
                    }
                }
            }
        cvcEditorLayout = findViewById(R.id.creditCardExpirationCvcEditorLayout)
        cvcEditor = findViewById<CreditCardCvcEditText>(R.id.creditCardCvcEditor).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setAutofillHints(AUTOFILL_HINT_CREDIT_CARD_SECURITY_CODE)
            }

            setOnFocusChangeListener { editor, hasFocus ->
                handleCvcEditorFocusChanges(editor as EditText, hasFocus)
            }
            stateListener = object : CreditCardCvcEditText.StateListener {
                override fun onCreditCardCvcCleanedUp() {
                    moveCursorTo(expirationDateEditor)
                }

                override fun onEditCreditCardCvc(digit: Int) {
                    actionListener?.onInputCreditCardInformation(InputEditorIdentity.CVC, digit)
                }

                override fun onCreditCardCvcFinishedEditing(cvc: String) {
                    val inputManager =
                        cvcEditor.context.getSystemService(Context.INPUT_METHOD_SERVICE)
                                as InputMethodManager
                    inputManager.hideSoftInputFromWindow(cvcEditor.windowToken, 0)
                }

                override fun onClearCreditCardCvcErrors() {
                    clearErrors(InputEditorIdentity.CVC)
                }
            }
        }

        isViewCreated = true
    }

    val collectedCardInfo: CreditCardInfo?
        get() {
            if (!isViewCreated) return null

            val expirationDate = expirationDateEditor.date ?: return null

            val number = numberEditor.text.toString()
            val cvc = cvcEditor.text.toString()
            return CreditCardInfo(number, expirationDate.month, expirationDate.year, cvc)
        }

    var numberScanButtonVisibility: Int
        get() = numberScanButton.visibility
        set(value) {
            numberScanButton.visibility = value
        }

    @SuppressLint("SetTextI18n")
    fun showCreditCard(cardInfo: CreditCardInfo) {
        if (cardInfo.number.isNotEmpty()) {
            numberEditor.setText(cardInfo.number)
        }

        if (cardInfo.month in 1..12 && cardInfo.year != 0) {
            expirationDateEditor.setText("${cardInfo.month}${cardInfo.year}")
        }

        if (cardInfo.cvc.isNotEmpty()) {
            cvcEditor.setText(cardInfo.cvc)
        }
    }

    fun clearInputs() {
        numberEditor.setText("")
        expirationDateEditor.setText("")
        cvcEditor.setText("")
    }

    fun showErrorMessage(message: String, target: InputEditorIdentity) {
        val textLayout = when (target) {
            InputEditorIdentity.CARD_NUMBER -> numberEditorLayout
            InputEditorIdentity.EXPIRY_DATE -> expirationDateEditorLayout
            InputEditorIdentity.CVC -> cvcEditorLayout
        }
        textLayout.error = message
    }

    fun moveCursor(target: InputEditorIdentity) {
        val editor = when (target) {
            InputEditorIdentity.CARD_NUMBER -> numberEditor
            InputEditorIdentity.EXPIRY_DATE -> expirationDateEditor
            InputEditorIdentity.CVC -> cvcEditor
        }
        moveCursorTo(editor)
    }

    private fun clearErrors(target: InputEditorIdentity) {
        val textLayout = when (target) {
            InputEditorIdentity.CARD_NUMBER -> numberEditorLayout
            InputEditorIdentity.EXPIRY_DATE -> expirationDateEditorLayout
            InputEditorIdentity.CVC -> cvcEditorLayout
        }
        textLayout.error = null
        // Do this after setError(null),
        // to make sure the error message view is removed from view hierarchy.
        textLayout.isErrorEnabled = false
    }

    private fun handleNumberEditorFocusChanges(editor: EditText, hasFocus: Boolean) {
        if (hasFocus) {
            editor.setHint(R.string.credit_card_number_editor_hint)
            actionListener?.onCreditCardInputFocusChanged(InputEditorIdentity.CARD_NUMBER)
        } else {
            editor.hint = ""
        }
    }

    private fun handleCardIssuerChanging(newIssuer: CardIssuer) {
        cardIssuer = newIssuer

        cvcEditor.updateMaxLength(newIssuer.cvcLength)

        actionListener?.onCreditCardIssuerChanged(newIssuer)
    }

    private fun processCardNumberInput(cardNumber: String, extraInput: String) {
        val isValidNumber = actionListener?.onValidateCreditCardNumber(cardNumber, cardIssuer)
            ?: true
        if (!isValidNumber) {
            // No further processing when the number is invalid.
            return
        }

        // We can move the date editor when:
        //  * the `extraInput` is empty
        //  * if the `extraInput` is not empty, need to make sure the date editor has no data currenlty
        val isDateEditorFocusable =
            extraInput.isEmpty() || expirationDateEditor.text?.isEmpty() ?: true
        if (isDateEditorFocusable) {
            moveCursorTo(expirationDateEditor)
            if (extraInput.isNotEmpty()) {
                handler.post {
                    // This will trigger the editor's input format mechanism,
                    // which is exactly what I expected.
                    expirationDateEditor.acceptInput(extraInput)
                }
            }
        }
    }

    private fun handleExpiryDateEditorFocusChange(editor: EditText, hasFocus: Boolean) {
        if (hasFocus) {
            editor.setHint(R.string.credit_card_expr_date_editor_hint)
            actionListener?.onCreditCardInputFocusChanged(InputEditorIdentity.EXPIRY_DATE)
        } else {
            editor.hint = ""
        }
    }

    private fun processExpiryDateInput(month: Int, year: Int, extraInput: String) {
        val isValidDate = actionListener?.onValidateExpirationDate(month, year) ?: true
        if (!isValidDate) {
            // No further processing when the number is invalid.
            return
        }

        val isCvcEditorEmpty = extraInput.isEmpty() || cvcEditor.text?.isEmpty() ?: true
        if (isCvcEditorEmpty) {
            moveCursorTo(cvcEditor)
            if (extraInput.isNotEmpty()) {
                handler.post { cvcEditor.acceptInput(extraInput) }
            }
        }
    }

    private fun handleCvcEditorFocusChanges(editor: EditText, hasFocus: Boolean) {
        if (hasFocus) {
            editor.setHint(R.string.credit_card_cvc_editor_hint)
            actionListener?.onCreditCardInputFocusChanged(InputEditorIdentity.CVC)
        } else {
            editor.hint = ""
        }
    }

    private fun moveCursorTo(editor: EditText) {
        editor.requestFocus()
    }
}