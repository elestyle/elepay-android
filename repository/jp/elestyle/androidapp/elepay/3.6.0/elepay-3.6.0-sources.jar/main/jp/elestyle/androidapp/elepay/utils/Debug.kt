package jp.elestyle.androidapp.elepay.utils

import android.util.Log
import jp.elestyle.androidapp.elepay.BuildConfig

internal enum class LogLevel {
    DEBUG, INFO, ERROR
}

internal fun log(
    tag: String,
    message: String,
    logLevel: LogLevel = LogLevel.DEBUG,
    printsStackTrace: Boolean = false
) {
    if (!BuildConfig.DEBUG && logLevel != LogLevel.ERROR) {
        return
    }

    val stackTraceExp = if (printsStackTrace) Exception() else null
    val logger: (String, String, Throwable?) -> Int = when (logLevel) {
        LogLevel.DEBUG -> Log::d
        LogLevel.INFO -> Log::i
        LogLevel.ERROR -> Log::e
    }
    logger(tag, message, stackTraceExp)
}