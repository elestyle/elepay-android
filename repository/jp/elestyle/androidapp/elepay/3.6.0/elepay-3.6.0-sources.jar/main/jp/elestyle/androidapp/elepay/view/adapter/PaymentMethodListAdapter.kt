package jp.elestyle.androidapp.elepay.view.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.checkout.PaymentMethodItem

internal class PaymentMethodListViewHolder(container: View) : RecyclerView.ViewHolder(container) {
    val logoImage: ImageView = container.findViewById(R.id.paymentMethodBrandLogo)
    val title: TextView = container.findViewById(R.id.paymentMethodBrandName)
    val extraLogoRight: ImageView = container.findViewById(R.id.paymentMethodExtraBrandLogoRight)
    val checkmark: ImageView = container.findViewById(R.id.paymentMethodItemCheckmark)
}

internal class PaymentMethodListAdapter(
    private val list: List<PaymentMethodItem>,
    private val selectedIndex: Int,
    private val itemClickHandler: (PaymentMethodItem) -> Unit
) : RecyclerView.Adapter<PaymentMethodListViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PaymentMethodListViewHolder =
        PaymentMethodListViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.payment_method_item, parent, false)
        )

    override fun getItemCount(): Int = list.count()

    override fun onBindViewHolder(holder: PaymentMethodListViewHolder, position: Int) {
        val itemData = list[position]

        Glide
            .with(holder.logoImage.context)
            .load(itemData.brand.logoUrl)
            .placeholder(R.drawable.ic_pm_logo_placeholder)
            .into(holder.logoImage)

        holder.title.text = itemData.brand.name
        val extraRightBrand = itemData.associatedBrands.find { it.id == "alipayplus" }
        if (extraRightBrand != null) {
            holder.extraLogoRight.visibility = View.VISIBLE
            Glide
                .with(holder.logoImage.context)
                .load(extraRightBrand.logoUrl)
                .into(holder.extraLogoRight)
        } else {
            holder.extraLogoRight.visibility = View.INVISIBLE
        }
        holder.checkmark.visibility =
            if (position == selectedIndex) View.VISIBLE else View.INVISIBLE
        holder.itemView.setOnClickListener {
            itemClickHandler(itemData)
        }
    }
}