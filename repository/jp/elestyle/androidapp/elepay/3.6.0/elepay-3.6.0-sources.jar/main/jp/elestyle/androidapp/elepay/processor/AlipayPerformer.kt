package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import com.alipay.sdk.app.PayTask
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.IntegrationChecker
import jp.elestyle.androidapp.elepay.utils.log

internal object AlipayPerformer {
    fun pay(
        paymentId: String,
        payload: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (!IntegrationChecker.isAlipayAvailable()) {
            val failure = ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.UninitializedPaymentMethod(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        null,
                        null,
                        ErrorCode.UNINIT
                    ),
                    paymentMethod = PaymentMethod.ALIPAY.rawValue,
                    message = "Have you installed Alipay sdk to your project?"
                )
            )
            resultHandler?.invoke(failure)
            return false
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
        }

        val payRunnable = Runnable {
            val alipay = PayTask(fromActivity)
            val result = alipay.payV2(payload, true)
            log("AlipayPerformer", result.toString())

            AlipayResultHelper.parseAlipayResult(rawResult = result).apply {
                // 判断resultStatus 为9000则代表支付成功
                when (status) {
                    "9000" -> {
                        ElepayResultHandlerManager.notifyResult(
                            result = ElepayResult.Succeeded(paymentId),
                            paymentId = paymentId
                        )
                    }
                    "6001" -> {
                        ElepayResultHandlerManager.notifyResult(
                            result = ElepayResult.Canceled(paymentId),
                            paymentId = paymentId
                        )
                    }
                    else -> {
                        val error = ElepayError.PaymentFailure(
                            errorCode = ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                PaymentMethodProvider.ALIPAY,
                                PaymentMethod.ALIPAY,
                                ErrorCode.FAILED
                            ),
                            message = "Alipay failed. status=$status memo=$memo result=$result"
                        )
                        ElepayResultHandlerManager.notifyResult(
                            result = ElepayResult.Failed(
                                paymentId,
                                error
                            ),
                            paymentId = paymentId
                        )
                    }
                }
            }
        }

        Thread(payRunnable).start()
        return true
    }
}