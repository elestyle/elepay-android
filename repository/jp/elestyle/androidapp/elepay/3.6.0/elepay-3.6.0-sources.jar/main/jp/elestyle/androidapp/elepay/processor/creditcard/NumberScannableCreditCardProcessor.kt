package jp.elestyle.androidapp.elepay.processor.creditcard

import androidx.activity.ComponentActivity
import jp.elestyle.androidapp.elepay.data.CreditCardInfo

internal interface NumberScannableCreditCardProcessor : ActivityAwarenessCreditCardProcessor {
    suspend fun scanCreditCard(hostActivity: ComponentActivity): CreditCardInfo?
}