package jp.elestyle.androidapp.elepay.utils.extensions

import android.content.res.Configuration

val Configuration.isDarkMode: Boolean
    get() = uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES