package jp.elestyle.androidapp.elepay.activity.checkout

import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.Keep
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.commit
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.checkout.CheckoutProduct
import jp.elestyle.androidapp.elepay.data.checkout.PaymentMethodItem
import jp.elestyle.androidapp.elepay.fragment.checkout.CheckoutFragment
import jp.elestyle.androidapp.elepay.fragment.checkout.PaymentMethodListFragment
import jp.elestyle.androidapp.elepay.fragment.checkout.ProductListFragment
import jp.elestyle.androidapp.elepay.utils.CheckoutDataSource
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.extensions.checkAndApplyElepayTheme
import jp.elestyle.androidapp.elepay.utils.locale.Localization
import jp.elestyle.androidapp.elepay.utils.log

private class FragmentTransitionAnim(
    val newFgInAnimRes: Int,
    val newFgOutAnimRes: Int,
    val oldFgInAnimRes: Int,
    val oldFgOutAnimRes: Int
)

@Keep
internal class CheckoutActivity : AppCompatActivity(),
    CheckoutFragment.ActionListener,
    PaymentMethodListFragment.ActionListener {

    private val logTag = CheckoutActivity::class.java.simpleName
    private val checkoutFgTag = "checkout.checkout_fg"
    private var checkoutJsonStr = ""
    private var resultHandlerId = ""
    private var isProcessingCheckout = false
    private var dialog: AlertDialog? = null
    private var doubleBackToExitPressedOnce = false
    private val backPressedCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (isProcessingCheckout) {
                log(logTag, "block back press while checkout is in processing.")

                // tab one more time to cancel the payment.
                if (doubleBackToExitPressedOnce) {
                    isProcessingCheckout = false
                    notifyElepayResult(ElepayResult.Canceled(paymentId = resultHandlerId))
                    return
                }

                doubleBackToExitPressedOnce = true
                Toast.makeText(this@CheckoutActivity, Localization.string(R.string.msgPressAgainToCancelCheckout), Toast.LENGTH_SHORT).show()

                Handler(Looper.getMainLooper()).postDelayed({
                    doubleBackToExitPressedOnce = false
                }, 2000)
                return
            }

            notifyElepayResult(ElepayResult.Canceled(paymentId = resultHandlerId))
        }
    }

    enum class IntentKey {
        CHECKOUT_JSON, RESULT_HANDLER_ID
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        checkAndApplyElepayTheme(ConfigManager.theme)

        super.onCreate(savedInstanceState)

        setContentView(R.layout.checkout_activity)

        onBackPressedDispatcher.addCallback(this, backPressedCallback)

        checkoutJsonStr = retrieveCheckoutJson() ?: run {
            finishDueToError("onCreate(): no code in intent")
            return
        }
        resultHandlerId = retrieveResultHandlerId() ?: run {
            finishDueToError("onCreate(): no result_handler_id in intent")
            return
        }

        Localization.setup(this, ConfigManager.languageKey)

        // Cancel payment when tapping the area outside the main fragment.
        findViewById<View>(R.id.checkoutActivityEmptyArea).setOnClickListener {
            if (isProcessingCheckout) {
                return@setOnClickListener
            }

            notifyElepayResult(ElepayResult.Canceled(paymentId = resultHandlerId))
        }

        supportFragmentManager.addOnBackStackChangedListener {
            backPressedCallback.isEnabled = supportFragmentManager.backStackEntryCount <= 1
        }
    }

    override fun onResume() {
        super.onResume()

        if (supportFragmentManager.findFragmentByTag(checkoutFgTag) != null) return

        val checkoutFg = CheckoutFragment.newInstance(checkoutJsonStr).apply {
            actionListener = this@CheckoutActivity
        }
        val transition = FragmentTransitionAnim(
            newFgInAnimRes = R.anim.push_bottom_in,
            newFgOutAnimRes = R.anim.pop_bottom_out,
            oldFgInAnimRes = 0,
            oldFgOutAnimRes = 0
        )
        showFragment(checkoutFg, checkoutFgTag, transition)
    }

    override fun onDestroy() {
        super.onDestroy()

        Localization.cleanup()

        dialog?.dismiss()
        dialog = null

        CheckoutDataSource.cleanup()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        val attachedFgs = supportFragmentManager.fragments
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            attachedFgs.forEach {
                supportFragmentManager.beginTransaction().detach(it).commitNow()
                supportFragmentManager.beginTransaction().attach(it).commitNow()
            }
        } else {
            val transaction = supportFragmentManager.beginTransaction()
            attachedFgs.forEach {
                transaction.detach(it)
                transaction.attach(it)
            }
            transaction.commit()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return super.onSupportNavigateUp()
    }

    override fun onCheckoutStart() {
        isProcessingCheckout = true
        backPressedCallback.isEnabled = true
    }

    override fun onCheckoutFinish(elepayResult: ElepayResult) {
        isProcessingCheckout = false
        backPressedCallback.isEnabled = supportFragmentManager.backStackEntryCount <= 1

        val intercepted = when (elepayResult) {
            // Canceled result from elepay is ignored, should let user determine what to do
            // next. We only notify cancel when user tapped the cancel button or the empty area.
            is ElepayResult.Canceled -> true

            is ElepayResult.Failed -> interceptElepayError(elepayResult.error)

            else -> false
        }

        if (!intercepted) {
            notifyElepayResult(elepayResult)
        }
    }

    override fun onCheckoutCanceled() {
        notifyElepayResult(ElepayResult.Canceled(paymentId = resultHandlerId))
    }

    override fun onTapPaymentMethod(paymentMethod: PaymentMethod) {
        val paymentMethodListFg = PaymentMethodListFragment.newInstance(paymentMethod)
        paymentMethodListFg.actionListener = this
        val transition = FragmentTransitionAnim(
            newFgInAnimRes = R.anim.push,
            newFgOutAnimRes = R.anim.pop,
            oldFgInAnimRes = 0,
            oldFgOutAnimRes = 0
        )
        showFragment(paymentMethodListFg, "checkout.payment_method_list_fg", transition)
    }

    override fun onTapProductList(products: List<CheckoutProduct>, currencySymbol: String) {
        val productsFg = ProductListFragment.newInstance(products, currencySymbol)
        val transition = FragmentTransitionAnim(
            newFgInAnimRes = R.anim.push,
            newFgOutAnimRes = R.anim.pop,
            oldFgInAnimRes = 0,
            oldFgOutAnimRes = 0
        )
        showFragment(productsFg, "checkout.product_list_fg", transition)
    }

    override fun onSelectPaymentMethod(paymentMethodItem: PaymentMethodItem) {
        val checkoutFg =
            supportFragmentManager.findFragmentByTag(checkoutFgTag) as? CheckoutFragment
        checkoutFg?.setPaymentMethod(paymentMethodItem)

        if (checkoutFg != null) {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun showFragment(fg: Fragment, tag: String, transitionAnim: FragmentTransitionAnim?) {
        supportFragmentManager.commit {
            if (transitionAnim != null) {
                setCustomAnimations(
                    transitionAnim.newFgInAnimRes,
                    transitionAnim.oldFgOutAnimRes,
                    transitionAnim.oldFgInAnimRes,
                    transitionAnim.newFgOutAnimRes
                )
            }

            add(R.id.checkoutActivityFragmentContainer, fg, tag)
            addToBackStack(tag)
        }
    }

    private fun showMessageDialog(message: String) {
        if (dialog != null) {
            dialog!!.dismiss()
        }

        dialog = AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton(R.string.button_title_ok) { _, _ -> }
            .create()
        dialog!!.show()
    }

    private fun retrieveCheckoutJson(): String? =
        intent?.extras?.getString(IntentKey.CHECKOUT_JSON.name)

    private fun retrieveResultHandlerId(): String? =
        intent?.extras?.getString(IntentKey.RESULT_HANDLER_ID.name)?.ifEmpty { null }

    private fun interceptElepayError(error: ElepayError): Boolean =
        when (error) {
            is ElepayError.PaymentFailure -> {
                when (error.errorCode) {
                    ErrorCode.APP_NOT_INSTALLED.raw -> {
                        showMessageDialog(Localization.string(R.string.msgPaymentAppNotInstalled))
                        true
                    }

                    ErrorCode.DEVICE_NOT_SUPPORTED.raw -> {
                        showMessageDialog(Localization.string(R.string.msgPaymentDeviceNotSupported))
                        true
                    }

                    else -> false
                }
            }

            else -> false
        }


    private fun notifyElepayResult(result: ElepayResult) {
        if (supportFragmentManager.backStackEntryCount <= 1) {
            supportFragmentManager.popBackStackImmediate(
                checkoutFgTag,
                FragmentManager.POP_BACK_STACK_INCLUSIVE
            )
        }

        // Wait until the final fragment's exit animation is done.
        val delay = resources.getInteger(R.integer.default_transition_duration) + 10
        android.os.Handler(Looper.getMainLooper()).postDelayed({
            ElepayResultHandlerManager.notifyResult(result, resultHandlerId)
            finish()
        }, delay.toLong())
    }

    private fun finishDueToError(logMsg: String) {
        log(logTag, logMsg)
        finish()
    }
}