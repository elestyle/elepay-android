package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.internal.ElepayWebProcessorActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator

internal object DocomoPayProcessor : ElepayProcessor {
    override val isWellConfigured: Boolean = true

    override fun setup(providerConfig: ElepayProviderConfig) {
        // Nothing to config
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else when (chargeData.method) {
            PaymentMethod.DOCOMO_PAY ->
                processPaymentData(chargeData, fromActivity, resultHandler)

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = chargeData.id,
                        error = ElepayError.UnsupportedPaymentMethod(chargeData.method.rawValue)
                    )
                )
                false
            }
        }

    private fun processPaymentData(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val paymentUrl = chargeData.redirectUrl ?: run {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    chargeData.id,
                    ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.DOCOMO_PAY,
                            PaymentMethod.DOCOMO_PAY,
                            ErrorCode.INVALID_AUTH_URL
                        ),
                        "No available url for processing."
                    )
                )
            )
            return false
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, chargeData.id)
        }
        val intent = Intent(fromActivity, ElepayWebProcessorActivity::class.java).apply {
            putExtra(
                ElepayWebProcessorActivity.IntentExtraKey.PAYMENT_DATA.rawValue,
                chargeData.paymentCommon
            )
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.TARGET_URL.rawValue, paymentUrl)
        }
        fromActivity.startActivity(intent)
        return true
    }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(sourceData.paymentCommon, fromActivity, resultHandler)) true
        else when (sourceData.method) {
            PaymentMethod.DOCOMO_PAY ->
                processSourceData(sourceData, fromActivity, resultHandler)

            else -> {
                val failure = ElepayResult.Failed(
                    paymentId = sourceData.id,
                    error = ElepayError.UnsupportedPaymentMethod(sourceData.method.rawValue)
                )
                resultHandler?.invoke(failure)
                false
            }
        }

    private fun processSourceData(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val paymentUrl = sourceData.redirectUrl ?: run {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    sourceData.id,
                    ElepayError.InvalidPayload(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.DOCOMO_PAY,
                            PaymentMethod.DOCOMO_PAY,
                            ErrorCode.INVALID_AUTH_URL
                        ),
                        "No available url for processing."
                    )
                )
            )
            return false
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, sourceData.id)
        }
        val intent = Intent(fromActivity, ElepayWebProcessorActivity::class.java).apply {
            putExtra(
                ElepayWebProcessorActivity.IntentExtraKey.PAYMENT_DATA.rawValue,
                sourceData.paymentCommon
            )
            putExtra(ElepayWebProcessorActivity.IntentExtraKey.TARGET_URL.rawValue, paymentUrl)
        }
        fromActivity.startActivity(intent)
        return true
    }
}