package jp.elestyle.androidapp.elepay.utils

import android.app.Activity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.android.gms.wallet.IsReadyToPayRequest
import com.google.android.gms.wallet.Wallet
import jp.elestyle.androidapp.elepay.asWalletConstantsValue
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

internal object GooglePayHelper {
    // Hold the parsing callbacks temporarily. When the parsing callback is retrieved, it removed from this map.
    private val oneTimeTokenParsers: MutableMap<String, (String) -> String> = mutableMapOf()

    /**
     * Temporarily store the given parser.
     * Parser is supposed to take a raw string token that Google Pay generated, and returns a translated string value
     * as the final token to be processed by elepay server.
     */
    fun storeGatewayTokenParser(parser: (String) -> String, key: String) {
        synchronized(this) {
            oneTimeTokenParsers[key] = parser
        }
    }

    /**
     * Retrieve the previously stored parser, the parser will be removed from the local storage.
     */
    fun retrieveGatewayTokenParser(key: String): ((String) -> String)? =
        synchronized(this) {
            val ret = oneTimeTokenParsers[key]
            oneTimeTokenParsers.remove(key)
            return ret
        }

    /**
     * Create basic common used JSON object for Google Pay.
     */
    fun generateBaseGooglePayParameter(): JSONObject =
        JSONObject()
            .put("apiVersion", 2)
            .put("apiVersionMinor", 0)

    /**
     * Create a basic JSON object structure for Google Pay's card parameter.
     */
    fun generateCardParameters(): JSONObject {
        val allowedCardAuthMethods = JSONArray()
            .put("PAN_ONLY")
            .put("CRYPTOGRAM_3DS")
        val allowedCardNetworks = JSONArray()
            .put("AMEX")
            .put("DISCOVER")
            .put("JCB")
            .put("MASTERCARD")
            .put("VISA")
        return JSONObject()
            .put("type", "CARD")
            .put(
                "parameters",
                JSONObject()
                    .put("allowedAuthMethods", allowedCardAuthMethods)
                    .put("allowedCardNetworks", allowedCardNetworks)
            )
    }

    /**
     * Check if Google Pay is ready to use.
     *
     * The check will not performed if ElepayConfiguration.googlePayEnvironment is not set.
     */
    suspend fun isGooglePayReadyToUse(activity: Activity): Boolean {
        val env = ConfigManager.googlePayEnvironment ?: return false

        val requestParams = generateBaseGooglePayParameter()
            .put("allowedPaymentMethods", JSONArray().put(generateCardParameters()))
            .put("existingPaymentMethodRequired", ConfigManager.googlePayExistingPaymentRequired)
        val request = IsReadyToPayRequest.fromJson(requestParams.toString())

        val options = Wallet.WalletOptions.Builder()
            .setEnvironment(env.asWalletConstantsValue())
            .build()

        return Wallet
            .getPaymentsClient(activity, options)
            .isReadyToPay(request)
            .executeWithCoroutine()
    }
}

/**
 * A coroutine wrapper for the Google Wallet callback API.
 */
private suspend fun Task<Boolean>.executeWithCoroutine(): Boolean {
    return suspendCoroutine { cont ->
        val completionListener = OnCompleteListener<Boolean> { task ->
            log("GooglePayHelper", "task state of checking is-ready-to-use: ${task.isSuccessful}")
            if (task.isSuccessful) {
                val res = task.result ?: false
                cont.resume(res)
            } else {
                cont.resume(false)
            }
        }
        addOnCompleteListener(completionListener)
    }
}