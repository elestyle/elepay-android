package jp.elestyle.androidapp.elepay.data.checkout

import android.os.Build
import android.os.Parcel
import android.os.Parcelable
import jp.elestyle.androidapp.elepay.utils.symbolizeCurrency

internal data class CheckoutData(
    val codeId: String,
    val orderId: String,
    val amount: String,
    val currency: String,
    val expiryDuration: Long,
    val products: List<CheckoutProduct>?,
    val payload: CheckoutPayload
) : Parcelable {
    val amountFormattedWithCurrency: String get() = symbolizeCurrency(currency) + amount

    constructor(parcel: Parcel) : this(
        codeId = parcel.readString() ?: "",
        orderId = parcel.readString() ?: "",
        amount = parcel.readString() ?: "",
        currency = parcel.readString() ?: "",
        expiryDuration = parcel.readLong(),
        products = mutableListOf<CheckoutProduct>().let {
            parcel.readTypedList(it, CheckoutProduct)
            return@let it
        },
        payload = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            parcel.readParcelable(
                CheckoutPayload::class.java.classLoader,
                CheckoutPayload::class.java
            )!!
        } else {
            @Suppress("DEPRECATION")
            parcel.readParcelable<CheckoutPayload>(CheckoutPayload::class.java.classLoader)!!
        }
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(codeId)
        dest.writeString(orderId)
        dest.writeString(amount)
        dest.writeString(currency)
        dest.writeLong(expiryDuration)
        dest.writeTypedList(products)
        dest.writeParcelable(payload, 0)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<CheckoutData> {
        override fun createFromParcel(source: Parcel): CheckoutData = CheckoutData(source)

        override fun newArray(size: Int): Array<CheckoutData?> = arrayOfNulls(size)
    }
}

internal data class CheckoutPayload(
    val appId: String,
    val pKey: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        appId = parcel.readString() ?: "",
        pKey = parcel.readString() ?: ""
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(appId)
        dest.writeString(pKey)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<CheckoutPayload> {
        override fun createFromParcel(source: Parcel): CheckoutPayload = CheckoutPayload(source)

        override fun newArray(size: Int): Array<CheckoutPayload?> = arrayOfNulls(size)
    }
}