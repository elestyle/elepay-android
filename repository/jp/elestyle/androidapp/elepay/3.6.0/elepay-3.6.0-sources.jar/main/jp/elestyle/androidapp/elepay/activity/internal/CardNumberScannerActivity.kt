package jp.elestyle.androidapp.elepay.activity.internal

import android.content.Intent
import android.graphics.Outline
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.view.doOnLayout
import androidx.lifecycle.Lifecycle
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.CreditCardInfo
import jp.elestyle.androidapp.elepay.databinding.CardNumberScannerActivityBinding
import jp.elestyle.androidapp.elepay.utils.PermissionChecker
import jp.elestyle.androidapp.elepay.utils.asBitmapWithYuv420888Format
import jp.elestyle.androidapp.elepay.utils.creditcard.CardIssuer
import jp.elestyle.androidapp.elepay.utils.creditcard.CreditCardValidator
import jp.elestyle.androidapp.elepay.utils.log
import jp.elestyle.androidapp.elepay.utils.transform
import java.util.Calendar
import java.util.concurrent.Executors
import kotlin.math.min

internal class CardNumberScannerActivity : AppCompatActivity() {
    private val logTag = CardNumberScannerActivity::class.java.simpleName

    private lateinit var viewBinding: CardNumberScannerActivityBinding

    private val permissionRequestLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startCamera()
            } else {
                showPermissionDeniedDialog()
            }
        }
    private var isCameraStarted = false
    private var analyzer: CardNumberAnalyzer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewBinding = CardNumberScannerActivityBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.root.apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                windowInsetsController?.apply {
                    systemBarsBehavior =
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    hide(WindowInsets.Type.statusBars())
                }
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            }

            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height + 16, 16.0f)
                }
            }
            clipToOutline = true
        }

        viewBinding.cardNumberScannerCameraPreviewContainer.doOnLayout {
            analyzer?.updateCropInfo(
                CardNumberAnalyzer.CropInfo(
                    targetWidthHeightRatio = it.width.toFloat() / it.height.toFloat(),
                    cardWidthRatio = it.width.toFloat() / viewBinding.root.width.toFloat()
                )
            )
        }

        analyzer = CardNumberAnalyzer(lifecycle = lifecycle) { card ->
            if (card != null) {
                stopCamera()
                notifyResult(card)
            }
        }
    }

    override fun onStart() {
        super.onStart()

        if (PermissionChecker.isPermissionGranted(this, android.Manifest.permission.CAMERA)) {
            startCamera()
        } else {
            permissionRequestLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    override fun onStop() {
        super.onStop()

        stopCamera()
    }

    private fun startCamera() {
        if (isCameraStarted) {
            return
        }

        val context = this@CardNumberScannerActivity
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            val provider = providerFuture.get()

            val cameraSelector = listOf(
                CameraSelector.DEFAULT_BACK_CAMERA,
                CameraSelector.DEFAULT_FRONT_CAMERA
            ).firstOrNull { provider.hasCamera(it) } ?: run {
                Log.e(logTag, "startCamera(): neither FRONT nor BACK camera is available")
                return@addListener
            }

            val preview = Preview.Builder().build()
                .apply {
                    setSurfaceProvider(viewBinding.cardNumberScannerCameraPreview.surfaceProvider)
                }
            val imageAnalysis = buildImageAnalysis()

            provider.unbindAll()

            provider.bindToLifecycle(
                context,
                cameraSelector,
                preview,
                imageAnalysis
            )

            isCameraStarted = true
            analyzer?.isEnabled = true
        }, ContextCompat.getMainExecutor(context))
    }

    private fun buildImageAnalysis(): ImageAnalysis {
        return ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .apply {
                setAnalyzer(Executors.newSingleThreadExecutor(), analyzer!!)
            }
    }

    private fun stopCamera() {
        isCameraStarted = false
        analyzer?.isEnabled = false
        analyzer = null
    }

    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setMessage(R.string.msgCameraPermissionDenied)
            .setPositiveButton(R.string.elepay_text_settings) { _, _ ->
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                }
                startActivity(intent)
            }
            .setNegativeButton(R.string.elepay_text_cancel) { _, _ -> }
            .create()
            .show()
    }

    private fun notifyResult(cardInfo: CreditCardInfo) {
        val data = Intent().apply {
            putExtra(scanningResultKey, CreditCardScannerResult.Completed(cardInfo))
        }
        setResult(RESULT_OK, data)
        finish()
    }

    companion object {
        const val scanningResultKey = "result"
    }
}

private class CardNumberAnalyzer(
    lifecycle: Lifecycle,
    private val resultProcessor: (CreditCardInfo?) -> Unit
) : ImageAnalysis.Analyzer {
    private val recognizer = TextRecognition.getClient(
        TextRecognizerOptions.Builder().setExecutor(Executors.newSingleThreadExecutor()).build()
    )
    private val lock = Object()
    private var cropInfo: CropInfo? = null
    private var _isEnabled = false
    private var isAnalyzing = false
    private var detectedNumbersCache = mutableMapOf<String, Int>()
    private var detectedDatesCache = mutableMapOf<String, Int>()

    /**
     * NOTE: all the information specified here is based on the assumption that we're cropping
     * a card frame from a portrait orientation, like:
     * |---------------|
     * |               |
     * |               |
     * |  |---------|  |
     * |  |         |  |
     * |  |---------|  |
     * |               |
     * |               |
     * |---------------|
     */
    data class CropInfo(
        /** The crop frame's w/h ratio */
        val targetWidthHeightRatio: Float,
        /** The ratio of crop frame's width to the view's width */
        val cardWidthRatio: Float,
    )

    init {
        lifecycle.addObserver(recognizer)
    }

    var isEnabled: Boolean
        get() = synchronized(lock) { _isEnabled }
        set(value) {
            synchronized(lock) { _isEnabled = value }
        }

    fun updateCropInfo(newInfo: CropInfo) {
        synchronized(lock) {
            cropInfo = newInfo
        }
    }

    @androidx.camera.core.ExperimentalGetImage
    override fun analyze(imageProxy: ImageProxy) {
        val cropInfo = synchronized(lock) {
            return@synchronized if (isAnalyzing || !isEnabled) null else cropInfo
        } ?: return
        val mediaImage = imageProxy.image ?: return

        synchronized(lock) {
            isAnalyzing = true
        }

        val imageHeight = mediaImage.height
        val imageWidth = mediaImage.width
        val rotationDegrees = imageProxy.imageInfo.rotationDegrees

        // Because we're assuming we're always in a portrait orientation, the `cardWidthRatio` is
        // calculated with cardWidth and the container view's shorter edge(its width).
        // Here we find the smaller one and use it to calculate the actual crop frame.
        val smallerDimen = min(imageWidth, imageHeight)
        val idealCropWidth = cropInfo.cardWidthRatio * smallerDimen
        val idealCropHeight = idealCropWidth / cropInfo.targetWidthHeightRatio
        // Swap the calculated ideal w/h when rotated.
        val (finalCropWidth, finalCropHeight) = when (rotationDegrees) {
            90, 270 -> Pair(idealCropHeight, idealCropWidth)
            else -> Pair(idealCropWidth, idealCropHeight)
        }
        val cropRect = Rect(0, 0, imageWidth, imageHeight).apply {
            inset(
                ((imageWidth - finalCropWidth) / 2).toInt(),
                ((imageHeight - finalCropHeight) / 2).toInt()
            )
        }
        val bitmap = mediaImage.asBitmapWithYuv420888Format()

        val croppedBitmap = bitmap.transform(rotationDegrees, cropRect)
        recognizer.process(InputImage.fromBitmap(croppedBitmap, 0))
            .addOnSuccessListener { visionText ->
                val cardInfo = parseCardInfoFromDetectedText(visionText)
                if (cardInfo != null) {
                    clearCache()
                    resultProcessor(cardInfo)
                }
            }
            .addOnFailureListener { exception ->
                Log.e(logTag, "Card recognition error", exception)
            }
            .addOnCompleteListener {
                synchronized(lock) {
                    isAnalyzing = false
                }
                imageProxy.close()
            }
    }

    private fun parseCardInfoFromDetectedText(text: Text): CreditCardInfo? {
        val allNumbers = mutableListOf<String>()
        for (block in text.textBlocks) {
            for (line in block.lines) {
                log(logTag, "in text block line: ${line.text}")
                val purified = line.text.numericCharacters
                if (purified.count() >= 4) {
                    allNumbers.add(purified)
                } else {
                    continue
                }

                val cardIssuerIssuer = parseCardIssuer(fromNumber = purified)
                if (cardIssuerIssuer != null &&
                    CreditCardValidator.validateCardNumber(purified, cardIssuerIssuer)
                ) {
                    cacheDetectedNumber(purified)
                } else if (purified.count() in 4..6) {
                    val matchResult = expirationDateRegex.matchEntire(line.text)
                    if (matchResult != null) {
                        val possibleDate = shortenDate(matchResult) ?: purified
                        val month = runCatching {
                            possibleDate.substring(0 until 2).toInt()
                        }.getOrNull() ?: 0
                        val year = runCatching {
                            possibleDate.substring(2).toInt()
                        }.getOrNull() ?: 0
                        // Ignore expiration dates 10+ years in the future,
                        // as they're likely to be incorrect recognitions.
                        val maxYear = (Calendar.getInstance().get(Calendar.YEAR) % 100) + 10
                        if (CreditCardValidator.validateCardExpirationDate(month, year) &&
                            year < maxYear
                        ) {
                            cacheDetectedDate(possibleDate)
                        }
                    }
                }
            }
        }

        if (allNumbers.count() > 3) {
            for (i in 0 until allNumbers.count() - 3) {
                val potentialAmexNumber = allNumbers.subList(i, i + 3).joinToString(separator = "")
                val cardIssuer = parseCardIssuer(fromNumber = potentialAmexNumber)
                if (cardIssuer != null) {
                    if (CreditCardValidator.validateCardNumber(potentialAmexNumber, cardIssuer)) {
                        cacheDetectedNumber(potentialAmexNumber)
                    } else if (i + 3 < allNumbers.count()) {
                        val potentialCard = potentialAmexNumber + allNumbers[i + 3]
                        if (CreditCardValidator.validateCardNumber(potentialCard, cardIssuer)) {
                            cacheDetectedNumber(potentialCard)
                        }
                    }
                }
            }
        }

        log(logTag, "parseCardInfoFromDetectedText: detectedNumber: $detectedNumbersCache")
        log(logTag, "parseCardInfoFromDetectedText: detectedDate: $detectedDatesCache")

        val topNumber = detectedNumbersCache.maxByOrNull { it.value }
        return if (topNumber != null && topNumber.value >= 2) {
            val (month, year) = detectedDatesCache.maxByOrNull { it.value }?.let { topDateEntry ->
                runCatching {
                    Pair(
                        topDateEntry.key.substring(0, 2).toInt(),
                        topDateEntry.key.substring(2).toInt()
                    )
                }.getOrNull()
            } ?: Pair(0, 0)
            CreditCardInfo(
                number = topNumber.key,
                month = month,
                year = year,
                cvc = ""
            )
        } else null
    }

    private val validCardIssuer = arrayOf(
        CardIssuer.Amex,
        CardIssuer.Jcb,
        CardIssuer.Visa,
        CardIssuer.Mastercard,
        CardIssuer.Unionpay,
        CardIssuer.DinersClub
    )

    private val expirationDateRegex = Regex("^(\\d{2}\\D{1,3})(\\d{1,4})?")

    private fun cacheDetectedNumber(number: String) {
        synchronized(lock) {
            when (val count = detectedNumbersCache[number]) {
                null -> detectedNumbersCache[number] = 1
                else -> detectedNumbersCache[number] = count + 1
            }
        }
    }

    private fun cacheDetectedDate(date: String) {
        synchronized(lock) {
            when (val count = detectedDatesCache[date]) {
                null -> detectedDatesCache[date] = 1
                else -> detectedDatesCache[date] = count + 1
            }
        }
    }

    private fun clearCache() {
        synchronized(lock) {
            detectedNumbersCache.clear()
            detectedDatesCache.clear()
            log(logTag, "clearCache(): done")
        }
    }

    private fun parseCardIssuer(fromNumber: String): CardIssuer? =
        validCardIssuer.firstOrNull { issuer ->
            issuer.identificationNumber
                .firstOrNull { idNumber -> fromNumber.startsWith(idNumber) } != null
        }

    private fun shortenDate(dateRegexMatchResult: MatchResult): String? {
        val groupValues = dateRegexMatchResult.groupValues
        return if (groupValues.count() >= 3 && groupValues[2].length == 4) {
            val month = groupValues[1]
            val year = groupValues[2].substring(2)
            "$month$year"
        } else {
            null
        }
    }

    companion object {
        private val logTag = CardNumberAnalyzer::class.java.simpleName
    }
}

private val String.numericCharacters: String
    get() = replace(Regex("[^0-9]"), "")