package jp.elestyle.androidapp.elepay.utils

import jp.elestyle.androidapp.elepay.BuildConfig
import jp.elestyle.androidapp.elepay.ElepayConfiguration
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayTheme
import jp.elestyle.androidapp.elepay.GooglePayEnvironment
import jp.elestyle.androidapp.elepay.data.ElepayRemoteConfig
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.utils.locale.LanguageKey
import jp.elestyle.androidapp.elepay.utils.parsing.ContentConverter
import jp.elestyle.androidapp.elepay.utils.parsing.DataParser
import org.json.JSONException
import org.json.JSONObject

internal object ConfigManager {
    private val logTag = ConfigManager::class.java.simpleName

    // This flag only differentiate the inited state from the un-inited state.
    // When the sdk is setup more than one time, e.g. call `Elepay.setup()` multiple times, this flag
    // remains `true` and won't change as true -> false -> true.
    var isInited = false
        get() = synchronized(this) {
            return field
        }
        private set(value) {
            synchronized(this) {
                field = value
            }
        }

    var appKey: String = ""
        private set

    var apiBaseUrl: String = ""
        private set

    var googlePayEnvironment: GooglePayEnvironment? = null
        private set

    var googlePayExistingPaymentRequired: Boolean = true
        private set

    // Save the value here and will be used by the Localization.
    var languageKey: LanguageKey = LanguageKey.System
        get() = synchronized(this) {
            return field
        }
        set(value) {
            synchronized(this) {
                field = value
            }
        }

    var theme: ElepayTheme = ElepayTheme.System
        get() = synchronized(this) {
            return field
        }
        set(value) {
            synchronized(this) {
                field = value
            }
        }

    fun update(config: ElepayConfiguration) {
        isInited = true

        this.appKey = config.apiKey
        this.apiBaseUrl =
            if (config.remoteHostBaseUrl.isEmpty())
                "${BuildConfig.API_URL_SCHEME}://${BuildConfig.API_URL_HOST}/${BuildConfig.API_URL_VAR}"
                    .removeSuffix("/")
            else config.remoteHostBaseUrl
        this.googlePayEnvironment = config.googlePayEnvironment
        this.googlePayExistingPaymentRequired = config.googlePayExistingPaymentRequired
        this.languageKey = config.languageKey
        this.theme = config.theme
    }

    suspend fun fetchConfigs(): ResultType<ElepayRemoteConfig, ElepayError> {
        when (val result = ServerAPIClient.retrieveConfigs()) {
            is ResultType.Succeeded -> {
                val encrypted = DataParser.parseEncryptedConfig(jsonObject = result.data)
                    ?: return ResultType.Succeeded(ElepayRemoteConfig(listOf()))

                val jsonConfigs = ContentConverter.decrypt(content = encrypted).let {
                    try {
                        JSONObject(it)
                    } catch (e: JSONException) {
                        JSONObject()
                    }
                }
                return ResultType.Succeeded(DataParser.parseConfig(jsonObject = jsonConfigs))
            }

            is ResultType.Failed -> {
                val fmtErr = """
                    [${result.error.code}, ${result.error.message}, ${result.error.extra}]
                    """.trimIndent()
                log(logTag, "failed retrieve configs. error: $fmtErr", logLevel = LogLevel.ERROR)
                return ResultType.Failed(
                    ElepayError.SystemError(
                        errorCode = result.error.code,
                        message = result.error.message
                    )
                )
            }
        }
    }
}