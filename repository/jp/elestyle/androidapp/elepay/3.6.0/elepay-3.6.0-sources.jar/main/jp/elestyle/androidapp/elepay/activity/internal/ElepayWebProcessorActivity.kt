package jp.elestyle.androidapp.elepay.activity.internal

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.os.BundleCompat
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.ServerAPIClient
import jp.elestyle.androidapp.elepay.utils.SystemUtil
import jp.elestyle.androidapp.elepay.utils.extensions.checkAndApplyElepayTheme
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject
import java.lang.ref.WeakReference

internal class ElepayWebProcessorActivity : AppCompatActivity(), ElepayJsActionPerformer,
    ElepayWebViewClientActionListener {
    enum class IntentExtraKey(val rawValue: String) {
        PAYMENT_DATA("payment_data"),
        EXPLICIT_PAYMENT_ID("payment_id"),
        TARGET_URL("url"),
        APP_SCHEME("app_scheme"),
        JSON_DATA("json_data"),
        ;
    }

    private lateinit var paymentData: PaymentCommon
    private var explicitPaymentId: String? = null
    private var appScheme: String? = null
    private var jsonData = JSONObject()
    private val mainScope = MainScope()
    private lateinit var webView: WebView

    private val paymentId: String
        get() = explicitPaymentId ?: paymentData.id

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        checkAndApplyElepayTheme(ConfigManager.theme)

        super.onCreate(savedInstanceState)

        val url: String
        intent.extras!!.run {
            paymentData = BundleCompat.getParcelable(
                this,
                IntentExtraKey.PAYMENT_DATA.rawValue,
                PaymentCommon::class.java
            )!!
            explicitPaymentId = getString(IntentExtraKey.EXPLICIT_PAYMENT_ID.rawValue)
            appScheme = getString(IntentExtraKey.APP_SCHEME.rawValue)
            url = getString(IntentExtraKey.TARGET_URL.rawValue)!!

            jsonData = getString(IntentExtraKey.JSON_DATA.rawValue)?.let {
                try {
                    JSONObject(it)
                } catch (e: JSONException) {
                    JSONObject()
                }
            } ?: JSONObject()
        }

        setContentView(R.layout.elepay_web_activity)

        val toolbar = findViewById<Toolbar>(R.id.elepay_web_view_tool_bar)
        setSupportActionBar(toolbar)
        supportActionBar!!.apply {
            setDisplayHomeAsUpEnabled(true)
            setHomeAsUpIndicator(R.drawable.ic_clear_light_24dp)
        }

        webView = findViewById(R.id.elepay_web_view)
        webView.settings.apply {
            javaScriptEnabled = true
            mediaPlaybackRequiresUserGesture = false
            @Suppress("DEPRECATION")
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
            }

            // Explicitly set the default zoom level
            textZoom = 100
        }
        webView.addJavascriptInterface(
            ElepayJavaScriptInterface(paymentData, WeakReference(this)),
            ElepayJavaScriptInterface.ELEPAY_JS_NAME
        )
        webView.webViewClient = ElepayWebViewClient(appScheme, WeakReference(this))

        CookieManager.getInstance().apply {
            setAcceptThirdPartyCookies(webView, true)
            setAcceptCookie(true)
        }

        webView.loadUrl(url)
    }

    override fun onDestroy() {
        super.onDestroy()

        mainScope.cancel()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            notifyResult(ElepayResult.Canceled(paymentId))
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        notifyResult(ElepayResult.Canceled(paymentId))
        return true
    }

    override fun onPaymentResult(result: ElepayResult) {
        notifyResult(result)
    }

    override fun onCapturePayment(token: String) {
        mainScope.launch {
            when (val result = ServerAPIClient.capture(paymentId = paymentId, token = token)) {
                is ResultType.Failed ->
                    notifyResult(
                        ElepayResult.Failed(
                            paymentId,
                            ElepayError.PaymentFailure(
                                ErrorCodeGenerator.generate(
                                    PlatformCode.SDK,
                                    paymentData.provider,
                                    paymentData.method,
                                    ErrorCode.FAILED_CAPTURE
                                ),
                                result.error.message
                            )
                        )
                    )

                is ResultType.Succeeded ->
                    notifyResult(ElepayResult.Succeeded(paymentId))
            }
        }
    }

    override fun onConfirmPayment(token: String) {
        mainScope.launch {
            when (val result = ServerAPIClient.confirm(sourceId = paymentId, token = token)) {
                is ResultType.Failed ->
                    notifyResult(
                        ElepayResult.Failed(
                            paymentId,
                            ElepayError.PaymentFailure(
                                ErrorCodeGenerator.generate(
                                    PlatformCode.SDK,
                                    paymentData.provider,
                                    paymentData.method,
                                    ErrorCode.FAILED_CONFIRM
                                ),
                                result.error.message
                            )
                        )
                    )

                is ResultType.Succeeded ->
                    notifyResult(ElepayResult.Succeeded(paymentId))
            }
        }
    }

    override fun onPaymentFinished() {
        finish()
    }

    override fun onProviderPaymentParams(callbackEvent: String) {
        val js = "\$elepay.$callbackEvent($jsonData)"
        runOnUiThread {
            webView.evaluateJavascript(js, null)
        }
    }

    override fun onOpen(url: String) {
        val uri = Uri.parse(url)
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }

    private fun notifyResult(result: ElepayResult) {
        ElepayResultHandlerManager.notifyResult(result, paymentId)
        runOnUiThread { finish() }
    }
}

internal interface ElepayWebViewClientActionListener {
    fun onPaymentFinished()
}

private class ElepayWebViewClient(
    private val appScheme: String?,
    private val weakListener: WeakReference<ElepayWebViewClientActionListener>
) : WebViewClient() {

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        // `false` indicates the processing is good to continue.
        var handled = false

        if (request != null && view != null) {
            val uri = request.url
            if (uri != null) {
                handled = processSpecialUri(uri, view)
            }
        }

        return handled
    }

    // There are some schemes that needs to be handled manually. Since this WebView is only used
    // internally, we can do this "hard code" thing. As the SDK upgrading, this method may need
    // adjust, too.
    private fun processSpecialUri(uri: Uri, webView: WebView): Boolean =
        when (uri.scheme) {
            null -> false

            "intent" -> {
                val ctx = webView.context
                val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                if (SystemUtil.isIntentLaunchable(intent, ctx)) {
                    ctx.startActivity(intent)
                    true
                } else {
                    val fallbackUrl = intent.getStringExtra("browser_fallback_url")
                    if (fallbackUrl != null) {
                        val webIntent = Intent(Intent.ACTION_VIEW)
                        webIntent.addCategory(Intent.CATEGORY_BROWSABLE)
                        webIntent.data = Uri.parse(fallbackUrl)
                        ctx.startActivity(webIntent)
                        true
                    } else false
                }
            }

            appScheme -> {
                // Try to open the app that uses elepay.
                val ctx = webView.context
                val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                if (SystemUtil.isIntentLaunchable(intent, ctx)) {
                    // It's the callback to the original app. Should finish processing here.
                    weakListener.get()?.onPaymentFinished()
                    ctx.startActivity(intent)
                    true
                } else {
                    false
                }
            }

            else -> false
        }

}
