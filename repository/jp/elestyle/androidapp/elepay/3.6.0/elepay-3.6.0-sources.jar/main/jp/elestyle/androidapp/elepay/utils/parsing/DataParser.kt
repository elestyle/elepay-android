package jp.elestyle.androidapp.elepay.utils.parsing

import android.util.Base64
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ChargeDataStatus
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ElepayRemoteConfig
import jp.elestyle.androidapp.elepay.data.EncryptedContent
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaygentGooglePayConfig
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentDataType
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PaymentMethodResourceInfo
import jp.elestyle.androidapp.elepay.data.PaymentTestModeData
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.RedirectType
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.data.checkout.CheckoutData
import jp.elestyle.androidapp.elepay.data.checkout.CheckoutPayload
import jp.elestyle.androidapp.elepay.data.checkout.CheckoutProduct
import jp.elestyle.androidapp.elepay.data.checkout.CodeSettings
import jp.elestyle.androidapp.elepay.data.checkout.PaymentMethodData
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject


internal object DataParser {
    var base64Decoding: (String) -> ByteArray = { encoded ->
        Base64.decode(encoded, Base64.DEFAULT)
    }

    fun parseEncryptedConfig(jsonObject: JSONObject): EncryptedContent? {
        // payload is in the format of:
        //  nonce(6 digit number) + BASE64 encoded encrypted string.
        val payload = jsonObject.optString("payload", "")
        if (payload.count() < 6) {
            return null
        }
        return ContentConverter.retrieveEncryptedContent(compound = payload)
    }

    // Decrypted string should be a JSON object, looking like:
    // {
    //   "allpay": {"scheme": ""},
    //   "paypal": {"scheme": "", "mode": "sandbox"},
    //   "stripe": {"scheme": "", "sdkKey": "pk_test_xxxx", "appleMerchantId": "merchant.jp.elestyle.elepay"}
    // }
    fun parseConfig(jsonObject: JSONObject): ElepayRemoteConfig {
        val providerConfigs = mutableListOf<ElepayProviderConfig>()
        // Loop through the sdk defined providers, so that we won't miss the config parsing when
        // add a new provider.
        for (provider in PaymentMethodProvider.values()) {
            val jsonConfig = jsonObject.optJSONObject(provider.rawValue) ?: continue

            when (provider) {
                PaymentMethodProvider.ALLPAY -> {
                    val mode = jsonConfig.optString("mode", "")
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(
                        ElepayProviderConfig.Allpay(
                            usesDevelopmentEnvironment = mode.lowercase() == "sandbox",
                            appScheme = appScheme
                        )
                    )
                }
                PaymentMethodProvider.STRIPE -> {
                    val sdkKey = jsonConfig.optString("sdkKey", "")
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(
                        ElepayProviderConfig.Stripe(
                            publishableKey = sdkKey,
                            appScheme = appScheme
                        )
                    )
                }
                PaymentMethodProvider.BRAINTREE -> {
                    val mode = jsonConfig.optString("mode", "")
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(
                        ElepayProviderConfig.Braintree(
                            sandbox = mode.lowercase() == "sandbox",
                            appScheme = appScheme
                        )
                    )
                }
                PaymentMethodProvider.WECHAT_PAY -> {
                    val appKey = jsonConfig.optString("subAppIdForApp")
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(
                        ElepayProviderConfig.WechatPay(
                            appKey = appKey,
                            appScheme = appScheme
                        )
                    )
                }
                PaymentMethodProvider.ALIPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.Alipay(appScheme))
                }
                PaymentMethodProvider.LINE_PAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.LinePay(appScheme))
                }
                PaymentMethodProvider.PAIDY -> {
                    // No thing to do for paidy. Native sdk do not require configs for paidy.
                }
                PaymentMethodProvider.PAYPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.PayPay(appScheme))
                }
                PaymentMethodProvider.MERPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.Merpay(appScheme))
                }
                PaymentMethodProvider.KSHER -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val wechatKey = jsonConfig.optString("subAppIdForApp")
                    providerConfigs.add(ElepayProviderConfig.Ksher(wechatKey, appScheme))
                }
                PaymentMethodProvider.AMAZON_PAY -> {
                    // Nothing to do with amazon pay
                }
                PaymentMethodProvider.DOCOMO_PAY -> {
                    // Nothing to do with docomo pay
                }
                PaymentMethodProvider.ATONE -> {
                    // Nothing to do with atone
                }
                PaymentMethodProvider.PAYGENT -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val googlePayConfig =
                        jsonConfig.optJSONObject("defaultGooglePayRequest") ?: JSONObject()
                    val merchantId = jsonConfig.optString("merchantId")
                    providerConfigs.add(
                        ElepayProviderConfig.Paygent(
                            PaygentGooglePayConfig(
                                googlePayConfig,
                                merchantId
                            ),
                            appScheme
                        )
                    )
                }
                PaymentMethodProvider.AUPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.AuPay(appScheme))
                }
                PaymentMethodProvider.RAKUTEN_PAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val gatewayCode = jsonConfig.optString("gatewayCode", "")
                    providerConfigs.add(ElepayProviderConfig.RakutenPay(gatewayCode, appScheme))
                }
                PaymentMethodProvider.JCOINPAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.JcoinPay(appScheme))
                }
                PaymentMethodProvider.UNION_PAY -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    val mode = jsonConfig.optString("mode", "")
                    providerConfigs.add(ElepayProviderConfig.UnionPay(appScheme, mode))
                }
                PaymentMethodProvider.ALIPAY_PLUS -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.AlipayPlus(appScheme))
                }
                PaymentMethodProvider.GMO -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.Gmo(appScheme))
                }
                PaymentMethodProvider.RAKUTEN_BANK -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.RakutenBank(appScheme))
                }
                PaymentMethodProvider.SONY_PAYMENT -> {
                    val appScheme = jsonConfig.optString("scheme", "")
                    providerConfigs.add(ElepayProviderConfig.SonyPayment(appScheme))
                }
                PaymentMethodProvider.AEON_PAY -> {
                    // Nothing to do with AEON pay
                }
                PaymentMethodProvider.PXPAY -> {
                    // Nothing to do with web browser pay
                }
                PaymentMethodProvider.ELEPAY_WEB_BROWSER_PAY -> {
                    // Nothing to do with web browser pay
                }
            }
        }
        return ElepayRemoteConfig(providerConfigs)
    }

    fun parseChargeData(jsonCharge: JSONObject): ResultType<ChargeData, ElepayError> {
        // Validate json data.
        val obj = jsonCharge.optString("object", "")
        if (obj != "charge") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_PAYLOAD,
                    message = "Invalid payload. raw: $jsonCharge"
                )
            )
        }

        val paymentId = jsonCharge.optString("id", "")
        if (paymentId.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_PAYMENT_ID,
                    message = "Invalid payment id. raw: $jsonCharge"
                )
            )
        }

        val resource = jsonCharge.optString("resource", "")
        if (resource != "android") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_RESOURCE,
                    message = "Invalid payload. Could not be handled by Android SDK. raw: $jsonCharge"
                )
            )
        }

        val amount = jsonCharge.optString("amount", "")
        validateAmount(amount)?.let { error ->
            return ResultType.Failed(error)
        }

        val currency = jsonCharge.optString("currency", "JPY")
        val name = jsonCharge.optString("name", "")
        val email = jsonCharge.optString("email", "")

        val method = jsonCharge.optString("paymentMethod")
            .let { PaymentMethod.from(string = it) }
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYMENT_METHOD
                )
            )

        val isTestMode = !jsonCharge.optBoolean("liveMode", true)

        val jsonCredential = parseCredential(jsonCharge, base64Decoding)
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_CREDENTIAL)
            )

        // The following 2 could be null.
        val payload = parsePayload(jsonCredential)
        val redirectType = jsonCredential.optString("redirectType", "any")
        val redirectUrl = parseRedirectUrl(jsonCredential)

        val providerString = jsonCredential.optString("provider")
        val provider = PaymentMethodProvider.from(providerString)
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_PROVIDER)
            )

        // Check status last. Because we only check parts of the status,
        // we need to make sure the other fields are all valid.
        val status = when (jsonCharge.optString("status", "")) {
            "pending" -> ChargeDataStatus.PENDING
            "captured" -> ChargeDataStatus.CAPTURED
            else ->
                return ResultType.Failed(
                    generateUserAwareInvalidPayloadError(
                        errorCode = ErrorCode.INVALID_STATUS,
                        message = "Invalid status. raw: $jsonCharge"
                    )
                )
        }

        return ResultType.Succeeded(
            ChargeData(
                paymentCommon = PaymentCommon(
                    paymentId,
                    provider,
                    method,
                    PaymentDataType.CHARGE,
                    if (isTestMode && redirectUrl != null) PaymentTestModeData(redirectUrl) else null
                ),
                amount = amount,
                currency = currency,
                name = name,
                email = email,
                payload = payload,
                redirectType = RedirectType.from(redirectType) ?: RedirectType.NATIVE,
                redirectUrl = redirectUrl,
                status = status,
                rawJson = jsonCharge
            )
        )
    }

    private fun validateAmount(amount: String): ElepayError? {
        val valid = if (amount.isEmpty()) {
            false
        } else {
            amount.toDoubleOrNull()
                ?.let { it > 0 }
                ?: false
        }
        return if (!valid) generateUserAwareInvalidPayloadError(ErrorCode.INVALID_AMOUNT)
        else null
    }

    fun parseSourceData(jsonSource: JSONObject): ResultType<SourceData, ElepayError> {
        // Validate json data.
        val obj = jsonSource.optString("object", "")
        if (obj != "source") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_PAYLOAD,
                    message = "Invalid payload. raw: $jsonSource"
                )
            )
        }

        val sourceId = jsonSource.optString("id", "")
        if (sourceId.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_PAYMENT_ID,
                    message = "Invalid payment id. raw: $jsonSource"
                )
            )
        }

        val status = jsonSource.optString("status", "")
        if (status != "pending") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_STATUS,
                    message = "Invalid status. raw: $jsonSource"
                )
            )
        }

        val resource = jsonSource.optString("resource", "")
        if (resource != "android") {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    errorCode = ErrorCode.INVALID_RESOURCE,
                    message = "Invalid payload. Could not be handled by Android SDK. raw: $jsonSource"
                )
            )
        }

        val method = jsonSource.optString("paymentMethod")
            .let { PaymentMethod.from(string = it) }
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_PAYMENT_METHOD)
            )

        val isTestMode = !jsonSource.optBoolean("liveMode", true)

        val jsonCredential = parseCredential(jsonSource, base64Decoding)
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_CREDENTIAL)
            )

        val payload = parsePayload(jsonCredential)
        val redirectType = jsonCredential.optString("redirectType", "any")
        val redirectUrl = parseRedirectUrl(jsonCredential)

        val providerString = jsonCredential.optString("provider")
        val provider = PaymentMethodProvider.from(providerString)
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(ErrorCode.INVALID_PROVIDER)
            )

        return ResultType.Succeeded(
            SourceData(
                paymentCommon = PaymentCommon(
                    sourceId,
                    provider,
                    method,
                    PaymentDataType.SOURCE,
                    if (isTestMode && redirectUrl != null) PaymentTestModeData(redirectUrl) else null
                ),
                payload = payload,
                redirectUrl = redirectUrl,
                redirectType = RedirectType.from(redirectType) ?: RedirectType.NATIVE,
                rawJson = jsonSource
            )
        )
    }

    fun parseCheckout(jsonCheckout: JSONObject): ResultType<CheckoutData, ElepayError> {
        val codeId = jsonCheckout.optString("id", "")
        if (codeId.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "No code id."
                )
            )
        }

        val orderId = jsonCheckout.optString("orderNo", "")
        if (orderId.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "No order id."
                )
            )
        }

        val payloadStr = jsonCheckout.optString("payload", "")
        if (payloadStr.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "no checkout payload"
                )
            )
        }
        val jsonPayload = ContentConverter.retrieveEncryptedContent(payloadStr)
            ?.let { encryptedContent ->
                try {
                    JSONObject(ContentConverter.decrypt(encryptedContent, base64Decoding))
                } catch (e: Exception) {
                    null
                }
            }
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "invalid checkout payload"
                )
            )
        val appId = jsonPayload.optString("appId", "")
        val pk = jsonPayload.optString("key")
        if (appId.isEmpty() || pk.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "invalid checkout payload content"
                )
            )
        }
        if (pk != ConfigManager.appKey) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "The public key dose not match."
                )
            )
        }
        val payload = CheckoutPayload(appId, pk)

        val amount = jsonCheckout.optString("amount", "")
        val currency = jsonCheckout.optString("currency", "JPY")
        val expiryDuration = jsonCheckout.optLong("expiryPeriod", 0L)

        val items = jsonCheckout.optJSONArray("items")?.let { jsonItems ->
            val products = mutableListOf<CheckoutProduct>()
            for (i in 0 until jsonItems.length()) {
                val jsonItem = jsonItems.optJSONObject(i) ?: continue

                val imageUrl = jsonItem.optString("image", "")
                val title = jsonItem.optString("name", "")
                val unitPrice = jsonItem.optString("price", "")
                val count = jsonItem.optInt("count", 1)
                products.add(CheckoutProduct(imageUrl, title, unitPrice, count))
            }
            return@let products
        }

        return ResultType.Succeeded(
            CheckoutData(
                codeId,
                orderId,
                amount,
                currency,
                expiryDuration,
                items,
                payload
            )
        )
    }

    fun parseCodeSettings(jsonCodeSettings: JSONObject): ResultType<CodeSettings, ElepayError> {
        val payloadStr = jsonCodeSettings.optString("payload")
        if (payloadStr.isEmpty()) {
            return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "no code-setting payload."
                )
            )
        }

        val jsonPayload = ContentConverter.retrieveEncryptedContent(payloadStr)
            ?.let { encryptedContent ->
                try {
                    JSONObject(ContentConverter.decrypt(encryptedContent, base64Decoding))
                } catch (e: Exception) {
                    null
                }
            }
            ?: return ResultType.Failed(
                generateUserAwareInvalidPayloadError(
                    ErrorCode.INVALID_PAYLOAD,
                    "invalid checkout payload."
                )
            )

        val basic = jsonPayload.optJSONObject("basic") ?: JSONObject()
        val paymentFilters = jsonPayload.optJSONArray("paymentFilters") ?: JSONArray()

        val jsonPaymentMethods = jsonPayload.optJSONArray("paymentMethods") ?: JSONArray()
        val methodsData = mutableListOf<PaymentMethodData>()
        for (i in 0 until jsonPaymentMethods.length()) {
            val jsonPm = jsonPaymentMethods.optJSONObject(i) ?: continue

            // Filter pms which is not for android.
            val jsonResources = jsonPm.optJSONArray("resources") ?: continue
            var isAndroidResource = false
            for (j in 0 until jsonResources.length()) {
                val res = jsonResources.optString(j, "")
                if (res == "android") {
                    isAndroidResource = true
                    break
                }
            }
            if (!isAndroidResource) continue

            val pm = jsonPm.optString("paymentMethod", "")
                .let {
                    PaymentMethod.from(it)
                }
                ?: continue
            val brands = jsonPm.optJSONArray("brand")?.let { jsonBrands ->
                val brandStrings = mutableListOf<String>()
                for (brandIdx in 0 until jsonBrands.length()) {
                    brandStrings.add(jsonBrands.optString(brandIdx))
                }
                brandStrings
            } ?: listOf()
            methodsData.add(PaymentMethodData(pm, brands))
        }

        return ResultType.Succeeded(CodeSettings(basic, paymentFilters, methodsData))
    }

    fun parsePaymentMethodResourceInfo(json: JSONObject): Map<String, PaymentMethodResourceInfo> {
        val ret = mutableMapOf<String, PaymentMethodResourceInfo>()
        for (key in json.keys()) {
            val jsonPaymentMethodResource = json.optJSONObject(key) ?: continue
            val jsonName = jsonPaymentMethodResource.optJSONObject("name") ?: continue
            val jsonImage = jsonPaymentMethodResource.optJSONObject("image") ?: continue

            val nameMap = mutableMapOf<String, String>()
            for (i18nKey in jsonName.keys()) {
                nameMap[i18nKey] = jsonName.optString(i18nKey)
            }

            val imageUrlMap = mutableMapOf<String, String>()
            for (imageUrlKey in jsonImage.keys()) {
                imageUrlMap[imageUrlKey] = jsonImage.optString(imageUrlKey)
            }

            ret[key] = PaymentMethodResourceInfo(nameMap, imageUrlMap)
        }
        return ret
    }

    private fun parseCredential(
        jsonCharge: JSONObject,
        base64Decoding: (String) -> ByteArray
    ): JSONObject? {
        val rawCredential = jsonCharge.optString("credential", "")
            .ifEmpty { return null }

        val encryptedCredential =
            ContentConverter.retrieveEncryptedContent(rawCredential) ?: return null
        val credentialString = ContentConverter.decrypt(
            content = encryptedCredential,
            base64Decoding = base64Decoding
        )
        return try {
            JSONObject(credentialString)
        } catch (e: JSONException) {
            return null
        }
    }

    private fun parsePayload(jsonCredential: JSONObject): String? =
        if (jsonCredential.has("payload") && !jsonCredential.isNull("payload")) {
            jsonCredential.optString("payload", "").takeIf { it.isNotEmpty() }
        } else null

    private fun parseRedirectUrl(jsonCredential: JSONObject): String? =
        if (jsonCredential.has("redirectUrl") && !jsonCredential.isNull("redirectUrl")) {
            jsonCredential.optString("redirectUrl", "").let {
                if (it.isEmpty()) null else it.replaceFirst(
                    "<key>",
                    ConfigManager.appKey
                )
            }
        } else null

    private fun generateUserAwareInvalidPayloadError(
        errorCode: ErrorCode,
        message: String = "charge error"
    ): ElepayError.InvalidPayload =
        ElepayError.InvalidPayload(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.ENDUSER,
                null,
                null,
                errorCode
            ),
            message = message
        )
}