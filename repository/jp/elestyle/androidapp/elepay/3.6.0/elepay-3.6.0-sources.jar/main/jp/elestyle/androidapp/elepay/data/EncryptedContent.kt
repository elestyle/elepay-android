package jp.elestyle.androidapp.elepay.data

internal data class EncryptedContent(val raw: String, val key: String)