package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import org.json.JSONException
import org.json.JSONObject


internal object WechatPayProcessor : ElepayProcessor {

    var apiKey: String = ""
        private set

    override val isWellConfigured: Boolean
        get() = apiKey.isNotEmpty()

    override fun setup(providerConfig: ElepayProviderConfig) {
        if (providerConfig is ElepayProviderConfig.WechatPay) {
            apiKey = providerConfig.appKey
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else if (chargeData.payload == null || chargeData.payload.isEmpty()) {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    chargeData.id, ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.WECHAT_PAY,
                            PaymentMethod.WECHAT_PAY,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "charge error: no payload"
                    )
                )
            )
            false
        } else {
            processPayment(
                paymentId = chargeData.id,
                payload = chargeData.payload,
                fromActivity = fromActivity,
                resultHandler = resultHandler
            )
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    private fun processPayment(
        paymentId: String,
        payload: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        if (!isWellConfigured) {
            val failure = ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.UninitializedPaymentMethod(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        null,
                        null,
                        ErrorCode.UNINIT
                    ),
                    paymentMethod = PaymentMethod.WECHAT_PAY.rawValue,
                    message = "Wechat Pay is not configured. Please contact elepay for support."
                )
            )
            postElepayResult(failure, resultHandler)
            return false
        }

        val data = try {
            JSONObject(payload)
        } catch (e: JSONException) {
            val failure = ElepayResult.Failed(
                paymentId, ElepayError.InvalidPayload(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.WECHAT_PAY,
                        PaymentMethod.WECHAT_PAY,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    message = payload
                )
            )
            postElepayResult(failure, resultHandler)
            return false
        }

        val info = WechatPayPerformer.PaymentInfo(
            apiKey,
            paymentId,
            provider = PaymentMethodProvider.WECHAT_PAY,
            paymentData = data
        )
        return WechatPayPerformer.pay(info, fromActivity, resultHandler)
    }
}
