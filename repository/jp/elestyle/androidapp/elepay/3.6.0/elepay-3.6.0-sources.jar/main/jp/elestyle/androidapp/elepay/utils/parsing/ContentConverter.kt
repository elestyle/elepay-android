package jp.elestyle.androidapp.elepay.utils.parsing

import android.util.Base64
import jp.elestyle.androidapp.elepay.data.EncryptedContent
import jp.elestyle.androidapp.elepay.utils.SecuredDataStore
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

internal object ContentConverter {

    fun retrieveEncryptedContent(compound: String): EncryptedContent? {
        val encrypted = try {
            compound.substring(6)
        } catch (e: StringIndexOutOfBoundsException) {
            return null
        }
        val nonce = try {
            compound.substring(0, 6)
        } catch (e: StringIndexOutOfBoundsException) {
            return null
        }
        val key = SecuredDataStore.retrieveKey() + nonce

        return EncryptedContent(raw = encrypted, key = key)
    }

    fun decrypt(
        content: EncryptedContent,
        base64Decoding: (String) -> ByteArray = { Base64.decode(it, Base64.DEFAULT) }
    ): String = decrypt(
        content.key.toByteArray(),
        base64Decoding(content.raw)
    )

    private fun decrypt(keyBytes: ByteArray, encryptionBytes: ByteArray): String =
        try {
            Cipher.getInstance("AES/CTR/NoPadding").apply {
                init(
                    Cipher.DECRYPT_MODE,
                    SecretKeySpec(keyBytes, "AES"),
                    IvParameterSpec(SecuredDataStore.generateIvParam())
                )
            }.doFinal(encryptionBytes).toString(Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }

    fun encrypt(
        content: String,
        key: String,
        base64Encoding: (ByteArray) -> String = { Base64.encodeToString(it, Base64.NO_WRAP) }
    ): String {
        var nonce = ""
        repeat(6) {
            nonce += (0..15).random().toString(16)
        }
        val encrypted = try {
            Cipher.getInstance("AES/CTR/NoPadding").apply {
                init(
                    Cipher.ENCRYPT_MODE,
                    SecretKeySpec((key + nonce).toByteArray(), "AES"),
                    IvParameterSpec(SecuredDataStore.generateIvParam())
                )
            }.doFinal(content.toByteArray())
        } catch (e: java.lang.Exception) {
            byteArrayOf()
        }
        return nonce + base64Encoding(encrypted)
    }
}