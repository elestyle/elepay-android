package jp.elestyle.androidapp.elepay.utils

import android.util.Base64
import jp.elestyle.androidapp.elepay.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

internal object ServerAPIClient {
    private val applicationJsonContentTypeHeaders: Map<String, String> = mapOf(
        "Content-Type" to "application/json; charset=utf-8",
        "Accept" to "application/json"
    )

    suspend fun retrieveConfigs() = withContext(Dispatchers.IO) {
        ApiRequester.get(
            "${ConfigManager.apiBaseUrl}/config/providers",
            headers = fetchCommonHeaders()
        )
    }

    suspend fun capture(paymentId: String, token: String, threeDSecureId: String = "") =
        withContext(Dispatchers.IO) {
            val credential = JSONObject().apply {
                put("token", token)
                if (threeDSecureId.isNotEmpty()) {
                    put("threeDSecureId", threeDSecureId)
                }
            }
            val params = JSONObject().apply {
                put("extra", credential)
            }

            ApiRequester.post(
                url = "${ConfigManager.apiBaseUrl}/charges/$paymentId/capture",
                headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
                bodyData = ApiPostRequestBody.JsonObject(params)
            )
        }

    suspend fun confirm(sourceId: String, token: String) = withContext(Dispatchers.IO) {
        val credential = JSONObject().apply {
            put("token", token)
        }
        val params = JSONObject().apply {
            put("extra", credential)
        }
        ApiRequester.post(
            url = "${ConfigManager.apiBaseUrl}/sources/$sourceId/confirm",
            headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
            bodyData = ApiPostRequestBody.JsonObject(params)
        )
    }

    suspend fun verifyCharge(paymentId: String, data: String) {
        verify("${ConfigManager.apiBaseUrl}/charges/$paymentId/verify", data)
    }

    suspend fun verifySource(sourceId: String, data: String) {
        verify("${ConfigManager.apiBaseUrl}/sources/$sourceId/verify", data)
    }

    private suspend fun verify(url: String, data: String) = withContext(Dispatchers.IO) {
        val params = JSONObject().apply {
            put("metadata", JSONObject().apply {
                put("credential", data)
            })
        }
        ApiRequester.post(
            url,
            headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
            bodyData = ApiPostRequestBody.JsonObject(params)
        )
    }

    suspend fun report(errors: List<String>) = withContext(Dispatchers.IO) {
        val params = JSONObject().apply {
            put("reports", JSONArray().apply {
                errors.forEach { put(it) }
            })
        }
        ApiRequester.post(
            url = "${ConfigManager.apiBaseUrl}/sdk-reports",
            headers = fetchCommonHeaders() + applicationJsonContentTypeHeaders,
            bodyData = ApiPostRequestBody.JsonObject(params)
        )
    }

    suspend fun retrieveCheckout(code: String, domain: String) = withContext(Dispatchers.IO) {
        val header = mapOf(
            "origin" to domain
        )
        ApiRequester.get(url = "${ConfigManager.apiBaseUrl}/codes-checkout/$code", headers = header)
    }

    suspend fun retrieveCheckoutSetting(pkey: String) = withContext(Dispatchers.IO) {
        ApiRequester.get(
            url = "${ConfigManager.apiBaseUrl}/config/app-code-setting",
            headers = fetchCommonHeaders(pkey)
        )
    }

    suspend fun retrievePaymentMethodResourceInfo() = withContext(Dispatchers.IO) {
        ApiRequester.get(
            url = "https://resource.elecdn.com/payment-methods/info.json",
            headers = fetchCommonHeaders()
        )
    }

    suspend fun createChargeForCheckout(
        codeId: String,
        pKey: String,
        paymentMethod: String,
        resource: String
    ) = withContext(Dispatchers.IO) {
        val params = JSONObject().apply {
            put("paymentMethod", paymentMethod)
            put("resource", resource)
        }
        ApiRequester.post(
            url = "${ConfigManager.apiBaseUrl}/codes/$codeId/charge",
            headers = fetchCommonHeaders(pKey),
            bodyData = ApiPostRequestBody.JsonObject(params)
        )
    }

    suspend fun chargeStatus(chargeId: String) = withContext(Dispatchers.IO) {
        ApiRequester.get(
            url = "${ConfigManager.apiBaseUrl}/charges/$chargeId/status",
            headers = fetchCommonHeaders()
        )
    }

    suspend fun sourceStatus(sourceId: String) = withContext(Dispatchers.IO) {
        ApiRequester.get(
            url = "${ConfigManager.apiBaseUrl}/sources/$sourceId/status",
            headers = fetchCommonHeaders()
        )
    }

    private fun fetchCommonHeaders(pKey: String = ConfigManager.appKey): Map<String, String> {
        // Uses http basic authorization, which in format of "username:password",
        // "username" is the `apiKey`, and we leave "password" empty.
        val basicAuth = "Basic " +
                Base64.encode("$pKey:".toByteArray(), Base64.NO_WRAP).toString(Charsets.UTF_8)
        return mapOf(
            "Authorization" to basicAuth,
            "elepay-api-version" to ApiVersion.versionCode,
            "elepay-sdk-source" to "android",
            "elepay-sdk-version" to BuildConfig.LIB_VERSION_CODE,
        )
    }
}