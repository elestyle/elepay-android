package jp.elestyle.androidapp.elepay

import androidx.annotation.Keep
import com.google.android.gms.wallet.WalletConstants
import jp.elestyle.androidapp.elepay.utils.locale.LanguageKey

@Suppress("unused")
@Keep
enum class GooglePayEnvironment {
    TEST, PRODUCTION
}

internal fun GooglePayEnvironment.asWalletConstantsValue(): Int = when (this) {
    GooglePayEnvironment.TEST -> WalletConstants.ENVIRONMENT_TEST
    GooglePayEnvironment.PRODUCTION -> WalletConstants.ENVIRONMENT_PRODUCTION
}

/**
 * The theme of the user interface elements in elepay SDK
 */
@Keep
enum class ElepayTheme {
    /**
     * Matches current system's theme.
     */
    System,

    Light,

    Dark,
}

/**
 * The base configuration of elepay SDK.
 */
@Keep
class ElepayConfiguration(

    /**
     * The key that can be retrieved from your dashboard page.
     */
    val apiKey: String,

    /**
     * The url used as the base url when accessing remote resources/APIs.
     *
     * You can pass in your own server's url to make the whole resources completely under your control.
     * Normally, if you're using elepay's service, you should leave this parameter empty.
     */
    val remoteHostBaseUrl: String = "",

    /**
     * The environment of Google Pay.
     *
     * To use Google Pay, the app(apk) needs to be sent to Google for review.
     * And it may take several steps to finish the review. During the review process, app(apk)
     * needs to switch the environment individually.
     *
     * If the app does NOT use Google Pay, leave this field `null`.
     */
    val googlePayEnvironment: GooglePayEnvironment? = null,

    /**
     * Whether to require existing payment method for Google Pay.
     *
     * Default is `true`.
     */
    val googlePayExistingPaymentRequired: Boolean = true,

    /**
     * The language used by the elepay sdk.
     *
     * Default is [LanguageKey.System].
     */
    val languageKey: LanguageKey = LanguageKey.System,

    /**
     * The theme of ui components used by elepay SDK.
     *
     * Default is [ElepayTheme.System].
     */
    val theme: ElepayTheme = ElepayTheme.System
)