package jp.elestyle.androidapp.elepay.fragment.checkout

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.Toolbar
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.checkout.PaymentMethodBrand
import jp.elestyle.androidapp.elepay.data.checkout.PaymentMethodItem
import jp.elestyle.androidapp.elepay.utils.CheckoutDataSource
import jp.elestyle.androidapp.elepay.utils.extensions.applyElepayThemeColor
import jp.elestyle.androidapp.elepay.utils.extensions.isDarkMode
import jp.elestyle.androidapp.elepay.utils.locale.Localization
import jp.elestyle.androidapp.elepay.view.adapter.PaymentMethodListAdapter

internal class PaymentMethodListFragment : Fragment(R.layout.checkout_paymentmethod_list_fragment) {
    interface ActionListener {
        fun onSelectPaymentMethod(paymentMethodItem: PaymentMethodItem)
    }

    var actionListener: ActionListener? = null

    companion object {
        fun newInstance(selected: PaymentMethod): PaymentMethodListFragment =
            PaymentMethodListFragment().apply {
                arguments = Bundle().apply {
                    putString("selected_data", selected.rawValue)
                }
            }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = super.onCreateView(inflater, container, savedInstanceState)?.also { ret ->
        val list = generatePaymentMethodItemList() ?: return ret
        val selectedItem = arguments?.getString("selected_data")
            ?.let { PaymentMethod.from(it) }
            ?: return ret
        val selectedIdx = list.indexOfFirst { it.data == selectedItem }

        ret.findViewById<Toolbar>(R.id.pmlFgToolBar).apply {
            title = Localization.string(R.string.checkoutPaymentFragmentProductsPrompt)
            navigationIcon = ResourcesCompat
                .getDrawable(resources, R.drawable.ic_arrow_back_light_24dp, null)
                ?.apply {
                    applyElepayThemeColor(R.color.elepayTextColorPrimary, resources)
                }
            setNavigationOnClickListener {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        }

        ret.findViewById<RecyclerView>(R.id.pmlFgPaymentMethodListView).apply {
            adapter = PaymentMethodListAdapter(list, selectedIdx) { selectedItem ->
                actionListener?.onSelectPaymentMethod(selectedItem)
            }
            layoutManager = LinearLayoutManager(ret.context, LinearLayoutManager.VERTICAL, false)
            ResourcesCompat.getDrawable(resources, R.drawable.horizontal_divider, null)
                ?.also { dividerDrawable ->
                    val divider = DividerItemDecoration(context, LinearLayoutManager.VERTICAL)
                        .apply { setDrawable(dividerDrawable) }
                    addItemDecoration(divider)
                }
        }
    }

    private fun generatePaymentMethodItemList(): List<PaymentMethodItem>? {
        val codeSettings = CheckoutDataSource.codeSettings ?: return null
        val paymentMethodResources = CheckoutDataSource.paymentMethodResources
            .takeIf { it.isNotEmpty() }
            ?: return null

        val isDarkMode = resources.configuration.isDarkMode
        return codeSettings.paymentMethodsData.mapNotNull { methodData ->
            val brandKey = methodData.method.rawValue
            val resource = paymentMethodResources[brandKey] ?: return@mapNotNull null
            val brand = PaymentMethodBrand.generateFrom(brandKey, resource, isDarkMode)
                ?: return@mapNotNull null
            val associatedBrands = methodData.associatedBrands.mapNotNull { brandString ->
                val key = when (methodData.method) {
                    PaymentMethod.CREDIT_CARD ->
                        PaymentMethod.CREDIT_CARD.rawValue + "_" + brandString

                    else -> brandString
                }
                paymentMethodResources[key]?.let { resource ->
                    PaymentMethodBrand.generateFrom(key, resource, isDarkMode)
                }
            }
            PaymentMethodItem(brand, methodData.method, associatedBrands)
        }
    }
}