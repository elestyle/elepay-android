package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator


/**
 * Created by tanyin on 2018/01/22.
 */

internal object AlipayProcessor : ElepayProcessor {
    // No configs needed, so always be ready to process.
    override val isWellConfigured: Boolean = true

    override fun setup(providerConfig: ElepayProviderConfig) {
        // nothing to do
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else if (chargeData.payload == null || chargeData.payload.isEmpty()) {
            resultHandler?.invoke(
                ElepayResult.Failed(
                    chargeData.id, ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.ALIPAY,
                            chargeData.method,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "charge error"
                    )
                )
            )
            false
        } else {
            AlipayPerformer.pay(
                paymentId = chargeData.id,
                payload = chargeData.payload,
                fromActivity = fromActivity,
                resultHandler = resultHandler
            )
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false
}