package jp.elestyle.androidapp.elepay.data

import org.json.JSONObject

internal data class PaygentGooglePayConfig(
    /**
     * Details could be found at:
     * https://developers.google.com/pay/api/android/reference/request-objects#PaymentDataRequest
     *
     * The base structure contains:
     * {
     *   "apiVersion": 2,
     *   "apiVersionMinor": 0,
     *   "allowedPaymentMethods": [
     *     {
     *       "type": "CARD",
     *       "parameters": {
     *         "allowedAuthMethods": [
     *           "PAN_ONLY",
     *           "CRYPTOGRAM_3DS"
     *         ],
     *         "allowedCardNetworks": [
     *           "AMEX",
     *           "DISCOVER",
     *           "INTERAC",
     *           "JCB",
     *           "MASTERCARD",
     *           "VISA"
     *         ]
     *       }
     *     }
     *   ]
     * }
     */
    val paymentDataRequestBase: JSONObject,

    val merchantId: String
)