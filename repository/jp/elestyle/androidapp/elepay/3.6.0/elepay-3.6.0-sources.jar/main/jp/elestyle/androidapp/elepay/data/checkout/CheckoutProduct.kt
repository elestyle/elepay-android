package jp.elestyle.androidapp.elepay.data.checkout

import android.os.Parcel
import android.os.Parcelable

internal data class CheckoutProduct(
    val imageUrl: String,
    val title: String,
    val unitPrice: String,
    val count: Int
) : Parcelable {
    constructor(parcel: Parcel): this(
        imageUrl = parcel.readString() ?: "",
        title = parcel.readString() ?: "",
        unitPrice = parcel.readString() ?: "",
        count = parcel.readInt()
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(imageUrl)
        dest.writeString(title)
        dest.writeString(unitPrice)
        dest.writeInt(count)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR: Parcelable.Creator<CheckoutProduct> {
        override fun createFromParcel(source: Parcel): CheckoutProduct = CheckoutProduct(source)

        override fun newArray(size: Int): Array<CheckoutProduct?> = arrayOfNulls(size)
    }
}