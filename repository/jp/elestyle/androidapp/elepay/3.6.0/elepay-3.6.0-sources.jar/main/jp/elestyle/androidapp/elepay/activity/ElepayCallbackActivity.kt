package jp.elestyle.androidapp.elepay.activity

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.annotation.Keep
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessingResult
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessor
import jp.elestyle.androidapp.elepay.utils.ConfigManager
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.extensions.checkAndApplyElepayTheme
import jp.elestyle.androidapp.elepay.utils.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

@Keep
open class ElepayCallbackActivity : AppCompatActivity(), CoroutineScope by MainScope() {
    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        checkAndApplyElepayTheme(ConfigManager.theme)

        super.onCreate(savedInstanceState)

        setContentView(R.layout.callback_activity)

        val uri = intent.data ?: run {
            finish()
            return
        }

        lifecycleScope.launch {
            val processedRes = when (val res = CallbackProcessor.processCallbackUri(uri)) {
                is CallbackProcessingResult.InvalidUri -> {
                    // Could not pass this error back to user, since we don't know the "paymentId"
                    val dbgMsg = "Invalid uri $uri. Extra msg: ${res.message}"
                    log("ElepayCallbackActivity", dbgMsg)
                    null
                }

                is CallbackProcessingResult.Result -> res.result
            }

            finishPayment(processedRes)
        }
    }

    private fun finishPayment(result: CallbackProcessable.ProcessedResult?) {
        if (result != null) {
            ElepayResultHandlerManager.notifyResult(result.elepayResult, result.paymentId)
        }
        runOnUiThread { finish() }
    }
}
