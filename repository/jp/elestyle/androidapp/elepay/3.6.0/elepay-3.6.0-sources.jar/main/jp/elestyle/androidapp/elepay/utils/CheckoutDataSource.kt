package jp.elestyle.androidapp.elepay.utils

import jp.elestyle.androidapp.elepay.data.PaymentMethodResourceInfo
import jp.elestyle.androidapp.elepay.data.checkout.CodeSettings

internal object CheckoutDataSource {
    @get:Synchronized
    @set:Synchronized
    var codeSettings: CodeSettings? = null

    @get:Synchronized
    @set:Synchronized
    var paymentMethodResources = mapOf<String, PaymentMethodResourceInfo>()

    @get:Synchronized
    val isDataValid: Boolean
        get() = codeSettings != null && paymentMethodResources.isNotEmpty()

    @Synchronized
    fun cleanup() {
        codeSettings = null
        paymentMethodResources = mapOf()
    }
}