package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.unionpay.UnionPayIntermediateActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import org.json.JSONException
import org.json.JSONObject

internal object UnionPayProcessor : ElepayProcessor {
    private var mode = ""

    override val isWellConfigured: Boolean = mode.isNotEmpty()

    override fun setup(providerConfig: ElepayProviderConfig) {
        if (providerConfig is ElepayProviderConfig.UnionPay) {
            mode = providerConfig.mode
        }
        // nothing to do
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else if (chargeData.payload == null || chargeData.payload.isEmpty()) {
            val error = ElepayError.InvalidPayload(
                errorCode = ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.UNION_PAY,
                    chargeData.method,
                    ErrorCode.INVALID_PAYLOAD
                ),
                message = "charge error, invalid payload"
            )
            resultHandler?.invoke(ElepayResult.Failed(chargeData.id, error))
            false
        } else {
            processUnionPayCharge(chargeData, fromActivity, resultHandler)
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    private fun processUnionPayCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val tn = chargeData.payload
            ?.let {
                try {
                    JSONObject(it).optString("tn", "")
                } catch (e: JSONException) {
                    null
                }
            }
            ?.takeIf { it.isNotEmpty() }
            ?: run {
                // Should not happen.
                val error = ElepayError.InvalidPayload(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.UNION_PAY,
                        chargeData.method,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    message = "Invalid payload: ${chargeData.payload}."
                )
                resultHandler?.invoke(ElepayResult.Failed(chargeData.id, error))
                return false
            }
        val usesDevMode = when (mode) {
            // As the doc says, currently(20211011) only 2 modes are available:
            // "00" for production, "01" for test.
            "01" -> true
            "00" -> false
            else -> {
                // Should not happen.
                val error = ElepayError.InvalidPayload(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.UNION_PAY,
                        chargeData.method,
                        ErrorCode.UNINIT
                    ),
                    message = "Invalid mode: $mode. Contact the elepay support to make sure the configuration is correct."
                )
                resultHandler?.invoke(ElepayResult.Failed(chargeData.id, error))
                return false
            }
        }

        if (resultHandler != null) {
            ElepayResultHandlerManager.registerResultHandler(resultHandler, chargeData.id)
        }
        val intent = Intent(fromActivity, UnionPayIntermediateActivity::class.java).apply {
            putExtra(UnionPayIntermediateActivity.IntentExtraKey.PAYMENT_ID.rawValue, chargeData.id)
            putExtra(UnionPayIntermediateActivity.IntentExtraKey.PAYMENT_TN.rawValue, tn)
            putExtra(
                UnionPayIntermediateActivity.IntentExtraKey.USES_DEVELOPMENT_ENVIRONMENT.rawValue,
                usesDevMode
            )
        }
        fromActivity.startActivity(intent)

        return true
    }
}