package jp.elestyle.androidapp.elepay.utils

import java.util.Locale

internal fun symbolizeCurrency(currency: String): String =
    when (currency.lowercase(Locale.ROOT)) {
        "jpy" -> "\u00A5"
        else -> ""
    }