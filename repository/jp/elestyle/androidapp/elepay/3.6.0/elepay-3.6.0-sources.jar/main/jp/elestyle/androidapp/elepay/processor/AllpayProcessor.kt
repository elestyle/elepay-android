package jp.elestyle.androidapp.elepay.processor

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.activity.allpay.AllpayIntermediateActivity
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.IntegrationChecker
import jp.elestyle.androidapp.elepay.utils.PermissionChecker
import org.json.JSONException
import org.json.JSONObject

internal object AllpayProcessor : ElepayProcessor {
    private var usesDevelopmentEnvironment = false

    // No configs needs to be checked, so always be ready to process.
    override val isWellConfigured: Boolean = true

    override fun setup(providerConfig: ElepayProviderConfig) {
        if (providerConfig is ElepayProviderConfig.Allpay) {
            usesDevelopmentEnvironment = providerConfig.usesDevelopmentEnvironment
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(chargeData.paymentCommon, fromActivity, resultHandler)) true
        else when (chargeData.method) {

            PaymentMethod.ALIPAY -> processAlipay(chargeData, fromActivity, resultHandler)

            PaymentMethod.UNION_PAY -> processUnionPay(chargeData, fromActivity, resultHandler)

            PaymentMethod.WECHAT_PAY -> processWechatPay(chargeData, fromActivity, resultHandler)

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        chargeData.id,
                        ElepayError.UnsupportedPaymentMethod(
                            "${PaymentMethodProvider.ALLPAY.rawValue} ${chargeData.method.rawValue}"
                        )
                    )
                )
                false
            }
        }

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    private fun processAlipay(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (!IntegrationChecker.isAlipayAvailable()) {
            postElepayResult(
                result = ElepayResult.Failed(
                    paymentId = chargeData.id,
                    error = ElepayError.UninitializedPaymentMethod(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.ENDUSER,
                            null,
                            null,
                            ErrorCode.UNINIT
                        ),
                        paymentMethod = PaymentMethod.ALIPAY.rawValue,
                        message = "Have you installed Alipay sdk to your project?"
                    )
                ),
                handler = resultHandler
            )
            false
        } else if (chargeData.payload == null || chargeData.payload.isEmpty()) {
            postElepayResult(
                ElepayResult.Failed(
                    chargeData.id, ElepayError.InvalidPayload(
                        errorCode = ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.ALLPAY,
                            PaymentMethod.ALIPAY,
                            ErrorCode.INVALID_PAYLOAD
                        ),
                        message = "charge error"
                    )
                ),
                resultHandler
            )
            false
        } else processPayment(
            paymentId = chargeData.id,
            payload = chargeData.payload,
            fromActivity = fromActivity,
            resultHandler = resultHandler
        )

    private fun processUnionPay(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = if (chargeData.payload == null || chargeData.payload.isEmpty()) {
        resultHandler?.invoke(
            ElepayResult.Failed(
                chargeData.id, ElepayError.InvalidPayload(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.ALLPAY,
                        PaymentMethod.UNION_PAY,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    message = "charge error"
                )
            )
        )
        false
    } else processPayment(
        paymentId = chargeData.id,
        payload = chargeData.payload,
        fromActivity = fromActivity,
        resultHandler = resultHandler
    )

    private fun processWechatPay(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = if (!IntegrationChecker.isWechatPayAvailable()) {
        postElepayResult(
            result = ElepayResult.Failed(
                paymentId = chargeData.id,
                error = ElepayError.UninitializedPaymentMethod(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        null,
                        null,
                        ErrorCode.UNINIT
                    ),
                    paymentMethod = PaymentMethod.ALIPAY.rawValue,
                    message = "Have you installed Wechat Pay sdk to your project?"
                )
            ),
            handler = resultHandler
        )
        false
    } else if (chargeData.payload == null || chargeData.payload.isEmpty()) {
        postElepayResult(
            ElepayResult.Failed(
                chargeData.id, ElepayError.InvalidPayload(
                    errorCode = ErrorCodeGenerator.generate(
                        PlatformCode.SDK,
                        PaymentMethodProvider.ALLPAY,
                        PaymentMethod.WECHAT_PAY,
                        ErrorCode.INVALID_PAYLOAD
                    ),
                    message = "charge error"
                )
            ),
            resultHandler
        )
        false
    } else processPayment(
        paymentId = chargeData.id,
        payload = chargeData.payload,
        fromActivity = fromActivity,
        resultHandler = resultHandler
    )

    private fun processPayment(
        paymentId: String,
        payload: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val ungrantedPermissions = checkForStupidAllpayPermissions(fromActivity)
        val error = when {
            ElepayResultHandlerManager.checkRegistration(paymentId) ->
                ElepayError.AlreadyMakingPayment(paymentId)

            ungrantedPermissions.isNotEmpty() ->
                ElepayError.PermissionRequired(ungrantedPermissions)

            else -> processAllpayPaymentData(paymentId, payload, fromActivity, resultHandler)
        }

        return if (error != null) {
            resultHandler?.invoke(ElepayResult.Failed(paymentId, error))
            false
        } else true
    }

    private fun checkForStupidAllpayPermissions(context: Context): List<String> =
        PermissionChecker.filterUngrantedPermissions(
            permissions = arrayOf(
                // Camera
                //                Manifest.permission.CAMERA,
                // Location
                //                Manifest.permission.ACCESS_FINE_LOCATION,
                //                Manifest.permission.ACCESS_COARSE_LOCATION,
                // Audio recording
                //                Manifest.permission.RECORD_AUDIO,
                // SMS
                //                Manifest.permission.READ_SMS,
                //                Manifest.permission.RECEIVE_SMS,
                // Storage
                //                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                // Phone
                Manifest.permission.READ_PHONE_STATE
            ),
            context = context
        )

    private fun processAllpayPaymentData(
        paymentId: String,
        payload: String,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): ElepayError? = try {
        val tn = JSONObject(payload).optString("tn", "")
        if (tn.isNotEmpty()) {
            if (resultHandler != null) {
                ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
            }
            val intent = Intent(fromActivity, AllpayIntermediateActivity::class.java).apply {
                putExtra(
                    AllpayIntermediateActivity.IntentExtraKey.USES_DEVELOPMENT_ENVIRONMENT.rawValue,
                    usesDevelopmentEnvironment
                )
                putExtra(
                    AllpayIntermediateActivity.IntentExtraKey.PAYMENT_ID.rawValue,
                    paymentId
                )
                putExtra(
                    AllpayIntermediateActivity.IntentExtraKey.PAYMENT_TN.rawValue,
                    tn
                )
            }
            fromActivity.startActivity(intent)
            null
        } else ElepayError.InvalidPayload(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.SDK,
                PaymentMethodProvider.ALLPAY,
                null,
                ErrorCode.INVALID_TOKEN
            ),
            message = "Invalid AllPay payload: $payload"
        )
    } catch (e: JSONException) {
        ElepayError.InvalidPayload(
            errorCode = ErrorCodeGenerator.generate(
                PlatformCode.SDK,
                PaymentMethodProvider.ALLPAY,
                null,
                ErrorCode.INVALID_TOKEN
            ),

            message = "Invalid AllPay payload: $payload"
        )
    }
}