package jp.elestyle.androidapp.elepay.data.checkout

import android.os.Parcel
import android.os.Parcelable
import jp.elestyle.androidapp.elepay.R
import jp.elestyle.androidapp.elepay.data.PaymentMethodResourceInfo
import jp.elestyle.androidapp.elepay.utils.locale.Localization

internal data class PaymentMethodBrand(
    val id: String,
    val logoUrl: String,
    val name: String
) : Parcelable {

    constructor(parcel: Parcel) : this(
        id = parcel.readString() ?: "",
        logoUrl = parcel.readString() ?: "",
        name = parcel.readString() ?: "",
    )

    override fun describeContents(): Int = 0

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(id)
        dest.writeString(logoUrl)
        dest.writeString(name)
    }

    companion object {
        fun generateFrom(
            id: String,
            resource: PaymentMethodResourceInfo,
            isDarkMode: Boolean
        ): PaymentMethodBrand? {
            val url =
                if (isDarkMode) {
                    resource.imageUrl["short_dark"]
                } else {
                    resource.imageUrl["short"]
                } ?: return null
            val nameKey = Localization.string(R.string.payment_method_name_key)
            val name = resource.name[nameKey] ?: return null

            return PaymentMethodBrand(id, url, name)
        }

        @Suppress("unused")
        @JvmField
        val CREATOR = object : Parcelable.Creator<PaymentMethodBrand> {
            override fun createFromParcel(parcel: Parcel): PaymentMethodBrand {
                return PaymentMethodBrand(parcel)
            }

            override fun newArray(size: Int): Array<PaymentMethodBrand?> {
                return arrayOfNulls(size)
            }
        }
    }
}