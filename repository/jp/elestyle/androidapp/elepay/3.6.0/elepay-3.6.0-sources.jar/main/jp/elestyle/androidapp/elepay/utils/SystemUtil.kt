package jp.elestyle.androidapp.elepay.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.StringBuilderPrinter

internal object SystemUtil {
    fun getHostAppInfo(context: Context): Map<String, String> {
        val pkgMgr = context.packageManager ?: return mapOf()
        val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pkgMgr.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pkgMgr.getPackageInfo(context.packageName, 0)
        } ?: return mapOf()

        @Suppress("DEPRECATION")
        val versionCode =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pkgInfo.longVersionCode.toString()
            else pkgInfo.versionCode.toString()

        val appInfo = pkgInfo.applicationInfo
        val appInfoStringBuilder = StringBuilder()
        appInfo.dump(StringBuilderPrinter(appInfoStringBuilder), "")

        return mapOf(
            "packageName" to pkgInfo.packageName,
            "version" to pkgInfo.versionName,
            "versionCode" to versionCode,
            "requestedPermissions" to (pkgInfo.requestedPermissions?.joinToString(",") ?: "none"),
            "firstInstallTime" to pkgInfo.firstInstallTime.toString(),
            "lastUpdateTime" to pkgInfo.lastUpdateTime.toString(),
            "appInfo" to appInfoStringBuilder.toString()
        )
    }

    fun isPackageInstalled(packageName: String, context: Context): Boolean {
        val pkgMgr = context.packageManager ?: return false
        return pkgMgr.getLaunchIntentForPackage(packageName) != null
    }

    fun isIntentLaunchable(intent: Intent, context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.resolveActivity(
                intent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        } != null
}