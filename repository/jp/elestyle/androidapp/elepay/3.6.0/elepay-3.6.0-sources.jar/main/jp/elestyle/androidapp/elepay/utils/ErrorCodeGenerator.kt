package jp.elestyle.androidapp.elepay.utils

import androidx.annotation.Keep
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode

/**
 * An generator creates the error code in the elepay specified format.
 */
@Keep
internal object ErrorCodeGenerator {
    private const val unknownBlock = "000"

    /**
     * This method is used by elepay internally.
     */
    fun generate(
        platform: PlatformCode,
        provider: PaymentMethodProvider?,
        method: PaymentMethod?,
        errorCode: ErrorCode
    ): String = generate(platform, provider, method, errorCode.raw)

    private fun generate(
        platform: PlatformCode,
        provider: PaymentMethodProvider?,
        method: PaymentMethod?,
        code: String
    ): String =
        when (platform) {
            PlatformCode.ENDUSER -> {
                // When there's detail information, construct the unified data.
                // Other wise, give a short-hand of the error code.
                if (provider != null || method != null) {
                    concatenate(platform, provider, method, code)
                } else {
                    code
                }
            }

            PlatformCode.SDK -> concatenate(platform, provider, method, code)
        }

    private fun concatenate(
        platform: PlatformCode, provider: PaymentMethodProvider?,
        method: PaymentMethod?,
        code: String
    ): String = arrayOf(
        platform.raw,
        provider?.asErrorCodeBlock ?: unknownBlock,
        method?.asErrorCodeBlock ?: unknownBlock,
        code
    ).joinToString("_")

}