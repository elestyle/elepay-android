package jp.elestyle.androidapp.elepay.utils

import android.content.Context
import jp.elestyle.androidapp.elepay.BuildConfig
import java.security.SecureRandom


internal object SecuredDataStore {
    private const val sharedPrefsFile = "elepay_sec_shared_prefs"

    fun retrieveKey(): String {
        val sb = StringBuilder()
        sb.append(BuildConfig.K1.reversed())
        sb.append(BuildConfig.K2)
        sb.append(BuildConfig.K3.reversed())
        return sb.toString()
    }

    fun generateIvParam(): ByteArray {
        val secureRandom = SecureRandom()
        val byteArray = ByteArray(16)
        secureRandom.nextBytes(byteArray)
        val ret = ByteArray(16)
        byteArray.forEachIndexed { idx, byte ->
            @Suppress("KotlinConstantConditions")
            ret[idx] = (byte.toInt() and 0xF0 shr 31).toByte()
        }
        return ret
    }
}