package jp.elestyle.androidapp.elepay.utils.locale

import androidx.annotation.Keep

/**
 * The Language key code used by elepay SDK.
 */
@Keep
enum class LanguageKey {
    /**
     * elepay SDK uses the OS language where the app is running.
     */
    System,
    English, SimplifiedChinese, TraditionalChinese, Japanese;
}