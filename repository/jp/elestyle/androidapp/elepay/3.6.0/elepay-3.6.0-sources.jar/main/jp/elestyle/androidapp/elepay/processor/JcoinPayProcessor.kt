package jp.elestyle.androidapp.elepay.processor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.ElepayResultHandler
import jp.elestyle.androidapp.elepay.data.CallbackProcessingData
import jp.elestyle.androidapp.elepay.data.ChargeData
import jp.elestyle.androidapp.elepay.data.ElepayProviderConfig
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PaymentMethod
import jp.elestyle.androidapp.elepay.data.PaymentMethodProvider
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.SourceData
import jp.elestyle.androidapp.elepay.processor.callback.CallbackProcessable
import jp.elestyle.androidapp.elepay.utils.ElepayResultHandlerManager
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import org.json.JSONObject

internal object JcoinPayProcessor: ElepayProcessor, CallbackProcessable {
    private var processingData: CallbackProcessable.ProcessingPaymentInfo? = null

    override val isWellConfigured: Boolean
        get() = callbackScheme.isNotEmpty()

    override fun setup(providerConfig: ElepayProviderConfig) {
        if (providerConfig is ElepayProviderConfig.JcoinPay) {
            callbackScheme = providerConfig.appScheme
        }
    }

    override fun processCharge(
        chargeData: ChargeData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = processJcoinPay(
        paymentData = chargeData.paymentCommon,
        payload = chargeData.payload,
        fromActivity,
        resultHandler
    )

    override fun processSource(
        sourceData: SourceData,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean = false

    override var callbackScheme: String = ""
        private set

    override fun retrieveProcessingPaymentInfo(
        disposeImmediately: Boolean
    ): CallbackProcessable.ProcessingPaymentInfo? {
        val ret = processingData
        if (disposeImmediately) {
            processingData = null
        }
        return ret
    }

    override suspend fun continueCallbackProcessing(
        data: CallbackProcessingData
    ): CallbackProcessable.ProcessedResult {
        val paymentId = data.paymentData.id
        val elepayResult = when (data.params["type"]?.lowercase()) {
            null -> ElepayResult.Failed(
                paymentId = paymentId,
                error = ElepayError.InvalidPayload(
                    ErrorCodeGenerator.generate(
                        PlatformCode.ENDUSER,
                        data.paymentData.provider,
                        data.paymentData.method,
                        ErrorCode.FAILED
                    ),
                    "No valid type found."
                )
            )
            "confirm" -> ElepayResult.Succeeded(paymentId)
            else -> ElepayResult.Canceled(paymentId)
        }

        return CallbackProcessable.ProcessedResult(paymentId, elepayResult)
    }

    private fun processJcoinPay(
        paymentData: PaymentCommon,
        payload: String?,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean =
        if (processTestModePayment(paymentData, fromActivity, resultHandler)) true
        else when (paymentData.method) {
            PaymentMethod.JCOINPAY -> {
                if (!isWellConfigured) {
                    val error = ElepayError.UninitializedPaymentMethod(
                        ErrorCodeGenerator.generate(
                            PlatformCode.SDK,
                            PaymentMethodProvider.JCOINPAY,
                            PaymentMethod.JCOINPAY,
                            ErrorCode.UNINIT
                        ),
                        PaymentMethod.JCOINPAY.rawValue,
                        "Not well configured"
                    )
                    resultHandler?.invoke(ElepayResult.Failed(paymentData.id, error))
                    false
                } else {
                    processJcoinPayCharge(
                        payload,
                        paymentData,
                        fromActivity,
                        resultHandler
                    )
                }
            }

            else -> {
                resultHandler?.invoke(
                    ElepayResult.Failed(
                        paymentId = paymentData.id,
                        error = ElepayError.UnsupportedPaymentMethod(paymentData.method.rawValue)
                    )
                )
                false
            }
        }

    private fun processJcoinPayCharge(
        payload: String?,
        paymentData: PaymentCommon,
        fromActivity: Activity,
        resultHandler: ElepayResultHandler?
    ): Boolean {
        val paymentId = paymentData.id
        if (payload.isNullOrEmpty()) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.JCOINPAY,
                    PaymentMethod.JCOINPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.PAYPAY.rawValue} no payload."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentId, error = error))
            return false
        }

        val jsonPayload = try {
            JSONObject(payload)
        } catch (e: Exception) {
            val error = ElepayError.InvalidPayload(
                ErrorCodeGenerator.generate(
                    PlatformCode.SDK,
                    PaymentMethodProvider.JCOINPAY,
                    PaymentMethod.JCOINPAY,
                    ErrorCode.INVALID_PAYLOAD
                ),
                "${PaymentMethod.PAYPAY.rawValue} invalid json payload."
            )
            resultHandler?.invoke(ElepayResult.Failed(paymentId = paymentId, error = error))
            return false
        }

        val paymentUrl = jsonPayload.optString("paymentUrl", "")
        return if (paymentUrl.isNotEmpty()) {
            try {
                val uri = Uri.parse(paymentUrl)
                fromActivity.startActivity(Intent(Intent.ACTION_VIEW, uri))
                processingData = CallbackProcessable.ProcessingPaymentInfo(paymentData)
                if (resultHandler != null) {
                    ElepayResultHandlerManager.registerResultHandler(resultHandler, paymentId)
                }
                true
            } catch (e: Exception) {
                false
            }
        } else false
    }
}