package jp.elestyle.androidapp.elepay.processor.creditcard

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import androidx.activity.ComponentActivity
import jp.elestyle.androidapp.elepay.ElepayError
import jp.elestyle.androidapp.elepay.ElepayResult
import jp.elestyle.androidapp.elepay.activity.internal.CreditCardScannerResult
import jp.elestyle.androidapp.elepay.activity.internal.CreditCardScannerSheet
import jp.elestyle.androidapp.elepay.activity.internal.ElepayJavaScriptInterface
import jp.elestyle.androidapp.elepay.activity.internal.ElepayJsActionPerformer
import jp.elestyle.androidapp.elepay.data.CreditCardInfo
import jp.elestyle.androidapp.elepay.data.ErrorCode
import jp.elestyle.androidapp.elepay.data.PaymentCommon
import jp.elestyle.androidapp.elepay.data.PlatformCode
import jp.elestyle.androidapp.elepay.data.ResultType
import jp.elestyle.androidapp.elepay.utils.ErrorCodeGenerator
import jp.elestyle.androidapp.elepay.utils.ServerAPIClient
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.lang.ref.WeakReference
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume

/**
 * A credit card processor using an invisible WebView communicating with its inner js.
 */
internal class WebViewCreditCardProcessor(
    private val paymentData: PaymentCommon,
    private val processingUrl: String,
    private val activity: Activity
) : NumberScannableCreditCardProcessor {

    private val tokenProcessor = CreditCardTokenJsProcessor(paymentData)
    private var cardScanContinuation: CancellableContinuation<CreditCardInfo?>? = null
    private var scannerSheet: CreditCardScannerSheet? = null

    @SuppressLint("SetJavaScriptEnabled")
    override suspend fun processCard(card: CreditCardInfo): ElepayResult =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                val webview = WebView(activity)
                tokenProcessor.prepare(cont, card, webview)
                webview.apply {
                    settings.apply {
                        javaScriptEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        @Suppress("DEPRECATION")
                        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
                            allowFileAccessFromFileURLs = false
                            allowUniversalAccessFromFileURLs = false
                        }
                    }
                    addJavascriptInterface(
                        ElepayJavaScriptInterface(paymentData, WeakReference(tokenProcessor)),
                        ElepayJavaScriptInterface.ELEPAY_JS_NAME
                    )
                }
                webview.loadUrl(processingUrl)
            }
        }


    override fun cancelProcessing() {}

    override fun onHostActivityCreate(hostActivity: ComponentActivity) {
        scannerSheet = CreditCardScannerSheet.create(
            from = hostActivity,
            resultCallback = { result ->
                val continuation = cardScanContinuation ?: return@create
                when (result) {
                    is CreditCardScannerResult.Completed -> {
                        continuation.resume(result.cardInfo)
                    }

                    is CreditCardScannerResult.Canceled -> {
                        continuation.resume(null)
                    }
                }

                cardScanContinuation = null
            }
        )
    }

    override fun onHostActivityDestroy(hostActivity: ComponentActivity) {
        cardScanContinuation = null
        scannerSheet?.dismiss()
        scannerSheet = null
    }

    override suspend fun scanCreditCard(hostActivity: ComponentActivity): CreditCardInfo? =
        suspendCancellableCoroutine { cont ->
            cardScanContinuation?.cancel()
            cardScanContinuation = cont

            scannerSheet?.show()
        }
}

private class CreditCardTokenJsProcessor(
    private val paymentData: PaymentCommon
) : ElepayJsActionPerformer {

    private var continuation: Continuation<ElepayResult>? = null
    private var cardInfo: CreditCardInfo? = null
    private var webView: WebView? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    fun prepare(cont: Continuation<ElepayResult>, creditCard: CreditCardInfo, webView: WebView) {
        continuation = cont
        cardInfo = creditCard
        this.webView = webView
    }

    override fun onPaymentResult(result: ElepayResult) {
        sendResult(result)
        continuation?.resume(result)
    }

    override fun onCapturePayment(token: String) {
        val paymentId = paymentData.id
        scope.launch {
            when (val result = ServerAPIClient.capture(paymentId = paymentId, token = token)) {
                is ResultType.Failed -> {
                    val failure = ElepayResult.Failed(
                        paymentId,
                        ElepayError.PaymentFailure(
                            ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                paymentData.provider,
                                paymentData.method,
                                ErrorCode.FAILED_CAPTURE
                            ),
                            result.error.message
                        )
                    )
                    sendResult(failure)
                }

                is ResultType.Succeeded -> {
                    sendResult(ElepayResult.Succeeded(paymentId))
                }
            }
        }
    }

    override fun onConfirmPayment(token: String) {
        val paymentId = paymentData.id
        scope.launch {
            when (val result = ServerAPIClient.confirm(sourceId = paymentId, token = token)) {
                is ResultType.Failed -> {
                    val failure = ElepayResult.Failed(
                        paymentId,
                        ElepayError.PaymentFailure(
                            ErrorCodeGenerator.generate(
                                PlatformCode.SDK,
                                paymentData.provider,
                                paymentData.method,
                                ErrorCode.FAILED_CONFIRM
                            ),
                            result.error.message
                        )
                    )
                    sendResult(failure)
                }

                is ResultType.Succeeded -> {
                    sendResult(ElepayResult.Succeeded(paymentId))
                }
            }
        }
    }

    override fun onProviderPaymentParams(callbackEvent: String) {
        val card = cardInfo ?: return
        val jsonCreditCard = JSONObject(mapOf(
            "cardNumber" to card.number.replace("\\s".toRegex(), ""),
            "cardExpiryYear" to card.year.toString(),
            "cardExpiryMonth" to card.month.toString(),
            "cardCvc" to card.cvc
        ))
        val js = "\$elepay.$callbackEvent($jsonCreditCard)"
        Handler(Looper.getMainLooper()).post {
            webView?.evaluateJavascript(js, null)
        }
    }

    override fun onOpen(url: String) {
        if (webView == null) return

        val uri = Uri.parse(url)
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        webView?.context?.startActivity(intent)
    }

    private fun sendResult(result: ElepayResult) {
        continuation?.resume(result)
        continuation = null
    }
}
